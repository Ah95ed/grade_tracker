import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import rawConfig from '../../firebase-applet-config.json';

const env = (typeof import.meta !== 'undefined' && import.meta?.env) ? import.meta.env : ({} as Record<string, string | undefined>);
const cfg: any = rawConfig || {};

// Fallback client API key for applet development and preview
const DEFAULT_API_KEY = 'AIzaSyCt83OG0NioLFOMK2qHwoJHcu40cJnB5gw';

// Use environment variables if provided (e.g. on Cloudflare Pages/Production), or fallback to config file
const firebaseConfig = {
  apiKey: env.VITE_FIREBASE_API_KEY || cfg.apiKey || DEFAULT_API_KEY,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || cfg.authDomain || 'gen-lang-client-0369327125.firebaseapp.com',
  projectId: env.VITE_FIREBASE_PROJECT_ID || cfg.projectId || 'gen-lang-client-0369327125',
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || cfg.storageBucket || 'gen-lang-client-0369327125.firebasestorage.app',
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || cfg.messagingSenderId || '1059409489946',
  appId: env.VITE_FIREBASE_APP_ID || cfg.appId || '1:1059409489946:web:d251a04020251d32b8a1a3',
};

let app: any;
try {
  app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
} catch (e) {
  console.warn('Firebase app init warning, retrying with fallback:', e);
  app = initializeApp({ ...firebaseConfig, apiKey: DEFAULT_API_KEY }, 'fallback-app');
}

let authInstance: any;
try {
  authInstance = getAuth(app);
} catch (e) {
  console.warn('Firebase getAuth warning, falling back to default API key:', e);
  try {
    const safeApp = initializeApp({ ...firebaseConfig, apiKey: DEFAULT_API_KEY }, 'safe-auth-app');
    authInstance = getAuth(safeApp);
  } catch (err2) {
    console.error('Critical Firebase Auth initialization error:', err2);
    // Return existing auth or basic object to prevent runtime import crashing
    authInstance = getAuth(app);
  }
}

export const auth = authInstance;
export const googleAuthProvider = new GoogleAuthProvider();

