import React, { useState, useMemo } from 'react';
import {
  MonthlyModel,
  TermModel,
  TeacherProfile,
  StudentSimpleCard,
  ClassSectionCard,
  PrintSettings,
} from '../../types';
import { calculateTermSummaries } from '../../utils/gradeCalculations';
import {
  Printer,
  FileSpreadsheet,
  Search,
  Sliders,
  AlertCircle,
  ArrowRight,
  Layers,
  School,
  LayoutGrid,
  Table as TableIcon,
  Users,
  Filter,
} from 'lucide-react';
import { ReportCardItem } from './ReportCardItem';
import { StudentCardModal } from './StudentCardModal';
import { PrintSettingsModal } from './PrintSettingsModal';

interface Props {
  monthlyModels: MonthlyModel[];
  terms: TermModel[];
  profile: TeacherProfile;
  onUpdateProfile?: (profile: TeacherProfile) => void;
  onNavigateToTerms?: () => void;
}

export const ReportCardsView: React.FC<Props> = ({
  monthlyModels,
  terms,
  profile,
  onUpdateProfile,
  onNavigateToTerms,
}) => {
  // Search and Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSection, setSelectedSection] = useState<string>('ALL');
  const [selectedGradeLevel, setSelectedGradeLevel] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  // Modals
  const [isPrintSettingsOpen, setIsPrintSettingsOpen] = useState(false);
  const [selectedCardForModal, setSelectedCardForModal] =
    useState<ClassSectionCard | null>(null);

  // Print settings
  const [printSettings, setPrintSettings] = useState<PrintSettings>(() => {
    try {
      const saved = localStorage.getItem('gradebook_print_settings');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error(e);
    }
    return {
      cardsPerPage: '1',
      orientation: 'portrait',
      margin: 'normal',
      customMarginMm: 10,
      showSchoolHeader: true,
      showSchoolLogo: true,
      showSignatures: false,
    };
  });

  const handleUpdateSettings = (newSettings: PrintSettings) => {
    setPrintSettings(newSettings);
    try {
      localStorage.setItem('gradebook_print_settings', JSON.stringify(newSettings));
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateProfile = (updated: TeacherProfile) => {
    if (onUpdateProfile) {
      onUpdateProfile(updated);
    }
  };

  // Derive common academic year and subject
  const defaultAcademicYear =
    profile.academicYear || monthlyModels[0]?.academicYear || '2024 - 2025';
  const defaultSubject =
    profile.subject || monthlyModels[0]?.subject || 'المادة الدراسية';

  // Assemble student card data across all terms defined in "المعدل"
  const studentCards = useMemo(() => {
    if (terms.length === 0) return [];

    // Calculate summaries for each term
    const termResults = terms.map((term) => ({
      term,
      summaries: calculateTermSummaries(term, monthlyModels),
    }));

    // Collect all unique students
    const map = new Map<
      string,
      {
        id: string;
        name: string;
        gradeLevel: string;
        section: string;
        termScores: Record<string, number | null>;
      }
    >();

    // 1. First add students in monthlyModels order
    for (const model of monthlyModels) {
      for (const s of model.students) {
        const key = s.name.trim().toLowerCase();
        if (!map.has(key)) {
          map.set(key, {
            id: s.id || key,
            name: s.name.trim(),
            gradeLevel: s.gradeLevel || '',
            section: s.section || '',
            termScores: {},
          });
        } else {
          const item = map.get(key)!;
          if (!item.gradeLevel && s.gradeLevel) item.gradeLevel = s.gradeLevel;
          if (!item.section && s.section) item.section = s.section;
        }
      }
    }

    // 2. Also ensure any students in term summaries are included
    for (const { summaries } of termResults) {
      for (const s of summaries) {
        const key = s.name.trim().toLowerCase();
        if (!map.has(key)) {
          map.set(key, {
            id: s.studentId || key,
            name: s.name.trim(),
            gradeLevel: s.gradeLevel || '',
            section: s.section || '',
            termScores: {},
          });
        }
      }
    }

    // 3. Assign each term's final score for each student
    map.forEach((student, key) => {
      termResults.forEach(({ term, summaries }) => {
        const found = summaries.find((s) => s.name.trim().toLowerCase() === key);
        student.termScores[term.id] = found?.finalTermScore ?? null;
      });
    });

    return Array.from(map.values());
  }, [terms, monthlyModels]);

  // Group students by Class & Section into ClassSectionCards
  const classCards = useMemo(() => {
    if (terms.length === 0 || studentCards.length === 0) return [];

    const groupMap = new Map<string, ClassSectionCard>();

    for (const student of studentCards) {
      const g = student.gradeLevel?.trim() || '';
      const s = student.section?.trim() || '';
      const key = `${g}|||${s}`;

      if (!groupMap.has(key)) {
        groupMap.set(key, {
          id: key,
          gradeLevel: g,
          section: s,
          students: [],
        });
      }

      groupMap.get(key)!.students.push(student);
    }

    return Array.from(groupMap.values());
  }, [studentCards, terms]);

  // Unique sections & grade levels for filtering at the top
  const allSections = useMemo(() => {
    return Array.from(
      new Set(studentCards.map((s) => s.section?.trim()).filter(Boolean))
    );
  }, [studentCards]);

  const allGradeLevels = useMemo(() => {
    return Array.from(
      new Set(studentCards.map((s) => s.gradeLevel?.trim()).filter(Boolean))
    );
  }, [studentCards]);

  // Filter cards based on selected Grade Level, Section, and Search
  const filteredClassCards = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    return classCards
      .filter((card) => {
        const matchGrade =
          selectedGradeLevel === 'ALL' || card.gradeLevel === selectedGradeLevel;
        const matchSection =
          selectedSection === 'ALL' || card.section === selectedSection;

        if (!matchGrade || !matchSection) return false;

        if (query) {
          const matchClassName =
            card.gradeLevel.toLowerCase().includes(query) ||
            card.section.toLowerCase().includes(query);
          const matchStudent = card.students.some((s) =>
            s.name.toLowerCase().includes(query)
          );
          return matchClassName || matchStudent;
        }

        return true;
      })
      .map((card) => {
        if (query) {
          const matchClassName =
            card.gradeLevel.toLowerCase().includes(query) ||
            card.section.toLowerCase().includes(query);
          if (!matchClassName) {
            return {
              ...card,
              students: card.students.filter((s) =>
                s.name.toLowerCase().includes(query)
              ),
            };
          }
        }
        return card;
      });
  }, [classCards, selectedGradeLevel, selectedSection, searchQuery]);

  // Total students currently shown in filtered cards
  const totalFilteredStudents = useMemo(() => {
    return filteredClassCards.reduce((acc, c) => acc + c.students.length, 0);
  }, [filteredClassCards]);

  // Export single class card to Excel
  const handleExportClassExcel = (card: ClassSectionCard) => {
    const headers = [
      'ت',
      'اسم الطالب',
      'المرحلة / الصف',
      'الشعبة',
      'السنة الدراسية',
      'المادة',
      ...terms.map((t) => `درجة ${t.name}`),
    ];

    const rows = card.students.map((student, idx) => {
      const scores = terms.map((t) => {
        const score = student.termScores[t.id];
        return score !== null && score !== undefined ? score : '';
      });

      return [
        idx + 1,
        `"${student.name}"`,
        `"${card.gradeLevel || '—'}"`,
        `"${card.section || '—'}"`,
        `"${defaultAcademicYear}"`,
        `"${defaultSubject}"`,
        ...scores,
      ];
    });

    const csvContent =
      '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const safeGrade = (card.gradeLevel || 'صف').replace(/\s+/g, '_');
    const safeSection = (card.section || 'شعبة').replace(/\s+/g, '_');
    link.setAttribute('download', `كشف_درجات_${safeGrade}_${safeSection}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export all visible class cards to Excel (CSV with UTF-8 BOM)
  const handleExportAllExcel = () => {
    const headers = [
      'ت',
      'اسم الطالب',
      'المرحلة / الصف',
      'الشعبة',
      'السنة الدراسية',
      'المادة',
      ...terms.map((t) => `درجة ${t.name}`),
    ];

    let counter = 1;
    const rows: (string | number)[][] = [];

    filteredClassCards.forEach((card) => {
      card.students.forEach((student) => {
        const scores = terms.map((t) => {
          const score = student.termScores[t.id];
          return score !== null && score !== undefined ? score : '';
        });

        rows.push([
          counter++,
          `"${student.name}"`,
          `"${card.gradeLevel || '—'}"`,
          `"${card.section || '—'}"`,
          `"${defaultAcademicYear}"`,
          `"${defaultSubject}"`,
          ...scores,
        ]);
      });
    });

    const csvContent =
      '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `كشف_درجات_كافة_الصفوف.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getMarginCssValue = () => {
    switch (printSettings.margin) {
      case 'narrow':
        return '5mm';
      case 'wide':
        return '15mm';
      case 'custom':
        return `${Math.max(2, Math.min(30, printSettings.customMarginMm || 10))}mm`;
      case 'normal':
      default:
        return '10mm';
    }
  };

  // Print all visible cards
  const handlePrintAll = () => {
    setSelectedCardForModal(null);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  // Print single class card
  const handlePrintSingleClass = (card: ClassSectionCard) => {
    setSelectedCardForModal(card);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  // If no terms exist yet in the system
  if (terms.length === 0) {
    return (
      <div className="space-y-6 max-w-5xl mx-auto">
        <div className="bg-[#4E7A68] rounded-2xl p-6 text-white shadow-md border border-[#3B6554]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 text-white flex items-center justify-center shrink-0">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">كروت درجات الصفوف</h2>
              <p className="text-xs text-white/90 mt-1">
                عرض كروت درجات الفصول لكل صف وشعبة مع إمكانية التصدير والطباعة
              </p>
            </div>
          </div>
        </div>

        <div className="bg-[#FAF7EC] rounded-2xl border border-[#D8CEBD] p-8 sm:p-12 text-center max-w-xl mx-auto shadow-xs">
          <div className="w-14 h-14 bg-[#E8D7C2] text-[#8C6544] rounded-2xl flex items-center justify-center mx-auto mb-4 border border-[#C2A88F]">
            <AlertCircle className="w-7 h-7" />
          </div>
          <h3 className="text-base sm:text-lg font-black text-[#2F2822] mb-2">
            لم يتم إنشاء أي فصول درجات بعد
          </h3>
          <p className="text-xs sm:text-sm text-[#7A6E61] mb-6 leading-relaxed">
            لعرض كروت درجات الصفوف، يرجى الانتقال إلى صفحة <strong>(المعدل)</strong> أولاً وإنشاء فصل دراسي (مثل: الفصل الأول، الفصل الثاني).
          </p>
          {onNavigateToTerms && (
            <button
              type="button"
              onClick={onNavigateToTerms}
              className="inline-flex items-center gap-2 px-5 py-2.5 craft-btn-primary text-white rounded-xl text-xs sm:text-sm font-bold transition-all shadow-md active:scale-95 cursor-pointer"
            >
              <span>الانتقال لصفحة المعدل لإنشاء فصل</span>
              <ArrowRight className="w-4 h-4 rotate-180" />
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      {/* Dynamic Print CSS */}
      <style
        dangerouslySetInnerHTML={{
          __html: `
            @media print {
              @page {
                size: ${printSettings.orientation === 'landscape' ? 'landscape' : 'portrait'};
                margin: ${getMarginCssValue()};
              }
              body {
                background: #ffffff !important;
                color: #000000 !important;
                font-size: 11pt !important;
              }
              .no-print,
              button,
              header,
              nav,
              .print\\:hidden {
                display: none !important;
              }
              ${
                selectedCardForModal
                  ? `
                .report-cards-print-grid {
                  display: none !important;
                }
                .single-card-modal-content {
                  box-shadow: none !important;
                  border: none !important;
                  width: 100% !important;
                  max-width: 100% !important;
                }
                .single-card-modal-backdrop {
                  position: static !important;
                  background: transparent !important;
                  padding: 0 !important;
                }
              `
                  : `
                .single-card-modal-backdrop {
                  display: none !important;
                }
              `
              }
              .report-cards-print-grid > div,
              .student-table-card {
                break-inside: avoid !important;
                page-break-inside: avoid !important;
                margin-bottom: 24px !important;
                border: 2px solid #000000 !important;
                box-shadow: none !important;
                background: #fff !important;
              }
              .student-table-card table,
              .student-table-card th,
              .student-table-card td {
                border: 1px solid #000000 !important;
                color: #000000 !important;
              }
              .student-table-card th {
                background: #f1f5f9 !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
            }
          `,
        }}
      />

      {/* 1. Top Term Names Display: Only displays names of terms created in "المعدل" - Sage Green Theme */}
      <div className="bg-[#4E7A68] rounded-2xl p-4 sm:p-5 text-white shadow-md border border-[#3B6554] space-y-3 no-print">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 text-white flex items-center justify-center shrink-0">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                <span>فصول الدرجات المعتمدة في المعدل</span>
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-white/20 text-white border border-white/30">
                  {terms.length} {terms.length === 1 ? 'فصل' : 'فصول'}
                </span>
              </h2>
              <p className="text-xs text-white/90 mt-0.5">
                تظهر هنا أسماء الفصول المعرفة في صفحة المعدل، وتُعرض درجاتها مباشرة لكل صف وشعبة أدناه.
              </p>
            </div>
          </div>
        </div>

        {/* Display the names of the terms created in the "المعدل" page */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          {terms.map((t) => (
            <div
              key={t.id}
              className="px-3.5 py-1.5 rounded-xl bg-white/15 border border-white/25 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-2xs select-none"
            >
              <span className="w-2 h-2 rounded-full bg-amber-300"></span>
              <span>{t.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Top Filter Bar by Grade (الصف / المرحلة) and Section (الشعبة), plus Search and Action Buttons */}
      <div className="bg-[#FAF7EC] p-3 sm:p-4 rounded-2xl border border-[#D8CEBD] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 no-print">
        <div className="flex flex-wrap items-center gap-2.5 flex-1">
          {/* Search by student name or class */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
            <input
              type="text"
              placeholder="بحث باسم الطالب أو الصف..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-9 pl-3 py-1.5 bg-white border border-[#D8CEBD] rounded-xl text-xs sm:text-sm font-medium focus:bg-white focus:ring-2 focus:ring-[#4E7A68] focus:outline-none"
            />
          </div>

          {/* Grade Level (المرحلة / الصف) Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-600 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <span>الصف / المرحلة:</span>
            </span>
            <select
              value={selectedGradeLevel}
              onChange={(e) => setSelectedGradeLevel(e.target.value)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-none cursor-pointer hover:bg-slate-100"
            >
              <option value="ALL">جميع الصفوف والمراحل</option>
              {allGradeLevels.map((g) => (
                <option key={g} value={g}>
                  {g || 'غير محدد'}
                </option>
              ))}
            </select>
          </div>

          {/* Section (الشعبة) Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-600">الشعبة:</span>
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-none cursor-pointer hover:bg-slate-100"
            >
              <option value="ALL">جميع الشُعب</option>
              {allSections.map((sec) => (
                <option key={sec} value={sec}>
                  الشعبة ({sec || 'غير محدد'})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-between md:justify-end gap-2 shrink-0 flex-wrap">
          {/* View Mode Toggle: Class Cards vs Master Table */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              className={`p-1.5 px-2.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                viewMode === 'cards'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="عرض كروت الصفوف والشُعب"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>كروت الصفوف</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`p-1.5 px-2.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="عرض كشف جدول شامل لكافة الطلاب"
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>جدول مجمع</span>
            </button>
          </div>

          <span className="text-xs font-semibold text-slate-600 hidden sm:inline px-1">
            {filteredClassCards.length} كارت صف • {totalFilteredStudents} طالب
          </span>

          {/* Export Excel Button for all filtered cards */}
          <button
            type="button"
            onClick={handleExportAllExcel}
            className="p-2 sm:px-3 sm:py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer active:scale-95"
            title="تصدير كشف درجات كافة الصفوف بصيغة Excel"
            aria-label="تصدير كشف درجات كافة الصفوف بصيغة Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline">تصدير إكسل</span>
          </button>

          {/* Print Customization Button */}
          <button
            type="button"
            onClick={() => setIsPrintSettingsOpen(true)}
            className="p-2 sm:px-3 sm:py-1.5 bg-white hover:bg-[#F2ECE0] text-[#554A3E] border border-[#D8CEBD] rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer active:scale-95"
            title="تخصيص الهوامش وشعار المدرسة"
            aria-label="تخصيص الهوامش وشعار المدرسة"
          >
            <Sliders className="w-4 h-4 text-[#4E7A68]" />
            <span className="hidden sm:inline">تخصيص الطباعة</span>
          </button>

          {/* Print All Cards Button */}
          <button
            type="button"
            onClick={handlePrintAll}
            className="px-3.5 py-1.5 bg-[#4E7A68] hover:bg-[#3B6554] border border-[#3B6554] text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer active:scale-95"
            title="طباعة كروت كافة الصفوف المعروضة"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة كافة الكروت</span>
          </button>
        </div>
      </div>

      {/* 3. Main Content: Class Cards View (each card has students of that class & section) */}
      {viewMode === 'cards' ? (
        <div
          className={`grid grid-cols-1 xl:grid-cols-2 gap-4 sm:gap-5 report-cards-print-grid ${
            selectedCardForModal ? 'print:hidden' : ''
          }`}
        >
          {filteredClassCards.length === 0 ? (
            <div className="col-span-full bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-400">
              لا توجد صفوف أو شُعب مطابقة لخيارات الفلترة والبحث.
            </div>
          ) : (
            filteredClassCards.map((card) => (
              <ReportCardItem
                key={card.id}
                classCard={card}
                terms={terms}
                profile={profile}
                academicYear={defaultAcademicYear}
                subject={defaultSubject}
                printSettings={printSettings}
                searchQuery={searchQuery}
                onPreview={() => setSelectedCardForModal(card)}
                onPrint={() => handlePrintSingleClass(card)}
                onExportExcel={() => handleExportClassExcel(card)}
              />
            ))
          )}
        </div>
      ) : (
        /* Consolidated Master Table View across all classes */
        <div className="bg-white rounded-2xl border border-slate-300 shadow-sm overflow-hidden student-table-card">
          <div className="bg-slate-50 p-3.5 border-b border-slate-300 flex items-center justify-between">
            <div className="flex items-center gap-3 text-xs font-bold text-slate-800">
              <span>
                السنة الدراسية: <strong className="text-slate-900">{defaultAcademicYear}</strong>
              </span>
              <span>•</span>
              <span>
                المادة: <strong className="text-slate-900">{defaultSubject}</strong>
              </span>
            </div>
            <span className="text-xs text-slate-600 font-bold">
              {totalFilteredStudents} طالب في {filteredClassCards.length} كارت صف
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center border-collapse border border-slate-300 text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-900 font-black border-b border-slate-300">
                  <th className="py-2.5 px-3 border-r border-slate-300 w-12">#</th>
                  <th className="py-2.5 px-3 border-r border-slate-300 text-right min-w-[150px]">
                    اسم الطالب
                  </th>
                  <th className="py-2.5 px-2.5 border-r border-slate-300">الصف / المرحلة</th>
                  <th className="py-2.5 px-2.5 border-r border-slate-300">الشعبة</th>
                  {terms.map((t) => (
                    <th key={t.id} className="py-2.5 px-3 border-r border-slate-300 text-center">
                      درجة {t.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {totalFilteredStudents === 0 ? (
                  <tr>
                    <td colSpan={4 + terms.length} className="py-8 text-center text-slate-400">
                      لا يوجد طلاب مطابقون لخيارات الفلترة والبحث.
                    </td>
                  </tr>
                ) : (
                  (() => {
                    let studentIdx = 1;
                    return filteredClassCards.flatMap((card) =>
                      card.students.map((student) => (
                        <tr
                          key={`${card.id}-${student.id}`}
                          className={`border-b border-slate-200 transition-colors ${
                            studentIdx % 2 === 0 ? 'bg-white' : 'bg-slate-50/60'
                          }`}
                        >
                          <td className="py-2.5 px-3 border-r border-slate-300 text-slate-500 font-semibold">
                            {studentIdx++}
                          </td>
                          <td className="py-2.5 px-3 border-r border-slate-300 text-right font-bold text-slate-900">
                            {student.name}
                          </td>
                          <td className="py-2.5 px-2.5 border-r border-slate-300 text-slate-800 font-medium">
                            {card.gradeLevel || '—'}
                          </td>
                          <td className="py-2.5 px-2.5 border-r border-slate-300 text-slate-800 font-medium">
                            {card.section || '—'}
                          </td>
                          {terms.map((t) => {
                            const score = student.termScores[t.id];
                            return (
                              <td
                                key={t.id}
                                className="py-2.5 px-3 border-r border-slate-300 text-center font-bold text-slate-900"
                              >
                                {score !== null && score !== undefined ? (
                                  score
                                ) : (
                                  <span className="text-slate-400 font-normal">—</span>
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      ))
                    );
                  })()
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. Single Class/Section Card Preview Modal */}
      {selectedCardForModal && (
        <StudentCardModal
          isOpen={!!selectedCardForModal}
          onClose={() => setSelectedCardForModal(null)}
          classCard={selectedCardForModal}
          terms={terms}
          profile={profile}
          academicYear={defaultAcademicYear}
          subject={defaultSubject}
          printSettings={printSettings}
        />
      )}

      {/* 5. Print Settings & Customization Modal */}
      {isPrintSettingsOpen && (
        <PrintSettingsModal
          isOpen={isPrintSettingsOpen}
          onClose={() => setIsPrintSettingsOpen(false)}
          settings={printSettings}
          onUpdateSettings={handleUpdateSettings}
          profile={profile}
          onUpdateProfile={handleUpdateProfile}
          sampleClassCard={filteredClassCards[0] || classCards[0]}
          terms={terms}
          academicYear={defaultAcademicYear}
          subject={defaultSubject}
          onStartPrint={() => {
            setIsPrintSettingsOpen(false);
            handlePrintAll();
          }}
          totalCardsCount={filteredClassCards.length}
        />
      )}
    </div>
  );
};
