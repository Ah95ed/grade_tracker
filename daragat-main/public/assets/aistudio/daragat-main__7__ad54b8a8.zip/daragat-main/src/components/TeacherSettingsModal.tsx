import React, { useState, useEffect, useRef } from 'react';
import { TeacherProfile } from '../types';
import { isTestProfile } from '../utils/storage';
import { X, UserCheck, Check, Upload, Trash2, Image as ImageIcon } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  profile: TeacherProfile;
  onSave: (updated: TeacherProfile) => void;
}

export const TeacherSettingsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  profile,
  onSave,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sanitizeProfile = (p: TeacherProfile): TeacherProfile => {
    if (isTestProfile(p)) {
      return {
        teacherName: '',
        schoolName: '',
        subject: '',
        academicYear: p.academicYear?.trim() || '2024 - 2025',
        governorate: '',
        schoolLogo: '',
      };
    }
    return {
      teacherName: p.teacherName || '',
      schoolName: p.schoolName || '',
      subject: p.subject || '',
      academicYear: p.academicYear?.trim() || '2024 - 2025',
      governorate: p.governorate || '',
      schoolLogo: p.schoolLogo || '',
    };
  };

  // Academic year appears automatically by default: "2024 - 2025", other fields empty if test data
  const [formData, setFormData] = useState<TeacherProfile>(() => sanitizeProfile(profile));

  useEffect(() => {
    if (isOpen) {
      setFormData(sanitizeProfile(profile));
    }
  }, [isOpen, profile]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Formatter for Academic Year (e.g. typing 2025 automatically inserts " - " to become "2025 - ")
  const formatAcademicYear = (raw: string, prevRaw: string = ''): string => {
    // Convert Arabic numerals to standard digits
    const converted = raw.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d).toString());
    const digits = converted.replace(/\D/g, '');

    if (!digits) return '';

    if (digits.length < 4) {
      return digits;
    }

    if (digits.length === 4) {
      // If user was deleting back into the first year, don't immediately re-append " - "
      if (prevRaw && prevRaw.length > raw.length && prevRaw.startsWith(digits)) {
        return digits;
      }
      return `${digits} - `;
    }

    const y1 = digits.slice(0, 4);
    const y2 = digits.slice(4, 8);
    return `${y1} - ${y2}`;
  };

  const handleAcademicYearKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      const current = formData.academicYear || '';
      if (current.endsWith(' - ') || current.endsWith('- ') || current.endsWith(' -')) {
        e.preventDefault();
        const stripped = current.replace(/\s*-\s*$/, '');
        setFormData((prev) => ({ ...prev, academicYear: stripped }));
      }
    }
  };

  const handleAcademicYearChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    const formatted = formatAcademicYear(val, formData.academicYear || '');
    setFormData((prev) => ({ ...prev, academicYear: formatted }));
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const src = event.target?.result as string;
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 320;
        let w = img.width;
        let h = img.height;
        if (w > maxDim || h > maxDim) {
          if (w > h) {
            h = Math.round((h * maxDim) / w);
            w = maxDim;
          } else {
            w = Math.round((w * maxDim) / h);
            h = maxDim;
          }
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, w, h);
          const dataUrl = canvas.toDataURL('image/png', 0.9);
          setFormData((prev) => ({ ...prev, schoolLogo: dataUrl }));
        }
      };
      img.src = src;
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveLogo = () => {
    setFormData((prev) => ({ ...prev, schoolLogo: '' }));
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      teacherName: formData.teacherName.trim(),
      schoolName: formData.schoolName.trim(),
      subject: formData.subject.trim(),
      academicYear: formData.academicYear?.trim() || '2024 - 2025',
      governorate: formData.governorate?.trim() || '',
      schoolLogo: formData.schoolLogo || '',
    });
    onClose();
  };

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-3 sm:p-4 animate-in fade-in duration-200"
    >
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-lg max-h-[90dvh] flex flex-col overflow-hidden my-auto">
        {/* Header (Matching user's photo with indigo gradient) */}
        <div className="shrink-0 px-6 py-4 bg-gradient-to-l from-indigo-700 via-indigo-800 to-indigo-900 text-white flex items-center justify-between">
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onClose();
            }}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3 text-right">
            <div>
              <h3 className="text-lg sm:text-xl font-bold tracking-tight">بيانات المعلم والمدرسة</h3>
              <p className="text-xs text-indigo-200 mt-0.5">
                تظهر هذه البيانات في ترويسة الجداول وبطاقات درجات الطلاب الرسمية
              </p>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center text-white shrink-0">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Content Form (Scrollable body) */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4 text-right">
          {/* Field 1: اسم المعلم / المدرس */}
          <div>
            <label className="block text-sm font-bold text-slate-800 mb-1.5">
              اسم المعلم / المدرس
            </label>
            <div className="relative">
              <input
                type="text"
                value={formData.teacherName}
                onChange={(e) =>
                  setFormData({ ...formData, teacherName: e.target.value })
                }
                placeholder="اكتب اسم المعلم أو المدرس"
                className="w-full px-4 py-3 bg-[#f8fafc] border border-slate-300 rounded-2xl text-slate-900 text-sm font-bold placeholder:text-slate-400 focus:bg-white focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none transition-all"
                required
              />
            </div>
          </div>

          {/* Row 2: اسم المدرسة / الثانوية & المادة الدراسية */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-slate-800 mb-1.5">
                اسم المدرسة / الثانوية
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={formData.schoolName}
                  onChange={(e) =>
                    setFormData({ ...formData, schoolName: e.target.value })
                  }
                  placeholder="اكتب اسم المدرسة"
                  className="w-full px-4 py-3 bg-[#f8fafc] border border-slate-300 rounded-2xl text-slate-900 text-sm font-semibold placeholder:text-slate-400 focus:bg-white focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none transition-all"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-800 mb-1.5">
                المادة الدراسية
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={formData.subject}
                  onChange={(e) =>
                    setFormData({ ...formData, subject: e.target.value })
                  }
                  placeholder="مثال: الرياضيات، الا..."
                  className="w-full px-4 py-3 bg-[#f8fafc] border border-slate-300 rounded-2xl text-slate-900 text-sm font-semibold placeholder:text-slate-400 focus:bg-white focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none transition-all"
                  required
                />
              </div>
            </div>
          </div>

          {/* Row 3: العام الدراسي & المحافظة / المديرية العامة */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-slate-800 mb-1.5">
                العام الدراسي
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={formData.academicYear || ''}
                  onChange={handleAcademicYearChange}
                  onKeyDown={handleAcademicYearKeyDown}
                  placeholder="2024 - 2025"
                  className="w-full px-4 py-3 bg-[#f8fafc] border border-slate-300 rounded-2xl text-slate-900 text-sm font-semibold placeholder:text-slate-400 focus:bg-white focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none transition-all text-center dir-ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-800 mb-1.5">
                المحافظة / المديرية العامة
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={formData.governorate || ''}
                  onChange={(e) =>
                    setFormData({ ...formData, governorate: e.target.value })
                  }
                  placeholder="مثال: بغداد / الكرخ..."
                  className="w-full px-4 py-3 bg-[#f8fafc] border border-slate-300 rounded-2xl text-slate-900 text-sm font-semibold placeholder:text-slate-400 focus:bg-white focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none transition-all"
                />
              </div>
            </div>
          </div>

          {/* Section: شعار المدرسة / المؤسسة التعليمية */}
          <div className="p-3.5 bg-slate-50/90 border border-slate-200 rounded-2xl space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <label className="block text-sm font-bold text-slate-800">
                  شعار المدرسة (اختياري)
                </label>
                <p className="text-xs text-slate-500">
                  يُطبع أعلى كروت النتائج والشهادات لإضفاء طابع رسمي أنيق
                </p>
              </div>
              {formData.schoolLogo && (
                <button
                  type="button"
                  onClick={handleRemoveLogo}
                  className="px-2 py-1 text-xs text-red-600 hover:bg-red-50 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                  title="حذف الشعار"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>حذف الشعار</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-3 pt-0.5">
              {formData.schoolLogo ? (
                <div className="w-13 h-13 rounded-xl border border-slate-200 bg-white p-1 flex items-center justify-center shrink-0 shadow-2xs overflow-hidden">
                  <img
                    src={formData.schoolLogo}
                    alt="شعار المدرسة"
                    className="max-h-full max-w-full object-contain"
                  />
                </div>
              ) : (
                <div className="w-13 h-13 rounded-xl border-2 border-dashed border-slate-300 bg-white flex items-center justify-center text-slate-400 shrink-0">
                  <ImageIcon className="w-6 h-6 stroke-1 text-slate-400" />
                </div>
              )}

              <div className="flex-1">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleLogoUpload}
                  accept="image/png, image/jpeg, image/webp, image/svg+xml"
                  className="hidden"
                  id="teacher-school-logo-file"
                />
                <label
                  htmlFor="teacher-school-logo-file"
                  className="inline-flex items-center gap-2 px-3 py-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 cursor-pointer shadow-2xs transition-all active:scale-98"
                >
                  <Upload className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{formData.schoolLogo ? 'تغيير الشعار' : 'اختيار صورة الشعار'}</span>
                </label>
                <span className="block text-[11px] text-slate-400 mt-1">
                  صيغ PNG, JPG, WebP أو SVG
                </span>
              </div>
            </div>
          </div>

          {/* Footer (Matching photo: save button on left, cancel on right) */}
          <div className="shrink-0 pt-4 border-t border-slate-200 flex items-center justify-between">
            <button
              type="submit"
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white rounded-2xl font-bold text-sm shadow-md shadow-indigo-400/30 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>حفظ البيانات</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onClose();
              }}
              className="px-5 py-2.5 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-xl font-bold text-sm transition-colors cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
