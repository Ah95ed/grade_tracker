import React, { useState, useMemo, useEffect } from 'react';
import { MonthlyModel, TermModel, TeacherProfile, RoundingMode } from '../../types';
import {
  calculateTermSummaries,
} from '../../utils/gradeCalculations';
import {
  Calculator,
  CheckCircle2,
  Calendar,
  Layers,
  FileSpreadsheet,
  Printer,
  Sparkles,
  Users,
  Award,
  TrendingUp,
  Plus,
  Trash2,
  Search,
  X,
  Pencil,
  Check,
  Eye,
  EyeOff,
  User,
  ChevronDown,
} from 'lucide-react';
import { ConfirmDeleteModal } from '../Common/ConfirmDeleteModal';
import { ScoreRoundingModal } from '../MonthlySheet/ScoreRoundingModal';
import { StudentFloatingCloud, ActiveStudentCloudInfo } from '../Common/StudentFloatingCloud';
import { ColumnSlant, getSlantClasses, getNextSlant, SlantButton } from '../Common/ColumnSlantToggle';

interface Props {
  terms: TermModel[];
  activeTermId: string;
  onSelectTerm: (id: string) => void;
  onUpdateTerm: (updatedTerm: TermModel) => void;
  onUpdateAllTerms?: (updatedTerms: TermModel[]) => void;
  onAddTerm: (newTerm: TermModel) => void;
  onDeleteTerm: (id: string) => void;
  monthlyModels: MonthlyModel[];
  profile: TeacherProfile;
}

export const TermCalculationView: React.FC<Props> = ({
  terms,
  activeTermId,
  onSelectTerm,
  onUpdateTerm,
  onUpdateAllTerms,
  onAddTerm,
  onDeleteTerm,
  monthlyModels,
  profile,
}) => {
  const currentTerm = terms.find((t) => t.id === activeTermId) || terms[0];

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGradeLevel, setSelectedGradeLevel] = useState('ALL');
  const [selectedSection, setSelectedSection] = useState('ALL');

  // Column header slant/orientation (normal | italic | vertical)
  const [columnSlants, setColumnSlants] = useState<Record<string, ColumnSlant>>(() => {
    try {
      const saved = localStorage.getItem(`daragat_term_slants_${currentTerm.id}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const toggleColumnSlant = (colKey: string) => {
    setColumnSlants((prev) => {
      const next = getNextSlant(prev[colKey]);
      const updated = { ...prev, [colKey]: next };
      try {
        localStorage.setItem(`daragat_term_slants_${currentTerm.id}`, JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };
  const [activeStudentCloud, setActiveStudentCloud] = useState<ActiveStudentCloudInfo | null>(null);
  const activeRowRef = React.useRef<HTMLTableRowElement | null>(null);
  const tableContainerRef = React.useRef<HTMLDivElement | null>(null);
  const [isNameColumnVisible, setIsNameColumnVisible] = useState(true);

  // Check if student name column is visible within the table container during horizontal scroll
  const checkNameColumnVisibility = React.useCallback(() => {
    if (!tableContainerRef.current) return;
    const container = tableContainerRef.current;
    const nameCell = container.querySelector('[data-student-name-column="true"]') as HTMLElement | null;
    if (!nameCell) return;
    const nameRect = nameCell.getBoundingClientRect();
    const containerRect = container.getBoundingClientRect();

    const visibleLeft = Math.max(nameRect.left, containerRect.left);
    const visibleRight = Math.min(nameRect.right, containerRect.right);
    const visibleWidth = Math.max(0, visibleRight - visibleLeft);

    setIsNameColumnVisible(visibleWidth >= 60);
  }, []);

  // Keep floating badge locked with row vertically during scroll & update visibility
  useEffect(() => {
    const handleScrollOrResize = () => {
      if (activeRowRef.current && activeStudentCloud) {
        const rect = activeRowRef.current.getBoundingClientRect();
        setActiveStudentCloud((prev) => (prev ? { ...prev, rowTop: rect.top } : null));
      }
      checkNameColumnVisibility();
    };

    checkNameColumnVisibility();

    window.addEventListener('scroll', handleScrollOrResize, true);
    window.addEventListener('resize', handleScrollOrResize);
    return () => {
      window.removeEventListener('scroll', handleScrollOrResize, true);
      window.removeEventListener('resize', handleScrollOrResize);
    };
  }, [activeStudentCloud, checkNameColumnVisibility]);

  // Dismiss floating badge when clicking outside the table
  useEffect(() => {
    if (!activeStudentCloud) return;

    const handlePointerDownOutside = (event: MouseEvent | TouchEvent) => {
      const target = event.target as HTMLElement | null;
      if (!target) return;

      if (tableContainerRef.current?.contains(target)) return;
      if (target.closest?.('[data-student-floating-cloud="true"]')) return;
      if (target.closest?.('[data-floating-cloud-toggle="true"]')) return;

      setActiveStudentCloud(null);
    };

    document.addEventListener('pointerdown', handlePointerDownOutside);
    return () => {
      document.removeEventListener('pointerdown', handlePointerDownOutside);
    };
  }, [activeStudentCloud]);

  const [isAddingNewTerm, setIsAddingNewTerm] = useState(false);
  const [newTermName, setNewTermName] = useState('');
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isRoundingModalOpen, setIsRoundingModalOpen] = useState(false);

  // Rating Column visibility preference (hidden by default)
  const [showRatingColumn, setShowRatingColumn] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gradebook_show_rating_col') === 'true';
    } catch {
      return false;
    }
  });

  const toggleRatingColumn = () => {
    setShowRatingColumn((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('gradebook_show_rating_col', String(next));
      } catch (e) {
        console.error(e);
      }
      return next;
    });
  };

  // Edit Term Name states
  const [isEditingTermName, setIsEditingTermName] = useState(false);
  const [editTermNameValue, setEditTermNameValue] = useState('');

  const handleOpenEditTermName = () => {
    if (!currentTerm) return;
    setEditTermNameValue(currentTerm.name);
    setIsEditingTermName(true);
  };

  const handleSaveTermName = () => {
    if (!currentTerm || !editTermNameValue.trim()) return;
    onUpdateTerm({
      ...currentTerm,
      name: editTermNameValue.trim(),
    });
    setIsEditingTermName(false);
  };

  const handleCreateTerm = () => {
    if (!newTermName.trim()) return;
    const newTerm: TermModel = {
      id: 'term-' + Date.now(),
      name: newTermName.trim(),
      selectedModelIds: monthlyModels.slice(0, 2).map((m) => m.id),
      calculationMode: monthlyModels.length > 1 ? 'average' : 'single',
      notes: '',
    };
    onAddTerm(newTerm);
    setNewTermName('');
    setIsAddingNewTerm(false);
  };

  const handleOpenAddTerm = () => {
    const nextNum = terms.length + 1;
    const suggested =
      nextNum === 1 ? 'الفصل الأول' : nextNum === 2 ? 'الفصل الثاني' : nextNum === 3 ? 'الفصل الثالث' : `الفصل ${nextNum}`;
    setNewTermName(suggested);
    setIsAddingNewTerm(true);
  };

  // Self-heal and sync term's selectedModelIds so phantom or deleted model IDs are never counted
  // CRITICAL: Must be placed BEFORE any early return to satisfy React Rules of Hooks!
  React.useEffect(() => {
    if (!currentTerm || monthlyModels.length === 0) return;
    const validIds = Array.from(
      new Set(
        currentTerm.selectedModelIds.filter((id) =>
          monthlyModels.some((m) => m.id === id)
        )
      )
    );
    const finalIds = validIds.length > 0 ? validIds : [monthlyModels[0].id];

    if (
      finalIds.length !== currentTerm.selectedModelIds.length ||
      finalIds.some((id, idx) => id !== currentTerm.selectedModelIds[idx])
    ) {
      onUpdateTerm({
        ...currentTerm,
        selectedModelIds: finalIds,
        calculationMode: finalIds.length === 1 ? 'single' : 'average',
      });
    }
  }, [currentTerm?.id, monthlyModels]);

  // Memoized student summaries across chosen models (placed before early return to strictly obey React Rules of Hooks!)
  const studentSummaries = useMemo(() => {
    if (!currentTerm) return [];
    return calculateTermSummaries(currentTerm, monthlyModels);
  }, [currentTerm, monthlyModels]);

  // Check if any student in the active term has decimal / fractional scores, or if rounding is configured
  const hasDecimalScores = useMemo(() => {
    if (!studentSummaries || studentSummaries.length === 0) return false;
    const hasRawDecimals = studentSummaries.some((s) => {
      const raw = s.rawTermScore ?? s.finalTermScore;
      if (raw === null || raw === undefined) return false;
      return Math.abs(raw - Math.round(raw)) > 0.001;
    });
    const currentRoundingMode = currentTerm?.roundingMode || 'none';
    return hasRawDecimals || currentRoundingMode !== 'none';
  }, [studentSummaries, currentTerm]);

  const handleSaveRounding = (newMode: RoundingMode, newThreshold: number, applyToAll: boolean) => {
    if (!currentTerm) return;
    if (applyToAll && onUpdateAllTerms) {
      const updated = terms.map((t) => ({
        ...t,
        roundingMode: newMode,
        roundingThreshold: newThreshold,
      }));
      onUpdateAllTerms(updated);
    } else {
      onUpdateTerm({
        ...currentTerm,
        roundingMode: newMode,
        roundingThreshold: newThreshold,
      });
    }
  };

  if (!currentTerm) {
    return (
      <div className="space-y-4">
        {/* Full-width "إضافة فصل جديد مادة ..." button */}
        <div className="no-print">
          <button
            type="button"
            onClick={handleOpenAddTerm}
            className="w-full py-2.5 px-4 bg-[#B86848] hover:bg-[#A05537] border border-[#944D30] active:scale-99 text-white rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
            title={`إضافة فصل دراسي جديد مادة ${profile.subject || 'المادة'}`}
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>إضافة فصل جديد مادة {profile.subject || 'المادة'}</span>
          </button>
        </div>

        <div className="bg-white rounded-2xl border border-[#E8E4DA] p-8 sm:p-12 text-center shadow-xs max-w-lg mx-auto my-8 space-y-4">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-[#EEF4F8] border border-[#D2E0EC] flex items-center justify-center text-[#557A95] shadow-xs">
            <Calendar className="w-8 h-8 text-[#557A95]" />
          </div>
          <div>
            <h2 className="text-xl font-black text-[#2E2B27]">لا يوجد أي فصل دراسي حالياً</h2>
            <p className="text-sm text-[#7A746B] mt-1.5 leading-relaxed">
              صفحة الفصول فارغة حالياً. يمكنك البدء بإضافة أول فصل دراسي (مثل الفصل الأول) واحتساب معدلات الدرجات.
            </p>
          </div>
          <div className="pt-2">
            <button
              type="button"
              onClick={handleOpenAddTerm}
              className="px-6 py-3 bg-[#487B5D] hover:bg-[#3C684E] active:scale-95 text-white rounded-xl text-sm font-bold transition-all shadow-md flex items-center justify-center gap-2 mx-auto"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>+ إضافة فصل دراسي جديد</span>
            </button>
          </div>
        </div>

        {/* Modal for Adding a New Term */}
        {isAddingNewTerm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
            <div className="bg-[#FAF7EC] rounded-2xl shadow-2xl border border-[#D8CEBD] w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-150 text-right">
              <div className="px-5 py-4 bg-[#B86848] text-white flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
                    <Plus className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold">إضافة فصل دراسي جديد</h3>
                    <p className="text-xs text-orange-100">
                      احتساب معدل الدرجات لشهور هذا الفصل تلقائياً
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAddingNewTerm(false)}
                  className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleCreateTerm();
                }}
                className="p-5 space-y-4"
              >
                <div>
                  <label className="block text-xs font-bold text-[#2F2822] mb-1.5">
                    اسم الفصل الدراسي
                  </label>
                  <input
                    type="text"
                    value={newTermName}
                    onChange={(e) => setNewTermName(e.target.value)}
                    placeholder="مثال: الفصل الأول، أو السعي السنوي"
                    className="w-full px-3.5 py-2.5 bg-white border border-[#D8CEBD] rounded-xl text-sm font-bold text-[#2F2822] focus:bg-white focus:ring-2 focus:ring-[#B86848] focus:outline-none"
                    autoFocus
                  />
                </div>

                <div className="pt-2 border-t border-[#E0D5C3] flex items-center justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setIsAddingNewTerm(false)}
                    className="px-4 py-2 text-[#7A6E61] hover:bg-[#EBE3D3] rounded-xl text-xs font-bold transition-colors cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    disabled={!newTermName.trim()}
                    className="px-5 py-2 bg-[#B86848] hover:bg-[#A05537] border border-[#944D30] disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إنشاء الفصل</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Toggle a monthly model in/out of the calculation
  const handleToggleModel = (modelId: string) => {
    // Only consider models that actually exist
    const currentValidSelected = Array.from(
      new Set(
        currentTerm.selectedModelIds.filter((id) =>
          monthlyModels.some((m) => m.id === id)
        )
      )
    );

    let newSelected: string[];
    if (currentValidSelected.includes(modelId)) {
      // Don't deselect if it's the only one
      if (currentValidSelected.length <= 1) {
        return;
      }
      newSelected = currentValidSelected.filter((id) => id !== modelId);
    } else {
      newSelected = [...currentValidSelected, modelId];
    }

    // Auto set calculationMode
    const mode = newSelected.length === 1 ? 'single' : 'average';

    onUpdateTerm({
      ...currentTerm,
      selectedModelIds: newSelected,
      calculationMode: mode,
    });
  };

    // Grade levels & Sections filter
  const allGradeLevels = Array.from(
    new Set(studentSummaries.map((s) => s.gradeLevel).filter(Boolean))
  );
  const allSections = Array.from(
    new Set(studentSummaries.map((s) => s.section).filter(Boolean))
  );

  const filteredSummaries = studentSummaries.filter((s) => {
    const matchName = s.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchGrade = selectedGradeLevel === 'ALL' || s.gradeLevel === selectedGradeLevel;
    const matchSection = selectedSection === 'ALL' || s.section === selectedSection;
    return matchName && matchGrade && matchSection;
  });

  // Analytics
  const validScores = studentSummaries
    .map((s) => s.finalTermScore)
    .filter((score): score is number => score !== null);

  const totalCount = studentSummaries.length;
  const passedCount = validScores.filter(
    (score) => (score / (currentTerm ? 100 : 100)) * 100 >= 50
  ).length;
  const passRate =
    validScores.length > 0 ? Math.round((passedCount / validScores.length) * 100) : 0;
  const avgScore =
    validScores.length > 0
      ? Math.round(
          (validScores.reduce((acc, curr) => acc + curr, 0) / validScores.length) * 10
        ) / 10
      : 0;
  const maxScore = validScores.length > 0 ? Math.max(...validScores) : 0;

  // Selected models objects
  const selectedModelsObj = monthlyModels.filter((m) =>
    currentTerm.selectedModelIds.includes(m.id)
  );

  // Export CSV
  const handleExportCSV = () => {
    const exportGradeLabel = 'الصف الدراسي';
    const exportSectionLabel = 'الشعبة';
    const exportFinalScoreLabel = 'النهائي';

    const headers = [
      'م',
      'اسم الطالب',
      exportGradeLabel,
      exportSectionLabel,
      ...selectedModelsObj.map((m) => `درجة ${m.name}`),
      exportFinalScoreLabel,
      'التقدير',
      'الحالة',
    ];

    const rows = filteredSummaries.map((s, idx) => {
      const monthScores = s.monthlyScores.map((ms) => ms.score ?? '');
      return [
        idx + 1,
        `"${s.name}"`,
        `"${s.gradeLevel}"`,
        `"${s.section}"`,
        ...monthScores,
        s.finalTermScore ?? '',
        `"${s.gradeText}"`,
        s.status === 'passed' ? 'ناجح' : 'راسب',
      ];
    });

    const csvContent =
      '\uFEFF' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `درجات_${currentTerm.name}_المعتمدة.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-3 sm:space-y-4">
      {/* Full-width "إضافة فصل جديد مادة ..." button */}
      <div className="no-print">
        <button
          type="button"
          onClick={handleOpenAddTerm}
          className="w-full py-2.5 px-4 bg-[#B86848] hover:bg-[#A05537] border border-[#944D30] active:scale-99 text-white rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
          title={`إضافة فصل دراسي جديد مادة ${profile.subject || 'الرياضيات'}`}
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>إضافة فصل جديد مادة {profile.subject || 'الرياضيات'}</span>
        </button>
      </div>

      {/* Term Switcher Bar */}
      <div className="bg-[#FAF7EC] p-3.5 rounded-2xl border border-[#D8CEBD] shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          {terms.map((term) => {
            const isActive = term.id === currentTerm.id;
            const termValidCount = monthlyModels.filter((m) =>
              term.selectedModelIds.includes(m.id)
            ).length;

            return (
              <button
                key={term.id}
                onClick={() => onSelectTerm(term.id)}
                className={`px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#B86848] text-white border border-[#944D30] shadow-sm font-black'
                    : 'bg-[#EFE3DC] hover:bg-[#E5D4CB] text-[#4A2818] border border-[#D6BFB2]'
                }`}
              >
                <span>{term.name}</span>
                <span
                  className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                    isActive ? 'bg-white/20 text-white' : 'bg-[#DDC9BD] text-[#4A2818]'
                  }`}
                >
                  {termValidCount === 1
                    ? 'نموذج واحد'
                    : termValidCount === 2
                    ? 'معدل نموذجين'
                    : `معدل ${termValidCount} نماذج`}
                </span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          {/* Edit Term Name Button */}
          <button
            type="button"
            onClick={handleOpenEditTermName}
            className="text-xs text-[#8C4325] hover:text-[#6D3219] bg-[#FAEDE8] hover:bg-[#F5DDD5] border border-[#ECD1C5] px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 font-bold shadow-2xs active:scale-95 cursor-pointer"
            title={`تعديل اسم فصل ${currentTerm.name}`}
            aria-label={`تعديل اسم فصل ${currentTerm.name}`}
          >
            <Pencil className="w-3.5 h-3.5 text-[#8C4325]" />
            <span>تعديل اسم الفصل</span>
          </button>

          {/* Delete Term Button - Always available even if only 1 term remains */}
          <button
            type="button"
            onClick={() => setIsDeleteModalOpen(true)}
            className="text-xs text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 font-bold shadow-2xs active:scale-95 cursor-pointer"
            title={`حذف فصل ${currentTerm.name}`}
            aria-label={`حذف فصل ${currentTerm.name}`}
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-600" />
            <span>حذف فصل {currentTerm.name}</span>
          </button>
        </div>
      </div>

      {/* Model Selection & Auto-Calculation Controller - Terracotta Theme */}
      <div className="bg-[#B86848] rounded-2xl text-white p-5 sm:p-6 shadow-md relative overflow-hidden">
        <div className="relative z-10 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <span className="px-2.5 py-0.5 rounded-md text-xs font-black bg-[#FAF0EB] text-[#7A361D] uppercase">
                صفحة احتساب الدرجات
              </span>
              <h2 className="text-xl sm:text-2xl font-black">{currentTerm.name}</h2>
              <button
                type="button"
                onClick={handleOpenEditTermName}
                className="w-7 h-7 flex items-center justify-center rounded-lg bg-white/15 hover:bg-white/25 text-white transition-colors cursor-pointer"
                title={`تعديل مسمى ${currentTerm.name}`}
                aria-label={`تعديل مسمى ${currentTerm.name}`}
              >
                <Pencil className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Interactive Checkboxes / Cards for choosing Monthly Models */}
          <div className="pt-1">
            <label className="block text-xs font-bold text-orange-100 mb-2">
              حدد النماذج الشهرية المعتمدة لاحتساب درجة ({currentTerm.name}):
              {selectedModelsObj.length > 0 && (
                <span className="text-amber-200 font-black mr-1">
                  ({selectedModelsObj.map((m) => m.name).join(' و ')})
                </span>
              )}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {monthlyModels.map((model) => {
                const isSelected = currentTerm.selectedModelIds.includes(model.id);
                return (
                  <div
                    key={model.id}
                    onClick={() => handleToggleModel(model.id)}
                    className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all flex items-start gap-3 select-none ${
                      isSelected
                        ? 'bg-[#96472A] border-[#F2C5B3] shadow-md text-white'
                        : 'bg-white/10 border-white/20 hover:border-white/40 text-orange-100/90'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-lg border flex items-center justify-center shrink-0 mt-0.5 ${
                        isSelected
                          ? 'bg-[#FAF0EB] border-[#FAF0EB] text-[#7A361D]'
                          : 'border-white/30'
                      }`}
                    >
                      {isSelected && <CheckCircle2 className="w-4 h-4 stroke-[3]" />}
                    </div>
                    <div className="flex-1">
                      <div className="font-bold text-sm text-white">{model.name}</div>
                      <div className="text-[11px] text-orange-100 mt-0.5">
                        {model.students.length} طالب • الدرجة من {model.totalMaxScore}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Analytics Widgets */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-semibold block">طلاب الفصل</span>
            <span className="text-2xl font-black text-slate-900">{totalCount}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-semibold block">نسبة النجاح</span>
            <span className="text-2xl font-black text-emerald-600">{passRate}%</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-semibold block">أعلى معدل</span>
            <span className="text-2xl font-black text-amber-600">{maxScore}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-semibold block">معدل الفصل العام</span>
            <span className="text-2xl font-black text-blue-600">{avgScore}</span>
          </div>
        </div>
      </div>

      {/* Term Grades Table - Excel Style with Warm Craft Theme */}
      <div className="bg-[#FAF7EC] rounded-2xl border border-[#D5C8B2] shadow-xs overflow-hidden">
        {/* Table Title Bar: Full width, Title on the right, Print & Export icons ONLY on the left without student count */}
        <div className="w-full px-3.5 py-3 sm:px-5 sm:py-3.5 bg-[#F8F4EA] border-b border-[#D8CEBD] flex items-center justify-between gap-3 flex-nowrap no-print">
          {/* Right: Clean Term Title */}
          <div className="flex items-center min-w-0">
            <h3 className="text-sm sm:text-base lg:text-lg font-bold text-[#2F2822] truncate flex items-center gap-1.5">
              <span>كشف درجات:</span>
              <span className="text-[#A05537] font-black">{currentTerm?.name || 'الفصل الدراسي'}</span>
            </h3>
          </div>

          {/* Left: Opposite to the title - Student Cloud, Print icon & Download Excel icon */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Toggle Student Info Cloud button */}
            <button
              type="button"
              data-floating-cloud-toggle="true"
              onClick={() => {
                if (activeStudentCloud) {
                  setActiveStudentCloud(null);
                } else if (filteredSummaries.length > 0) {
                  const s = filteredSummaries[0];
                  const firstRow = document.querySelector('tbody tr') as HTMLTableRowElement | null;
                  const rect = firstRow?.getBoundingClientRect();
                  activeRowRef.current = firstRow;
                  setActiveStudentCloud({
                    studentId: s.studentId,
                    name: s.name,
                    section: s.section,
                    rowTop: rect ? rect.top + Math.max(0, (rect.height - 32) / 2) : 200,
                  });
                }
              }}
              className={`px-2.5 py-1.5 sm:py-2 rounded-xl transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer active:scale-95 shrink-0 border ${
                activeStudentCloud
                  ? 'bg-sky-50 text-sky-800 border-sky-300'
                  : 'bg-white text-[#1E293B] hover:text-[#2B6CB0] hover:bg-slate-100 border-[#CBD5E1]'
              }`}
              title="إظهار / إخفاء سحابة اسم الطالب التفاعلية لمتابعة الأسماء أثناء التمرير الأفقي"
              aria-label="سحابة اسم الطالب"
            >
              <User className="w-4 h-4 text-sky-600" />
              <span className="text-xs font-bold hidden md:inline">
                {activeStudentCloud ? 'إخفاء سحابة الطالب' : 'سحابة اسم الطالب'}
              </span>
            </button>

            {/* Print icon only */}
            <button
              type="button"
              onClick={() => window.print()}
              className="p-2 sm:p-2.5 text-[#334155] hover:text-[#2B6CB0] bg-white hover:bg-slate-100 border border-[#CBD5E1] rounded-xl transition-all shadow-2xs flex items-center justify-center cursor-pointer active:scale-95 shrink-0"
              title="طباعة كشف درجات الفصل"
              aria-label="طباعة كشف درجات الفصل"
            >
              <Printer className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-[#2B6CB0]" />
            </button>

            {/* Export Excel icon only */}
            <button
              type="button"
              onClick={handleExportCSV}
              className="p-2 sm:p-2.5 text-[#15803D] hover:text-[#166534] bg-[#F0FDF4] hover:bg-[#DCFCE7] border border-emerald-300 rounded-xl transition-all shadow-2xs flex items-center justify-center cursor-pointer active:scale-95 shrink-0"
              title="تصدير كشف درجات الفصل بصيغة Excel"
              aria-label="تصدير كشف درجات الفصل بصيغة Excel"
            >
              <FileSpreadsheet className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-[#15803D]" />
            </button>
          </div>
        </div>

        <div ref={tableContainerRef} onScroll={checkNameColumnVisibility} className="overflow-x-auto">
          <table className="w-full text-right border-collapse border border-[#CBD5E1] bg-white">
            <thead>
              <tr className="bg-[#F1F5F9] text-[#1E293B] text-xs font-bold">
                <th className="py-2.5 px-3 w-12 text-center align-middle bg-[#F1F5F9] border border-[#CBD5E1] text-[#475569]">
                  <div className="flex items-center justify-center gap-0.5">
                    <span className={getSlantClasses(columnSlants['index'])}>#</span>
                    <SlantButton slant={columnSlants['index']} onToggle={() => toggleColumnSlant('index')} />
                  </div>
                </th>

                {/* Search input directly under "اسم الطالب" heading */}
                <th data-student-name-column="true" className={`py-2 px-3 min-w-[220px] align-top bg-[#F1F5F9] border border-[#CBD5E1] ${columnSlants['studentName'] === 'vertical' ? 'min-w-[70px]' : ''}`}>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <span className={`font-bold text-[#1E293B] ${getSlantClasses(columnSlants['studentName'])}`}>اسم الطالب</span>
                        <SlantButton slant={columnSlants['studentName']} onToggle={() => toggleColumnSlant('studentName')} />
                      </div>
                      {searchQuery && (
                        <button
                          onClick={() => setSearchQuery('')}
                          className="text-[10px] text-[#64748B] hover:text-[#1E293B] print:hidden cursor-pointer"
                        >
                          مسح البحث
                        </button>
                      )}
                    </div>
                    {/* Embedded Search Input */}
                    <div className="relative print:hidden">
                      <Search className="w-3.5 h-3.5 text-[#64748B] absolute right-2.5 top-2 pointer-events-none" />
                      <input
                        type="text"
                        placeholder="بحث بالاسم..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pr-8 pl-2 py-1 bg-white border border-[#CBD5E1] rounded-lg text-xs font-normal focus:border-[#2B6CB0] focus:ring-1 focus:ring-[#2B6CB0] focus:outline-none placeholder:text-[#94A3B8]"
                      />
                    </div>
                  </div>
                </th>

                {/* Grade Level Column Header with inline dynamic title & small triangle */}
                <th className={`py-1.5 px-1 w-auto min-w-[50px] max-w-[85px] print:w-auto print:min-w-0 print:px-0 text-center align-middle bg-[#F1F5F9] border border-[#CBD5E1] ${columnSlants['gradeLevel'] === 'vertical' ? 'min-w-[40px]' : ''}`}>
                  <div className="flex flex-col items-center justify-center gap-1">
                    {/* Screen edit & filter */}
                    <div className="print:hidden flex items-center justify-center w-full">
                      <div className="flex flex-col items-center justify-center gap-1 group/header w-full">
                        {/* Top row: Slant icon above the dropdown */}
                        <div className="flex items-center justify-center">
                          <SlantButton slant={columnSlants['gradeLevel']} onToggle={() => toggleColumnSlant('gradeLevel')} className="p-1" />
                        </div>

                        {/* Relative container with title + small triangle + invisible native select */}
                        <div className="relative inline-flex items-center justify-center gap-1 px-1.5 py-0.5 rounded-lg bg-white/80 hover:bg-white border border-[#CBD5E1] hover:border-[#2B6CB0] shadow-2xs transition-all cursor-pointer group/grade w-full">
                          <span className={`font-bold text-xs text-[#1E293B] whitespace-nowrap truncate ${getSlantClasses(columnSlants['gradeLevel'])}`}>
                            {selectedGradeLevel === 'ALL' ? 'الصف' : selectedGradeLevel}
                          </span>
                          <ChevronDown className="w-3 h-3 text-slate-500 shrink-0 transition-transform group-hover/grade:translate-y-0.5" />
                          <select
                            value={selectedGradeLevel}
                            onChange={(e) => setSelectedGradeLevel(e.target.value)}
                            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                            title="انقر لاختيار الصف أو تصفية الكل"
                          >
                            <option value="ALL">الكل (الصف)</option>
                            {allGradeLevels.map((grd) => (
                              <option key={grd} value={grd}>
                                {grd}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Print Only Header: Strictly ONLY "الصف الدراسي" or selected grade without dropdown/arrow */}
                    <div className="hidden print:block text-center py-1">
                      <span className={`font-bold text-xs text-[#1E293B] ${getSlantClasses(columnSlants['gradeLevel'])}`}>
                        {selectedGradeLevel === 'ALL' ? 'الصف الدراسي' : selectedGradeLevel}
                      </span>
                    </div>
                  </div>
                </th>

                {/* Section Column - Narrow width, vertical "الشعبة" with letter underneath & small triangle, or vertical "كل الشعب" */}
                <th className="py-1 px-0.5 w-auto min-w-[32px] max-w-[42px] print:w-auto print:min-w-0 print:px-0 text-center align-middle bg-[#F1F5F9] border border-[#CBD5E1]">
                  <div className="flex flex-col items-center justify-center">
                    {/* Screen filter */}
                    <div className="print:hidden flex flex-col items-center w-full">
                      <div className="relative flex flex-col items-center justify-center p-1 rounded hover:bg-white/80 transition-colors cursor-pointer group/sec w-full">
                        {selectedSection === 'ALL' ? (
                          /* All Sections: "كل الشعب" displayed vertically */
                          <div className="flex flex-col items-center">
                            <span className="[writing-mode:vertical-rl] rotate-180 font-bold text-xs text-[#1E293B] tracking-wider py-1 select-none leading-tight">
                              كل الشعب
                            </span>
                            <ChevronDown className="w-3 h-3 text-slate-500 mt-0.5 shrink-0 transition-transform group-hover/sec:translate-y-0.5" />
                          </div>
                        ) : (
                          /* Specific Section: "الشعبة" vertically + section letter horizontally underneath */
                          <div className="flex flex-col items-center">
                            <span className="[writing-mode:vertical-rl] rotate-180 font-bold text-xs text-[#1E293B] tracking-wider select-none leading-tight">
                              الشعبة
                            </span>
                            <span className="font-extrabold text-xs text-[#1E293B] mt-0.5 leading-none bg-slate-200/80 px-1 py-0.5 rounded shadow-2xs">
                              {selectedSection}
                            </span>
                            <ChevronDown className="w-2.5 h-2.5 text-slate-500 mt-0.5 shrink-0 transition-transform group-hover/sec:translate-y-0.5" />
                          </div>
                        )}

                        {/* Invisible native select overlay for instant selection */}
                        <select
                          value={selectedSection}
                          onChange={(e) => setSelectedSection(e.target.value)}
                          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                          title="انقر لاختيار وتصفية الشعبة"
                        >
                          <option value="ALL">كل الشعب</option>
                          {allSections.map((sec) => (
                            <option key={sec} value={sec}>
                              شعبة {sec}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Print Only Header: Vertical "كل الشعب" or Vertical "الشعبة" with normal horizontal letter underneath */}
                    <div className="hidden print:flex flex-col items-center justify-center text-center py-0.5 leading-tight">
                      {selectedSection === 'ALL' ? (
                        <span className="[writing-mode:vertical-rl] rotate-180 font-bold text-xs text-[#1E293B] tracking-wider py-1 select-none">
                          كل الشعب
                        </span>
                      ) : (
                        <div className="flex flex-col items-center justify-center">
                          <span className="[writing-mode:vertical-rl] rotate-180 font-bold text-xs text-[#1E293B] tracking-wider select-none">
                            الشعبة
                          </span>
                          <span className="font-bold text-xs text-[#1E293B] mt-0.5 leading-none">
                            {selectedSection}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </th>

                {/* Columns for each selected Monthly Model */}
                {selectedModelsObj.map((model) => (
                  <th
                    key={model.id}
                    className={`py-2.5 px-3 min-w-[130px] print:min-w-0 text-center bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] align-top ${columnSlants[model.id] === 'vertical' ? 'min-w-[50px]' : ''}`}
                  >
                    <div className="flex items-center justify-center gap-1 font-bold">
                      <span className={getSlantClasses(columnSlants[model.id])}>درجة {model.name}</span>
                      <SlantButton slant={columnSlants[model.id]} onToggle={() => toggleColumnSlant(model.id)} />
                    </div>
                    <div className="text-[10px] text-[#64748B] font-normal mt-0.5 print:hidden">
                      (النهائية: {model.totalMaxScore})
                    </div>
                  </th>
                ))}

                {/* The Calculated Term Grade Column - In print strictly ONLY "النهائي" */}
                <th className={`py-2.5 px-3 min-w-[170px] print:min-w-0 bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] text-center font-bold align-top ${columnSlants['finalTermScore'] === 'vertical' ? 'min-w-[50px]' : ''}`}>
                  {/* Screen Title */}
                  <div className="flex items-center justify-center gap-1 print:hidden">
                    <Sparkles className="w-3.5 h-3.5 text-[#2B6CB0]" />
                    <span className={getSlantClasses(columnSlants['finalTermScore'])}>درجة {currentTerm.name} المحسوبة</span>
                    <SlantButton slant={columnSlants['finalTermScore']} onToggle={() => toggleColumnSlant('finalTermScore')} />
                  </div>
                  <div className="text-[10px] text-[#64748B] font-normal mt-0.5 print:hidden">
                    {currentTerm.selectedModelIds.length === 2
                      ? '(معدل الشهرين تلقائياً)'
                      : '(الدرجة المعتمدة)'}
                  </div>

                  {/* Print Only Title: Strictly ONLY "النهائي" */}
                  <div className="hidden print:block text-center py-1">
                    <span className={`font-bold text-xs text-[#1E293B] ${getSlantClasses(columnSlants['finalTermScore'])}`}>
                      النهائي
                    </span>
                  </div>

                  {/* Sub-toolbar: Rounding & Rating Toggle - STRICTLY HIDDEN ON PRINT */}
                  <div className="pt-1 mt-1 border-t border-[#CBD5E1] flex items-center justify-between gap-1 text-[10px] print:hidden">
                    {/* Rounding button inside header */}
                    <button
                      type="button"
                      onClick={() => setIsRoundingModalOpen(true)}
                      className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold transition-all border flex items-center gap-1 shadow-2xs cursor-pointer ${
                        currentTerm.roundingMode && currentTerm.roundingMode !== 'none'
                          ? 'bg-amber-50 text-[#854D0E] border-amber-300 hover:bg-amber-100'
                          : 'bg-white text-[#854D0E] border-[#CBD5E1] hover:bg-slate-50'
                      }`}
                      title="التحكم بالنسب وقواعد جبر الكسور العشرية"
                    >
                      <Calculator className="w-3.5 h-3.5 text-[#854D0E]" />
                      <span>
                        {currentTerm.roundingMode === 'half_up'
                          ? 'جبر: ≥0.5'
                          : currentTerm.roundingMode === 'any_fraction'
                          ? 'جبر: ≥0.1'
                          : currentTerm.roundingMode === 'custom_threshold'
                          ? `جبر: ≥${currentTerm.roundingThreshold}`
                          : 'التحكم بالنسب العشرية'}
                      </span>
                    </button>

                    {/* Toggle Rating button inside header */}
                    <button
                      type="button"
                      onClick={toggleRatingColumn}
                      className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold transition-all border flex items-center gap-1 shadow-2xs active:scale-95 cursor-pointer ${
                        showRatingColumn
                          ? 'bg-white text-[#15803D] border-emerald-300'
                          : 'bg-white text-[#64748B] border-[#CBD5E1] hover:bg-slate-100'
                      }`}
                      title={showRatingColumn ? 'عمود التقدير ظاهر (انقر للإخفاء)' : 'عمود التقدير مخفي (انقر للإظهار)'}
                    >
                      {showRatingColumn ? (
                        <Eye className="w-3.5 h-3.5 text-[#15803D]" />
                      ) : (
                        <EyeOff className="w-3.5 h-3.5 text-[#64748B]" />
                      )}
                      <span>التقدير: {showRatingColumn ? 'ظاهر' : 'مخفي'}</span>
                    </button>
                  </div>
                </th>

                {/* Rating */}
                {showRatingColumn && (
                  <th className={`py-2.5 px-3 min-w-[100px] print:min-w-0 text-center align-top bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] animate-in fade-in ${columnSlants['gradeText'] === 'vertical' ? 'min-w-[45px]' : ''}`}>
                    <div className="flex items-center justify-center gap-1">
                      <span className={getSlantClasses(columnSlants['gradeText'])}>التقدير</span>
                      <SlantButton slant={columnSlants['gradeText']} onToggle={() => toggleColumnSlant('gradeText')} />
                      <button
                        type="button"
                        onClick={toggleRatingColumn}
                        className="p-0.5 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-200 transition-colors cursor-pointer print:hidden"
                        title="إخفاء عمود التقدير"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  </th>
                )}
                <th className={`py-2.5 px-3 min-w-[85px] print:min-w-0 text-center align-middle bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] ${columnSlants['status'] === 'vertical' ? 'min-w-[45px]' : ''}`}>
                  <div className="flex items-center justify-center gap-1">
                    <span className={getSlantClasses(columnSlants['status'])}>الحالة</span>
                    <SlantButton slant={columnSlants['status']} onToggle={() => toggleColumnSlant('status')} />
                  </div>
                </th>
              </tr>
            </thead>

            <tbody className="text-sm">
              {filteredSummaries.length === 0 ? (
                <tr>
                  <td
                    colSpan={(showRatingColumn ? 6 : 5) + selectedModelsObj.length}
                    className="py-12 text-center text-[#64748B] text-sm border border-[#CBD5E1]"
                  >
                    لا توجد بيانات طلاب مطابقة في هذا الفصل.
                  </td>
                </tr>
              ) : (
                filteredSummaries.map((student, index) => {
                  const isSelected = activeStudentCloud?.studentId === student.studentId;
                  return (
                    <tr
                      key={student.studentId}
                      onClick={(e) => {
                        const rowEl = e.currentTarget;
                        activeRowRef.current = rowEl;
                        const rect = rowEl.getBoundingClientRect();
                        setActiveStudentCloud({
                          studentId: student.studentId,
                          name: student.name,
                          section: student.section,
                          rowTop: rect.top + Math.max(0, (rect.height - 32) / 2),
                        });
                        checkNameColumnVisibility();
                      }}
                      className={`even:bg-[#F8FAFC] odd:bg-white hover:bg-blue-50/40 transition-colors cursor-pointer ${
                        isSelected ? 'bg-sky-50/80 ring-1 ring-sky-300' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3 text-center text-xs font-bold text-[#64748B] border border-[#CBD5E1] bg-[#F8FAFC]">
                        {index + 1}
                      </td>

                      <td className="py-2.5 px-4 font-bold text-[#1E293B] border border-[#CBD5E1]">
                        {student.name}
                      </td>

                      <td className="py-2.5 px-3 text-xs text-[#475569] font-medium border border-[#CBD5E1] text-center">
                        {student.gradeLevel}
                      </td>

                      <td className="py-2.5 px-0.5 text-center border border-[#CBD5E1] w-auto min-w-[34px] max-w-[48px] print:w-auto print:px-0">
                        <span className="px-1.5 py-0.5 bg-slate-100 border border-[#CBD5E1] text-[#1E293B] rounded text-xs font-bold inline-block">
                          {student.section}
                        </span>
                      </td>

                      {/* Display breakdown of each selected month */}
                      {selectedModelsObj.map((model) => {
                        const mScore = student.monthlyScores.find(
                          (ms) => ms.modelId === model.id
                        )?.score;

                        return (
                          <td
                            key={model.id}
                            className="py-2.5 px-3 text-center border border-[#CBD5E1]"
                          >
                            {mScore !== null && mScore !== undefined ? (
                              <span className="font-bold text-[#1E293B] text-sm">
                                {mScore}
                              </span>
                            ) : (
                              <span className="text-slate-400 text-xs">-</span>
                            )}
                          </td>
                        );
                      })}

                      {/* Calculated Final Term Grade */}
                      <td className="py-2.5 px-4 text-center font-black border border-[#CBD5E1]">
                        {student.finalTermScore !== null ? (
                          <div className="flex flex-col items-center justify-center gap-0.5">
                            <span className="text-base font-black text-[#1E293B] px-3 py-0.5 bg-slate-100 rounded-lg inline-block min-w-[55px] border border-slate-200">
                              {student.finalTermScore}
                            </span>
                            {student.isRounded && student.rawTermScore !== null && student.rawTermScore !== undefined && (
                              <span
                                className="text-[10px] text-[#854D0E] font-bold"
                                title={`الدرجة قبل جبر الكسور كانت ${student.rawTermScore}`}
                              >
                                (أصله: {student.rawTermScore})
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-[#64748B] text-xs">غير مرصود</span>
                        )}
                      </td>

                      {/* Rating */}
                      {showRatingColumn && (
                        <td className="py-2.5 px-3 text-center border border-[#CBD5E1] animate-in fade-in">
                          <span
                            className={`text-xs px-2.5 py-1 rounded-full font-bold ${
                              student.status === 'passed'
                                ? 'bg-[#EBF4EE] text-[#15803D] border border-emerald-300'
                                : student.status === 'failed'
                                ? 'bg-[#FBEBEB] text-[#BD4B4B] border border-red-200'
                                : 'bg-slate-100 text-[#64748B]'
                            }`}
                          >
                            {student.gradeText}
                          </span>
                        </td>
                      )}

                      {/* Status (Pass / Fail) */}
                      <td className="py-2.5 px-3 text-center border border-[#CBD5E1]">
                        <span
                          className={`text-xs font-bold px-2 py-0.5 rounded-lg ${
                            student.status === 'passed'
                              ? 'text-[#15803D] bg-[#EBF4EE]'
                              : student.status === 'failed'
                              ? 'text-[#BD4B4B] bg-[#FBEBEB]'
                              : 'text-[#64748B] bg-slate-100'
                          }`}
                        >
                          {student.status === 'passed'
                            ? 'ناجح'
                            : student.status === 'failed'
                            ? 'راسب'
                            : 'غير محدد'}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="p-3.5 bg-[#FAF8F5] border-t border-[#E8E4DA] flex items-center justify-between text-xs text-[#7A746B]">
          <div>
            إجمالي الطلاب: <strong className="text-[#2E2B27] font-bold">{filteredSummaries.length}</strong> طالب
          </div>
          <div>
            تم احتساب الدرجات آلياً اعتماداً على:{' '}
            <strong className="text-[#2E2B27] font-bold">
              {selectedModelsObj.map((m) => m.name).join(' و ')}
            </strong>
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Term Deletion */}
      <ConfirmDeleteModal
        isOpen={isDeleteModalOpen}
        title={`تأكيد حذف فصل (${currentTerm.name})`}
        message={`هل أنت متأكد من الاستمرار في حذف فصل (${currentTerm.name})؟ سيتم حذف نتائج واحتساب هذا الفصل نهائياً.`}
        confirmText={`نعم، استمر في حذف ${currentTerm.name}`}
        onConfirm={() => onDeleteTerm(currentTerm.id)}
        onCancel={() => setIsDeleteModalOpen(false)}
      />

      {/* Modal for Adding a New Term */}
      {isAddingNewTerm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="px-5 py-4 bg-gradient-to-l from-emerald-800 to-teal-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold">إضافة فصل دراسي جديد</h3>
                  <p className="text-xs text-emerald-100">
                    احتساب معدل الدرجات لشهور هذا الفصل تلقائياً
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddingNewTerm(false)}
                className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleCreateTerm();
              }}
              className="p-5 space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  اسم الفصل الدراسي
                </label>
                <input
                  type="text"
                  value={newTermName}
                  onChange={(e) => setNewTermName(e.target.value)}
                  placeholder="مثال: الفصل الثاني، أو السعي السنوي"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  autoFocus
                />
              </div>

              <div className="pt-2 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsAddingNewTerm(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl text-xs font-bold transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={!newTermName.trim()}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-200 flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>إنشاء الفصل</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal for Editing Term Name */}
      {isEditingTermName && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150 text-right">
          <div className="bg-[#FAF7EC] rounded-2xl shadow-2xl border border-[#D8CEBD] w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="px-5 py-4 bg-[#B86848] text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
                  <Pencil className="w-5 h-5 text-orange-100" />
                </div>
                <div>
                  <h3 className="text-base font-bold">تعديل اسم الفصل الدراسي</h3>
                  <p className="text-xs text-orange-100">
                    تغيير مسمى الفصل الحالي ({currentTerm.name})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsEditingTermName(false)}
                className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSaveTermName();
              }}
              className="p-5 space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-[#2F2822] mb-1.5">
                  اسم الفصل الدراسي الجديد:
                </label>
                <input
                  type="text"
                  value={editTermNameValue}
                  onChange={(e) => setEditTermNameValue(e.target.value)}
                  placeholder="مثال: الفصل الأول، الفصل الثاني، السعي السنوي..."
                  className="w-full px-3.5 py-2.5 bg-white border border-[#D8CEBD] rounded-xl text-sm font-bold text-[#2F2822] focus:bg-white focus:ring-2 focus:ring-[#B86848] focus:outline-none"
                  autoFocus
                />
              </div>

              <div className="pt-2 border-t border-[#E0D5C3] flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsEditingTermName(false)}
                  className="px-4 py-2 text-[#7A6E61] hover:bg-[#EBE3D3] rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={!editTermNameValue.trim()}
                  className="px-5 py-2 bg-[#B86848] hover:bg-[#A05537] border border-[#944D30] disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>حفظ التعديل</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Score Rounding Modal */}
      {currentTerm && (
        <ScoreRoundingModal
          isOpen={isRoundingModalOpen}
          onClose={() => setIsRoundingModalOpen(false)}
          currentMode={currentTerm.roundingMode || 'none'}
          currentThreshold={currentTerm.roundingThreshold || 0.5}
          modelName={currentTerm.name}
          applyToAllLabel="تطبيق قاعدة الجبر هذه على جميع الفصول الدراسية"
          onSave={(newMode, newThreshold, applyToAll) => {
            handleSaveRounding(newMode, newThreshold, applyToAll);
          }}
        />
      )}

      {/* Floating Student Info Cloud during horizontal scrolling (only when names are scrolled out of view) */}
      <StudentFloatingCloud
        info={activeStudentCloud}
        isOpen={Boolean(activeStudentCloud) && !isNameColumnVisible}
        onClose={() => setActiveStudentCloud(null)}
      />
    </div>
  );
};
