import React, { useState, useEffect } from 'react';
import { X, Users, Check, Sparkles } from 'lucide-react';
import { MonthlyModel } from '../../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentModel?: MonthlyModel;
  allModels: MonthlyModel[];
  onCreate: (newModel: MonthlyModel) => void;
}

export const CreateModelModal: React.FC<Props> = ({
  isOpen,
  onClose,
  currentModel,
  allModels,
  onCreate,
}) => {
  // Suggest next month name automatically
  const nextMonthNumber = allModels.length + 1;
  const defaultNewName =
    nextMonthNumber === 1
      ? 'الشهر الأول'
      : nextMonthNumber === 2
      ? 'الشهر الثاني'
      : nextMonthNumber === 3
      ? 'الشهر الثالث'
      : nextMonthNumber === 4
      ? 'الشهر الرابع'
      : `الشهر ${nextMonthNumber}`;

  const [modelName, setModelName] = useState(defaultNewName);
  const [totalMaxInput, setTotalMaxInput] = useState('');

  useEffect(() => {
    if (isOpen) {
      setModelName(defaultNewName);
      setTotalMaxInput('');
    }
  }, [isOpen, defaultNewName]);

  if (!isOpen) return null;

  const handleCreate = () => {
    if (!modelName.trim()) return;

    const newId = 'month-' + Date.now();

    // AUTOMATIC TRANSFER: If currentModel exists with students, carry over names/classes
    const transferredStudents = (currentModel?.students || []).map((st) => ({
      id: st.id,
      name: st.name,
      gradeLevel: st.gradeLevel,
      section: st.section,
      writtenRawScore: null,
      scores: {},
      notes: '',
    }));

    // Also transfer the columns configuration (written weight & custom columns)
    const clonedCustomColumns = (currentModel?.customColumns || []).map((col) => ({
      ...col,
      id: 'col-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    }));

    const lastModel = allModels && allModels.length > 0 ? allModels[allModels.length - 1] : undefined;
    const modelToInherit = currentModel || lastModel;
    let storedDefaultMax = 100;
    try {
      const stored = localStorage.getItem('gradebook_last_total_max_score');
      if (stored && Number(stored) > 0) storedDefaultMax = Number(stored);
    } catch {}

    const inheritedTotalMax = modelToInherit?.totalMaxScore || storedDefaultMax;
    const userEnteredMax = Number(totalMaxInput.trim());
    const finalTotalMax = userEnteredMax > 0 ? userEnteredMax : inheritedTotalMax;

    if (userEnteredMax > 0) {
      try {
        localStorage.setItem('gradebook_last_total_max_score', String(userEnteredMax));
      } catch {}
    }

    const finalWrittenMax =
      clonedCustomColumns.length === 0
        ? finalTotalMax
        : Math.min(modelToInherit?.writtenMaxScore || finalTotalMax, finalTotalMax);

    const newModel: MonthlyModel = {
      id: newId,
      name: modelName.trim(),
      subject: modelToInherit?.subject || 'المادة الدراسية',
      academicYear: modelToInherit?.academicYear || '2024-2025',
      totalMaxScore: finalTotalMax,
      writtenWeight: modelToInherit?.writtenWeight ?? null,
      writtenMaxScore: finalWrittenMax,
      writtenScoreMode: modelToInherit?.writtenScoreMode || 'raw',
      customColumns: clonedCustomColumns,
      students: transferredStudents,
      roundingMode: modelToInherit?.roundingMode || 'none',
      roundingThreshold: modelToInherit?.roundingThreshold || 0.5,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onCreate(newModel);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-[#FAF7EC] rounded-2xl shadow-2xl border border-[#D8CEBD] w-full max-w-md overflow-hidden">
        {/* Header - Sky Slate Blue matching reference image */}
        <div className="px-5 py-4 bg-[#5692BE] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-amber-200" />
            </div>
            <div>
              <h3 className="text-base font-bold">إنشاء نموذج جديد (شهر جديد)</h3>
              <p className="text-[11px] text-blue-100">
                ترحيل الطلاب وتصميم الأعمدة تلقائياً
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#2F2822] mb-1.5">
              اسم النموذج:
            </label>
            <input
              type="text"
              value={modelName}
              onChange={(e) => setModelName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
              placeholder="مثال: الشهر الأول، الشهر الثاني..."
              className="w-full px-3.5 py-2.5 bg-white border border-[#D8CEBD] rounded-xl font-bold text-[#2F2822] text-sm focus:bg-white focus:ring-2 focus:ring-[#5692BE] focus:outline-none"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2F2822] mb-1.5">
              الدرجة النهائية من:
            </label>
            <input
              type="number"
              min="1"
              max="1000"
              value={totalMaxInput}
              onChange={(e) => setTotalMaxInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
              placeholder="مثلاً 10 أو 100..."
              className="w-full px-3.5 py-2.5 bg-white border border-[#D8CEBD] rounded-xl font-bold text-[#2F2822] text-sm focus:bg-white focus:ring-2 focus:ring-[#5692BE] focus:outline-none placeholder:text-slate-400 placeholder:font-normal"
            />
            <p className="text-[11px] text-[#7A6E61] mt-1">
              (حقل فارغ: اكتب الدرجة مثل 10 أو 100، أو اتركه فارغاً للاعتماد على النموذج السابق)
            </p>
          </div>

          {/* Automatic Transfer Guarantee Box (Only when currentModel exists with students) */}
          {currentModel && currentModel.students && currentModel.students.length > 0 ? (
            <div className="p-3.5 bg-[#EEF5EB] rounded-xl border border-[#C5DDBE] text-[#224A1E] space-y-2">
              <div className="flex items-center gap-2 font-bold text-xs text-[#224A1E]">
                <Users className="w-4 h-4 text-[#2E6B28] shrink-0" />
                <span>نقل بيانات الطلاب تلقائياً:</span>
              </div>
              <p className="text-xs text-[#2B5626] leading-relaxed">
                سيتم نقل جميع أسماء الطلاب (
                <strong className="text-[#1A3817] font-black">
                  {currentModel.students.length} طالب
                </strong>
                ) مع صفوفهم وشُعبهم ونفس توزيع الأعمدة تلقائياً من (
                <strong>{currentModel.name}</strong>) إلى (
                <strong>{modelName || 'النموذج الجديد'}</strong>) مع تصفير الدرجات للبدء بالرصد فوراً.
              </p>
              <div className="text-[11px] text-[#2E6B28] flex items-center gap-1 font-semibold pt-1 border-t border-[#C5DDBE]/60">
                <Check className="w-3.5 h-3.5 text-[#2E6B28] stroke-[3]" />
                <span>لا حاجة لإعادة كتابة الأسماء أو الصف أو الشعبة مجدداً!</span>
              </div>
            </div>
          ) : (
            <div className="p-3.5 bg-[#FAF7EC] rounded-xl border border-[#D8CEBD] text-[#2F2822] text-xs leading-relaxed font-semibold">
              سيتم إنشاء نموذج شهري جديد فارغ جاهز لإضافة الطلاب وتخصيص الأعمدة ورصد الدرجات.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-[#F8F4EA] border-t border-[#E0D5C3] flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 text-[#7A6E61] hover:bg-[#EBE3D3] rounded-xl font-semibold text-xs transition-colors cursor-pointer"
          >
            إلغاء
          </button>
          <button
            type="button"
            onClick={handleCreate}
            disabled={!modelName.trim()}
            className="px-5 py-2 craft-btn-primary disabled:opacity-50 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            <span>
              {currentModel && currentModel.students && currentModel.students.length > 0
                ? `إنشاء (${modelName}) ونقل الطلاب`
                : `إنشاء (${modelName})`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
