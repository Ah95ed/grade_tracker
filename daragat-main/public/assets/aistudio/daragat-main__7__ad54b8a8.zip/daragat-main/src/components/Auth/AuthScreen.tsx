import React, { useState } from 'react';
import { AppLogo } from '../common/AppLogo';
import {
  GraduationCap,
  LogIn,
  Sparkles,
  Mail,
  Lock,
  Clock,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import {
  AppUser,
  loginWithTrial,
  loginWithEmail,
  loginWithGoogle,
  registerWithEmail,
  sendPasswordResetLink,
} from '../../utils/auth';

interface Props {
  onLoginSuccess: (user: AppUser, isTrial: boolean) => void;
  expiredNotice?: boolean;
  onOpenPrivacy?: () => void;
  onAccountCancelled?: (email: string, message?: string) => void;
}

export const AuthScreen: React.FC<Props> = ({
  onLoginSuccess,
  expiredNotice,
  onOpenPrivacy,
  onAccountCancelled,
}) => {
  const [activeMode, setActiveMode] = useState<'selection' | 'login' | 'register' | 'forgot-password'>('selection');

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [resetSuccessMessage, setResetSuccessMessage] = useState<string | null>(null);

  // Password reset handler
  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setErrorMessage('يرجى كتابة البريد الإلكتروني لإرسال رابط إعادة التعيين.');
      return;
    }
    setIsLoading(true);
    setErrorMessage(null);
    setResetSuccessMessage(null);
    try {
      await sendPasswordResetLink(email);
      setResetSuccessMessage('تم إرسال رابط إعادة تعيين الرقم السري إلى بريدك الإلكتروني بنجاح! يرجى مراجعة صندوق الوارد (ومجلد الرسائل غير المرغوب فيها Spam).');
    } catch (err: any) {
      setErrorMessage(err.message || 'تعذر إرسال الرابط.');
    } finally {
      setIsLoading(false);
    }
  };

  // 1. Instant Trial Login Button
  const handleTrialLogin = () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const trialUser = loginWithTrial();
      onLoginSuccess(trialUser, true);
    } catch (err: any) {
      const msg = err.message || '';
      if (msg.startsWith('CANCELLED_ACCOUNT:')) {
        const cancelledEmail = msg.replace('CANCELLED_ACCOUNT:', '').trim() || email;
        if (onAccountCancelled) {
          onAccountCancelled(cancelledEmail, 'تم إلغاء تفعيل حسابك من قِبل إدارة النظام.');
          return;
        }
      }
      setErrorMessage(err.message || 'حدث خطأ أثناء إنشاء الحساب التجريبي');
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Email + Password Login
  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setErrorMessage('يرجى ملء جميع الحقول المطلوبة.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      let user: AppUser;
      if (activeMode === 'register') {
        user = await registerWithEmail(email, password, displayName);
      } else {
        user = await loginWithEmail(email, password);
      }
      onLoginSuccess(user, false);
    } catch (err: any) {
      const msg = err.message || '';
      if (msg.startsWith('CANCELLED_ACCOUNT:')) {
        const cancelledEmail = msg.replace('CANCELLED_ACCOUNT:', '').trim() || (email || '').trim().toLowerCase();
        if (onAccountCancelled) {
          onAccountCancelled(cancelledEmail, 'تم إلغاء حسابك من قِبل إدارة النظام.');
          return;
        }
      }
      setErrorMessage(err.message || 'فشل تسجيل الدخول، يرجى التحقق من البيانات.');
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Google Sign-In
  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const user = await loginWithGoogle();
      onLoginSuccess(user, false);
    } catch (err: any) {
      const msg = err.message || '';
      if (msg.startsWith('CANCELLED_ACCOUNT:')) {
        const cancelledEmail = msg.replace('CANCELLED_ACCOUNT:', '').trim();
        if (onAccountCancelled) {
          onAccountCancelled(cancelledEmail, 'تم إلغاء حسابك من قِبل إدارة النظام.');
          return;
        }
      }
      setErrorMessage(err.message || 'تعذر تسجيل الدخول بحساب Google');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4EFEA] flex flex-col justify-center items-center p-4 sm:p-6 text-right selection:bg-[#557A95] selection:text-white" dir="rtl">
      {/* Background Subtle Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-[#557A95]/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-[#487B5D]/10 rounded-full blur-3xl"></div>
      </div>

      <div className="w-full max-w-lg bg-white rounded-3xl shadow-xl border border-[#E8E4DA] p-6 sm:p-8 relative z-10 animate-in fade-in zoom-in-95 duration-200">
        {/* App Logo & Header */}
        <div className="text-center space-y-2 mb-6">
          <div className="flex justify-center">
            <AppLogo className="w-20 h-20 sm:w-22 sm:h-22 drop-shadow-md hover:scale-105 transition-transform duration-200" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-[#2E2B27] tracking-tight">
            دفتر درجات المعلم
          </h1>
          <p className="text-xs sm:text-sm text-[#7A746B] font-semibold max-w-sm mx-auto leading-relaxed">
            المنصة الذكية لرصد الدرجات الشهرية، احتساب الفصول، وإصدار بطاقات النتائج المعتمدة
          </p>
        </div>

        {/* Expired Notice Banner (if previous trial expired) */}
        {expiredNotice && (
          <div className="mb-5 p-3.5 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-2.5 text-xs text-amber-900 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">انتهت صلاحية الحساب التجريبي السابق</p>
              <p className="text-amber-700 text-[11px] mt-0.5">
                لقد انقضت مهلة الـ 48 ساعة وتم مسح بيانات الحساب التجريبي تلقائياً. يمكنك البدء بحساب تجريبي جديد أو تسجيل الدخول الدائم.
              </p>
            </div>
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-5 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-2.5 text-xs text-rose-800 animate-in shake duration-200">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <span className="font-bold leading-relaxed">{errorMessage}</span>
          </div>
        )}

        {/* Reset Password Success Alert */}
        {resetSuccessMessage && (
          <div className="mb-5 p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-start gap-2.5 text-xs text-emerald-900 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span className="font-bold leading-relaxed">{resetSuccessMessage}</span>
          </div>
        )}

        {/* View 1: Main Gateway Selection (Two Primary Buttons) */}
        {activeMode === 'selection' ? (
          <div className="space-y-4">
            <div className="text-center pb-2">
              <span className="inline-block px-3 py-1 bg-[#EEF4F8] text-[#557A95] text-xs font-black rounded-full border border-[#D2E0EC]">
                اختر طريقة الدخول للبدء
              </span>
            </div>

            {/* Button 1: Regular Sign-In */}
            <button
              type="button"
              onClick={() => setActiveMode('login')}
              className="w-full p-4 rounded-2xl border-2 border-[#557A95] bg-white hover:bg-[#EEF4F8]/60 text-right transition-all group hover:shadow-md flex items-center justify-between"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-[#557A95] text-white flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                  <LogIn className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-base font-black text-[#2E2B27] flex items-center gap-1.5">
                    <span>تسجيل الدخول</span>
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#EBF4EE] text-[#2D6047]">
                      دائم
                    </span>
                  </div>
                  <p className="text-xs text-[#7A746B] mt-0.5">
                    تسجيل دخول عادي عبر البريد الإلكتروني وكلمة المرور أو عبر حساب Google
                  </p>
                </div>
              </div>
              <ArrowRight className="w-5 h-5 text-[#557A95] group-hover:-translate-x-1 transition-transform shrink-0" />
            </button>

            {/* Button 2: Demo / Trial Login */}
            <button
              type="button"
              disabled={isLoading}
              onClick={handleTrialLogin}
              className="w-full p-4 rounded-2xl border-2 border-[#B27D3E]/40 bg-gradient-to-r from-[#FFFBF7] to-[#FDF5EB] hover:border-[#B27D3E] text-right transition-all group hover:shadow-md flex items-center justify-between"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-[#B27D3E] text-white flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-base font-black text-[#6C4718] flex items-center gap-2">
                    <span>الدخول التجريبي الفوري</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#F5E6D0] text-[#7A4B13] border border-[#E8CDA8]">
                      ينتهي بعد يومين
                    </span>
                  </div>
                  <p className="text-xs text-[#8A6A42] mt-0.5 leading-relaxed">
                    إنشاء حساب وهمي ينتهي بـ <code className="font-bold text-[#6C4718] bg-white/80 px-1 py-0.5 rounded">@jok.nom</code> ويُحذف تلقائياً مع كافة بياناته بعد مرور يومين (48 ساعة)
                  </p>
                </div>
              </div>
              <Clock className="w-5 h-5 text-[#B27D3E] shrink-0" />
            </button>

            {/* Info footer note */}
            <div className="pt-2 text-center flex flex-col items-center gap-1.5">
              <p className="text-[11px] text-[#9A9388] flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#3E7D59]" />
                <span>حفظ تلقائي للبيانات وحماية كاملة لخصوصية الطلاب</span>
              </p>
              {onOpenPrivacy && (
                <button
                  type="button"
                  onClick={onOpenPrivacy}
                  className="text-xs text-[#557A95] hover:text-[#38556b] font-bold hover:underline transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <span>عرض سياسة الخصوصية وسرية البيانات</span>
                  <ArrowRight className="w-3 h-3 rotate-180" />
                </button>
              )}
            </div>
          </div>
        ) : activeMode === 'forgot-password' ? (
          /* View 3: Forgot Password View */
          <div className="space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between pb-2 border-b border-[#E8E4DA]">
              <h2 className="text-base font-bold text-[#2E2B27]">استعادة الرقم السري</h2>
              <button
                type="button"
                onClick={() => {
                  setActiveMode('login');
                  setErrorMessage(null);
                  setResetSuccessMessage(null);
                }}
                className="text-xs font-bold text-[#557A95] hover:underline flex items-center gap-1"
              >
                <span>العودة لتسجيل الدخول</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-xs text-[#7A746B] leading-relaxed">
              أدخل بريدك الإلكتروني المسجل، وسيقوم النظام بإرسال رسالة بريد إلكتروني تحتوي على رابط آمن لإعادة تعيين الرقم السري فوراً.
            </p>

            <form onSubmit={handlePasswordReset} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-[#4A463F] mb-1">
                  البريد الإلكتروني المسجل
                </label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    dir="ltr"
                    className="w-full px-3.5 py-2.5 pl-10 bg-[#FAF8F5] border border-[#D5CFC4] rounded-xl text-sm font-semibold text-[#2E2B27] focus:bg-white focus:ring-2 focus:ring-[#557A95] focus:outline-none text-left"
                  />
                  <Mail className="w-4 h-4 text-[#7A746B] absolute left-3 top-3" />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 px-4 bg-[#557A95] hover:bg-[#476A84] active:scale-99 text-white rounded-xl text-sm font-black transition-all shadow-md flex items-center justify-center gap-2 mt-2"
              >
                {isLoading ? (
                  <span>جاري إرسال الرابط...</span>
                ) : (
                  <>
                    <Mail className="w-4 h-4" />
                    <span>إرسال رابط إعادة تعيين الرقم السري</span>
                  </>
                )}
              </button>
            </form>
          </div>
        ) : (
          /* View 2: Email & Password Form */
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#E8E4DA]">
              <h2 className="text-base font-bold text-[#2E2B27]">
                {activeMode === 'login' ? 'تسجيل الدخول بالبريد' : 'إنشاء حساب دائم جديد'}
              </h2>
              <button
                type="button"
                onClick={() => setActiveMode('selection')}
                className="text-xs font-bold text-[#557A95] hover:underline flex items-center gap-1"
              >
                <span>الرجوع للخيارات</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <form onSubmit={handleEmailAuth} className="space-y-3.5">
              {activeMode === 'register' && (
                <div>
                  <label className="block text-xs font-bold text-[#4A463F] mb-1">
                    اسم المعلم / الأستاذ
                  </label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="مثال: أ. أحمد الهاشمي"
                    className="w-full px-3.5 py-2.5 bg-[#FAF8F5] border border-[#D5CFC4] rounded-xl text-sm font-semibold text-[#2E2B27] focus:bg-white focus:ring-2 focus:ring-[#557A95] focus:outline-none"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-[#4A463F] mb-1">
                  البريد الإلكتروني
                </label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    dir="ltr"
                    className="w-full px-3.5 py-2.5 pl-10 bg-[#FAF8F5] border border-[#D5CFC4] rounded-xl text-sm font-semibold text-[#2E2B27] focus:bg-white focus:ring-2 focus:ring-[#557A95] focus:outline-none text-left"
                  />
                  <Mail className="w-4 h-4 text-[#7A746B] absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#4A463F] mb-1">
                  الرقم السري / كلمة المرور
                </label>
                <div className="relative">
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    dir="ltr"
                    className="w-full px-3.5 py-2.5 pl-10 bg-[#FAF8F5] border border-[#D5CFC4] rounded-xl text-sm font-semibold text-[#2E2B27] focus:bg-white focus:ring-2 focus:ring-[#557A95] focus:outline-none text-left"
                  />
                  <Lock className="w-4 h-4 text-[#7A746B] absolute left-3 top-3" />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 px-4 bg-[#557A95] hover:bg-[#476A84] active:scale-99 text-white rounded-xl text-sm font-black transition-all shadow-md flex items-center justify-center gap-2 mt-2"
              >
                {isLoading ? (
                  <span>جاري تسجيل الدخول...</span>
                ) : (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>{activeMode === 'login' ? 'دخول إلى حسابي' : 'إتمام إنشاء الحساب'}</span>
                  </>
                )}
              </button>
            </form>

            {/* Google Sign In option */}
            <div className="relative py-2">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-[#E8E4DA]" />
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="bg-white px-2 text-[#9A9388] font-bold">أو</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={isLoading}
              className="w-full py-2.5 px-4 bg-white hover:bg-slate-50 border border-[#D5CFC4] rounded-xl text-xs sm:text-sm font-bold text-slate-700 transition-all flex items-center justify-center gap-2.5 shadow-2xs"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                />
              </svg>
              <span>تسجيل الدخول عبر Google</span>
            </button>

            {/* Toggle Mode */}
            <div className="pt-2 text-center text-xs text-[#7A746B]">
              {activeMode === 'login' ? (
                <div>
                  ليس لديك حساب؟{' '}
                  <button
                    type="button"
                    onClick={() => setActiveMode('register')}
                    className="font-bold text-[#557A95] hover:underline"
                  >
                    إنشاء حساب جديد
                  </button>
                </div>
              ) : (
                <div>
                  لديك حساب بالفعل؟{' '}
                  <button
                    type="button"
                    onClick={() => setActiveMode('login')}
                    className="font-bold text-[#557A95] hover:underline"
                  >
                    تسجيل الدخول الآن
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Footer below Auth Card */}
      <footer className="mt-6 text-center text-xs text-[#7A746B] relative z-10 flex flex-col items-center gap-2 max-w-lg w-full px-2">
        <div className="flex flex-wrap items-center justify-center gap-3">
          {onOpenPrivacy && (
            <button
              type="button"
              onClick={onOpenPrivacy}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/90 hover:bg-white text-slate-700 hover:text-emerald-800 font-bold text-xs border border-[#E8E4DA] transition-all shadow-2xs hover:shadow-xs active:scale-95 cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>سياسة الخصوصية وسرية البيانات</span>
            </button>
          )}
        </div>

        <div className="flex items-center justify-center gap-2 text-[11px] text-[#9A9388]">
          <span>رابط الصفحة المباشر:</span>
          <a
            href="/privacy"
            onClick={(e) => {
              e.preventDefault();
              if (onOpenPrivacy) onOpenPrivacy();
            }}
            className="font-mono text-[#557A95] hover:underline"
            dir="ltr"
          >
            https://daragato.online/privacy
          </a>
        </div>
      </footer>
    </div>
  );
};
