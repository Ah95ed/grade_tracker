import React, { useState, useEffect } from 'react';
import { Clock, AlertTriangle, LogOut, ShieldAlert } from 'lucide-react';
import { AppUser, getTrialRemainingTime } from '../../utils/auth';

interface Props {
  user: AppUser;
  onLogout: () => void;
  onExpire: () => void;
}

export const TrialBanner: React.FC<Props> = ({ user, onLogout, onExpire }) => {
  const [remaining, setRemaining] = useState(() => getTrialRemainingTime(user));

  useEffect(() => {
    const timer = setInterval(() => {
      const updated = getTrialRemainingTime(user);
      setRemaining(updated);
      if (updated.expired) {
        clearInterval(timer);
        onExpire();
      }
    }, 30000); // Check every 30 seconds

    return () => clearInterval(timer);
  }, [user, onExpire]);

  if (!user.isTrial) return null;

  return (
    <aside aria-label="تنبيه الحساب التجريبي" className="bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 text-white px-3 py-1.5 text-xs font-bold shadow-xs no-print">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="p-1 bg-white/20 rounded-md">
            <Clock className="w-3.5 h-3.5 text-amber-200" />
          </span>
          <span className="bg-amber-900/60 px-2 py-0.5 rounded text-[11px] font-mono" dir="ltr">
            {user.email}
          </span>
          <span className="hidden sm:inline">
            حساب تجريبي مؤقت • ينتهي تلقائياً بعد:
          </span>
          <span className="px-2 py-0.5 bg-white text-amber-900 rounded-md font-black text-[11px] shadow-2xs">
            {remaining.hours} ساعة و {remaining.minutes} دقيقة
          </span>
          <span className="hidden md:inline text-amber-200 text-[11px]">
            (سيتم حذف الحساب والبيانات تلقائياً بعد مرور 48 ساعة)
          </span>
        </div>

        <div className="flex items-center gap-2 mr-auto">
          <button
            type="button"
            onClick={onLogout}
            className="px-2.5 py-1 bg-white/10 hover:bg-white/20 rounded-md text-[11px] font-bold transition-colors flex items-center gap-1"
            title="تسجيل الخروج والعودة لشاشة الدخول"
          >
            <LogOut className="w-3 h-3" />
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
