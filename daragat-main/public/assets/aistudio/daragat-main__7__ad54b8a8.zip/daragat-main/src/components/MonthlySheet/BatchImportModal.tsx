import {
  getAuthHeaders,
  getCurrentUser,
  getTrialExtractionsCount,
  incrementTrialExtractionsCount,
} from '../../utils/auth';
import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  FileSpreadsheet,
  Check,
  Camera,
  Upload,
  Trash2,
  Loader2,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
  ChevronLeft,
  FileText,
  UserCheck,
  Scissors,
  Crop,
  ClipboardList,
  AlertCircle,
  AlertTriangle,
  HelpCircle,
  Sparkles,
} from 'lucide-react';
import { CustomColumn, StudentRow } from '../../types';
import { SmartCropModal } from './SmartCropModal';
import { isWrittenScoreColumn } from '../../utils/gradeCalculations';
import { extractStudentsDirectly } from '../../utils/directGeminiExtract';
import {
  cleanSingleSpaces,
  canonicalizeArabic,
  findSuspectedStudentMatch,
  SuspectedMatchResult,
} from '../../utils/arabicNameMatcher';

interface AvailableColumnInfo {
  id: string;
  name: string;
  type: 'written' | 'custom';
  maxScore?: number;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onImport: (
    students: Partial<StudentRow>[],
    options?: {
      updateExisting?: boolean;
      newCustomColumns?: Array<{ name: string; maxScore?: number }>;
    }
  ) => void;
  defaultGrade?: string;
  defaultSection?: string;
  customColumns?: CustomColumn[];
  writtenMaxScore?: number;
  existingStudents?: StudentRow[];
  previousModelsStudents?: Array<{ id: string; name: string; modelName?: string }>;
}

interface ImageUploadItem {
  id: string;
  file: File;
  previewUrl: string;
  base64Data: string;
  mimeType: string;
}

interface ExtractedStudentItem {
  id: string;
  name: string;
  gradeLevel: string;
  section: string;
  writtenRawScore: number | null;
  scores: Record<string, number | null>;
  detectedScores?: Array<{ columnName: string; type: string; score: number | null }>;
  isAbsent?: boolean;
  notes?: string;
  isExisting?: boolean;
  selected: boolean;
  suspectedMatch?: SuspectedMatchResult | null;
  confirmedPreviousName?: boolean;
}

interface DetectedColumn {
  name: string;
  type: string;
}

const normalizeArabic = (str: string): string => {
  return (str || '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
};

// Compress and convert image to base64 for fast and reliable upload
const processImageFile = async (
  file: File
): Promise<{ mimeType: string; base64Data: string; previewUrl: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const maxDim = 2600;
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve({
            mimeType: file.type || 'image/jpeg',
            base64Data: String(e.target?.result || ''),
            previewUrl: String(e.target?.result || ''),
          });
          return;
        }
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.90);
        resolve({
          mimeType: 'image/jpeg',
          base64Data: dataUrl,
          previewUrl: dataUrl,
        });
      };
      img.onerror = () => reject(new Error('فشل قراءة الصورة'));
      img.src = String(e.target?.result);
    };
    reader.onerror = () => reject(new Error('فشل قراءة الملف'));
    reader.readAsDataURL(file);
  });
};

export const BatchImportModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onImport,
  defaultGrade = 'الأول متوسط',
  defaultSection = 'أ',
  customColumns = [],
  writtenMaxScore = 100,
  existingStudents = [],
  previousModelsStudents = [],
}) => {
  // Reference students combined from current sheet and previous sheets/models for intelligent name verification
  const allReferenceStudents = React.useMemo(() => {
    const list: Array<{ id?: string; name: string; source?: string }> = [];
    const seen = new Set<string>();

    (existingStudents || []).forEach((st) => {
      const cleaned = cleanSingleSpaces(st.name);
      if (cleaned && !seen.has(cleaned)) {
        seen.add(cleaned);
        list.push({ id: st.id, name: cleaned, source: 'الجدول الحالي' });
      }
    });

    (previousModelsStudents || []).forEach((st) => {
      const cleaned = cleanSingleSpaces(st.name);
      if (cleaned && !seen.has(cleaned)) {
        seen.add(cleaned);
        list.push({ id: st.id, name: cleaned, source: st.modelName || 'الجدول السابق' });
      }
    });

    return list;
  }, [existingStudents, previousModelsStudents]);
  // Mode selection: 'manual' is the INITIAL DEFAULT choice!
  const [activeTab, setActiveTab] = useState<'manual' | 'extract'>('manual');

  // Manual Mode State
  const [namesText, setNamesText] = useState('');
  const [gradeLevel, setGradeLevel] = useState(defaultGrade);
  const [section, setSection] = useState(defaultSection);

  // Extraction Mode State (from Camera or Device)
  const [images, setImages] = useState<ImageUploadItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isPrepaymentError, setIsPrepaymentError] = useState(false);
  const [extractedStudents, setExtractedStudents] = useState<ExtractedStudentItem[]>([]);
  const [detectedColumns, setDetectedColumns] = useState<DetectedColumn[]>([]);
  const [hasExtracted, setHasExtracted] = useState(false);

  // Options
  const [updateExisting, setUpdateExisting] = useState(true);
  const [autoAddColumns, setAutoAddColumns] = useState(true);

  // Trial User Extraction Limit
  const currentUser = getCurrentUser();
  const isTrialUser = Boolean(
    currentUser &&
      (currentUser.isTrial ||
        currentUser.authProvider === 'trial' ||
        currentUser.uid?.startsWith('trial-') ||
        currentUser.email?.includes('@jok.nom'))
  );
  const [trialCount, setTrialCount] = useState<number>(() => getTrialExtractionsCount());
  const isTrialLimitReached = isTrialUser && trialCount >= 1;

  // Smart Crop State
  const [isCropOpen, setIsCropOpen] = useState(false);
  const [cropImageIndex, setCropImageIndex] = useState(0);

  // Direct 100% Free Gemini API Key (stored in localStorage for zero-cost client extraction)
  const [customDirectKey] = useState<string>(() => {
    try {
      return localStorage.getItem('user_free_gemini_key') || '';
    } catch {
      return '';
    }
  });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setNamesText('');
      setGradeLevel(defaultGrade);
      setSection(defaultSection);
      setImages([]);
      setIsProcessing(false);
      setErrorMessage(null);
      setIsPrepaymentError(false);
      setExtractedStudents([]);
      setDetectedColumns([]);
      setHasExtracted(false);
      // ALWAYS default to manual entry initially
      setActiveTab('manual');
      setUpdateExisting(true);
      setAutoAddColumns(true);
      setIsCropOpen(false);
      setCropImageIndex(0);
      setTrialCount(getTrialExtractionsCount());
    }
  }, [isOpen, defaultGrade, defaultSection]);

  if (!isOpen) return null;

  // Merge existing customColumns in the model and newly detected columns
  const effectiveReviewColumns: Array<{ id?: string; name: string; type: string; isNew?: boolean }> = [];
  {
    const seen = new Set<string>();
    for (const cc of customColumns) {
      if (isWrittenScoreColumn(cc.name)) continue;
      const norm = normalizeArabic(cc.name);
      seen.add(norm);
      seen.add(cc.name);
      seen.add(norm.replace(/^ال/, ''));
      effectiveReviewColumns.push({ id: cc.id, name: cc.name, type: 'custom', isNew: false });
    }
    for (const dc of detectedColumns) {
      if (isWrittenScoreColumn(dc.name, dc.type)) continue;
      const norm = normalizeArabic(dc.name);
      const stripped = norm.replace(/^ال/, '');
      if (!seen.has(norm) && !seen.has(dc.name) && !seen.has(stripped)) {
        seen.add(norm);
        seen.add(dc.name);
        seen.add(stripped);
        effectiveReviewColumns.push({ name: dc.name, type: dc.type, isNew: true });
      }
    }
  }

  // Manual Tab parsing: handles name + optional scores with smart Arabic name verification
  const parseManualLines = () => {
    const rawLines = namesText.split('\n');

    return rawLines
      .map((line, lineIndex) => {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) return null;

        const tokens = trimmed.split(/[\t,،]+/).map((t) => t.trim()).filter(Boolean);
        let rawName = '';
        let writtenScore: number | null = null;
        const extraScores: Record<string, number | null> = {};

        if (tokens.length >= 2) {
          rawName = tokens[0];
          const num1 = parseFloat(tokens[1]);
          writtenScore = !isNaN(num1) ? num1 : null;
          if (tokens.length >= 3) {
            const num2 = parseFloat(tokens[2]);
            if (!isNaN(num2) && customColumns[0]) {
              extraScores[customColumns[0].id] = num2;
            }
          }
        } else {
          const match = trimmed.match(/^(.*?)\s+([0-9]+(?:\.[0-9]+)?)$/);
          if (match) {
            rawName = match[1].trim();
            writtenScore = parseFloat(match[2]);
          } else {
            rawName = trimmed;
          }
        }

        const cleanedName = cleanSingleSpaces(rawName);
        const matchResult = findSuspectedStudentMatch(cleanedName, allReferenceStudents);

        return {
          lineIndex,
          rawLine: line,
          rawName,
          name: cleanedName,
          writtenRawScore: writtenScore,
          scores: extraScores,
          suspectedMatch: matchResult && !matchResult.isExact ? matchResult : null,
          isExactMatch: Boolean(matchResult?.isExact),
        };
      })
      .filter(Boolean) as Array<{
        lineIndex: number;
        rawLine: string;
        rawName: string;
        name: string;
        writtenRawScore: number | null;
        scores: Record<string, number | null>;
        suspectedMatch: SuspectedMatchResult | null;
        isExactMatch: boolean;
      }>;
  };

  const parsedManualItems = parseManualLines();
  const suspectedManualItems = parsedManualItems.filter((item) => item.suspectedMatch !== null);

  const handleAdoptManualPreviousName = (lineIndex: number, rawName: string, matchedName: string) => {
    const lines = namesText.split('\n');
    if (lines[lineIndex] !== undefined) {
      lines[lineIndex] = lines[lineIndex].replace(rawName, matchedName);
      setNamesText(lines.join('\n'));
    }
  };

  const handleAdoptAllManualPreviousNames = () => {
    const lines = namesText.split('\n');
    for (const item of suspectedManualItems) {
      if (item.suspectedMatch && lines[item.lineIndex] !== undefined) {
        lines[item.lineIndex] = lines[item.lineIndex].replace(item.rawName, item.suspectedMatch.matchedName);
      }
    }
    setNamesText(lines.join('\n'));
  };

  const handleConfirmManual = () => {
    if (parsedManualItems.length === 0) return;

    const newRows: Partial<StudentRow>[] = parsedManualItems.map((item) => ({
      name: cleanSingleSpaces(item.name),
      gradeLevel,
      section,
      writtenRawScore: item.writtenRawScore,
      scores: item.scores,
      notes: '',
    }));

    onImport(newRows, { updateExisting });
    onClose();
  };

  // Image Selection Handlers
  const handleFilesSelected = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    setErrorMessage(null);

    const filesArray = Array.from(fileList);
    const newItems: ImageUploadItem[] = [];

    for (const file of filesArray) {
      if (!file.type.startsWith('image/')) continue;
      try {
        const { mimeType, base64Data, previewUrl } = await processImageFile(file);
        newItems.push({
          id: `${Date.now()}-${Math.random()}`,
          file,
          previewUrl,
          base64Data,
          mimeType,
        });
      } catch (err) {
        console.error('Error loading image', err);
      }
    }

    setImages((prev) => [...prev, ...newItems]);
  };

  const handleRemoveImage = (id: string) => {
    setImages((prev) => prev.filter((img) => img.id !== id));
  };

  // Handle Crop result from SmartCropModal
  const handleApplyCrop = (
    croppedBase64: string,
    imageIndex: number,
    analyzeImmediately: boolean
  ) => {
    const updatedImages = images.map((img, idx) =>
      idx === imageIndex
        ? {
            ...img,
            base64Data: croppedBase64,
            previewUrl: croppedBase64,
          }
        : img
    );
    setImages(updatedImages);
    setIsCropOpen(false);
    setErrorMessage(null);

    if (analyzeImmediately) {
      setTimeout(() => {
        executeExtraction(undefined, updatedImages);
      }, 60);
    }
  };

  // Trigger data extraction from images
  const handleExtractFromImages = () => {
    executeExtraction();
  };

  const executeExtraction = async (
    overrideDirectKey?: string,
    overrideImages?: ImageUploadItem[]
  ) => {
    const currentImages = overrideImages || images;
    if (currentImages.length === 0) {
      setErrorMessage('يرجى التقاط صورة أو اختيار ملف صورة لكشف درجات الطلاب أولاً');
      return;
    }

    if (isTrialLimitReached) {
      setErrorMessage(
        'تم استخدام محاولة الاستخراج المتاحة في الفترة التجريبية. يمكنك استخدام خيار "إضافة يدوية أو لصق نص" لإضافة الطلاب ودرجاتهم مجاناً دائماً، أو الترقية للاشتراك الدائم.'
      );
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);
    setIsPrepaymentError(false);

    const availableCols: AvailableColumnInfo[] = [
      { id: 'written', name: 'الامتحان التحريري', type: 'written', maxScore: writtenMaxScore },
      ...customColumns.map((c) => ({
        id: c.id,
        name: c.name,
        type: 'custom' as const,
        maxScore: c.maxScore,
      })),
    ];

    const directKey =
      (overrideDirectKey || '').trim() ||
      (customDirectKey || '').trim() ||
      (typeof window !== 'undefined' ? localStorage.getItem('user_free_gemini_key') || '' : '').trim() ||
      ((import.meta.env.VITE_GEMINI_API_KEY as string) || '').trim() ||
      '';

    const payload = {
      images: currentImages.map((img) => ({
        mimeType: img.mimeType,
        data: img.base64Data,
      })),
      defaultGrade: gradeLevel,
      defaultSection: section,
      availableColumns: availableCols,
      apiKey: directKey,
    };

    let rawList: any[] = [];
    let returnedCols: DetectedColumn[] = [];
    let detectedGradeFinal = gradeLevel;
    let detectedSectionFinal = section;
    let extractionSucceeded = false;
    let lastExtractError = '';

    try {
      let authHeaders = await getAuthHeaders();
      let res = await fetch('/api/extract-students', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify(payload),
      });

      // If unauthorized on first attempt and user is logged in, retry once with refreshed auth headers
      if (res.status === 401 && currentUser) {
        authHeaders = await getAuthHeaders();
        res = await fetch('/api/extract-students', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify(payload),
        });
      }

      const resText = await res.text();
      let parsedData: any = null;

      try {
        parsedData = JSON.parse(resText);
      } catch {
        parsedData = null;
      }

      if (parsedData && typeof parsedData === 'object') {
        const isAuthErr =
          res.status === 401 ||
          Boolean(parsedData.isAuthError) ||
          Boolean(parsedData.isMissingApiKey) ||
          (parsedData.error &&
            (parsedData.error.includes('401') ||
              parsedData.error.includes('UNAUTHENTICATED') ||
              parsedData.error.includes('ACCESS_TOKEN_TYPE_UNSUPPORTED') ||
              parsedData.error.includes('authentication credentials') ||
              parsedData.error.includes('GEMINI_API_KEY') ||
              parsedData.error.includes('مفتاح')));

        if (
          res.status === 403 &&
          (parsedData.isTrialLimitReached ||
            (parsedData.error && (parsedData.error.includes('استنفدت المحاولة المجانية') || parsedData.error.includes('المحاولة'))))
        ) {
          if (isTrialUser) {
            incrementTrialExtractionsCount();
            setTrialCount(getTrialExtractionsCount());
          }
          setIsProcessing(false);
          setErrorMessage(
            parsedData.error ||
              'تم استخدام محاولة الاستخراج المتاحة في الفترة التجريبية. يمكنك استخدام خيار "إضافة يدوية أو لصق نص" لإضافة الطلاب ودرجاتهم مجاناً دائماً، أو الترقية إلى الاشتراك الدائم.'
          );
          return;
        }

        if (res.ok && parsedData.success && Array.isArray(parsedData.students) && parsedData.students.length > 0) {
          rawList = parsedData.students;
          returnedCols = (Array.isArray(parsedData.detectedColumns) ? parsedData.detectedColumns : []).filter(
            (c: any) => c && c.name && !isWrittenScoreColumn(c.name, c.type)
          );
          if (parsedData.detectedGrade && typeof parsedData.detectedGrade === 'string' && parsedData.detectedGrade.trim()) {
            detectedGradeFinal = parsedData.detectedGrade.trim();
            setGradeLevel(detectedGradeFinal);
          }
          if (parsedData.detectedSection && typeof parsedData.detectedSection === 'string' && parsedData.detectedSection.trim()) {
            detectedSectionFinal = parsedData.detectedSection.trim();
            setSection(detectedSectionFinal);
          }
          extractionSucceeded = true;
        } else if (isAuthErr) {
          lastExtractError = parsedData.error || 'خدمة الذكاء الاصطناعي تحتاج إلى مفتاح API صالح.';
        } else if (
          parsedData.isPrepaymentError ||
          res.status === 402 ||
          (parsedData.error &&
            (parsedData.error.includes('prepayment') ||
              parsedData.error.includes('RESOURCE_EXHAUSTED') ||
              parsedData.error.includes('رصيد')))
        ) {
          setIsPrepaymentError(true);
          setIsProcessing(false);
          setErrorMessage(
            'مفتاح الخدمة الحالي انتهى رصيده المخصص. يمكنك استخدام خيار الإدخال اليدوي أو إنشاء مفتاح جديد.'
          );
          return;
        } else if (parsedData.error) {
          lastExtractError = parsedData.error;
        }
      } else if (!res.ok) {
        if (res.status === 429) {
          lastExtractError = 'تم تجاوز حد الطلبات للذكاء الاصطناعي (429). يرجى الانتظار لحظات وإعادة المحاولة.';
        } else if (res.status === 503 || res.status === 504) {
          lastExtractError = 'خدمة الذكاء الاصطناعي مشغولة حالياً (503). يرجى إعادة المحاولة بعد لحظات.';
        } else {
          lastExtractError = `استجاب الخادم برمز خطأ (${res.status}).`;
        }
      }
    } catch (srvErr: any) {
      console.warn('Backend proxy /api/extract-students error:', srvErr);
      lastExtractError = srvErr?.message || 'تعذر الاتصال بخادم الاستخراج.';
    }

    // Direct fallback if backend was unavailable and a direct client Gemini key exists
    if (!extractionSucceeded) {
      const directKey =
        (overrideDirectKey || '').trim() ||
        (customDirectKey || '').trim() ||
        (typeof window !== 'undefined' ? localStorage.getItem('user_free_gemini_key') || '' : '').trim() ||
        ((import.meta.env.VITE_GEMINI_API_KEY as string) || '').trim() ||
        '';

      if (directKey) {
        try {
          const directResult = await extractStudentsDirectly({
            apiKey: directKey,
            images: payload.images,
            defaultGrade: gradeLevel,
            defaultSection: section,
            availableColumns: availableCols,
          });
          if (directResult && Array.isArray(directResult.students) && directResult.students.length > 0) {
            rawList = directResult.students;
            returnedCols = directResult.detectedColumns || [];
            if (directResult.detectedGrade) detectedGradeFinal = directResult.detectedGrade;
            if (directResult.detectedSection) detectedSectionFinal = directResult.detectedSection;
            extractionSucceeded = true;
          }
        } catch (directErr: any) {
          console.warn('Direct client-side extraction error:', directErr);
          lastExtractError = directErr?.message || 'فشل الاتصال المباشر بالذكاء الاصطناعي.';
        }
      }
    }

    if (!extractionSucceeded || rawList.length === 0) {
      setErrorMessage(
        lastExtractError
          ? `تعذّر استخراج البيانات: ${lastExtractError}`
          : 'لم يتم العثور على أسماء طلاب داخل هذه الصورة. يرجى التأكد من وضوح كشف الأسماء، أو استخدام خيار الإضافة اليدوية.'
      );
      setIsProcessing(false);
      return;
    }

    setDetectedColumns(returnedCols);

    const items: ExtractedStudentItem[] = rawList.map((item: any, idx: number) => {
      const cleanedName = cleanSingleSpaces(item.name || '');
      const matchResult = findSuspectedStudentMatch(cleanedName, allReferenceStudents);
      const isExisting = Boolean(
        matchResult?.isExact ||
          (existingStudents || []).some(
            (ex) => canonicalizeArabic(ex.name) === canonicalizeArabic(cleanedName)
          )
      );

      return {
        id: `extracted-${idx}-${Date.now()}`,
        name: cleanedName,
        gradeLevel: item.gradeLevel || detectedGradeFinal,
        section: item.section || detectedSectionFinal,
        writtenRawScore:
          typeof item.writtenRawScore === 'number' && !isNaN(item.writtenRawScore)
            ? item.writtenRawScore
            : null,
        scores: item.scores || {},
        detectedScores: item.detectedScores || [],
        isAbsent: Boolean(item.isAbsent),
        notes: item.notes || (item.isAbsent ? 'غائب' : ''),
        isExisting,
        selected: true,
        suspectedMatch: matchResult && !matchResult.isExact ? matchResult : null,
        confirmedPreviousName: false,
      };
    });

    if (isTrialUser) {
      incrementTrialExtractionsCount();
      setTrialCount(getTrialExtractionsCount());
    }

    setExtractedStudents(items);
    setHasExtracted(true);
    setIsProcessing(false);
  };

  const handleAdoptPreviousName = (studentId: string, matchedName: string) => {
    setExtractedStudents((prev) =>
      prev.map((s) =>
        s.id === studentId
          ? {
              ...s,
              name: matchedName,
              isExisting: true,
              suspectedMatch: null,
              confirmedPreviousName: true,
            }
          : s
      )
    );
  };

  const handleDismissSuspicion = (studentId: string) => {
    setExtractedStudents((prev) =>
      prev.map((s) =>
        s.id === studentId ? { ...s, suspectedMatch: null, confirmedPreviousName: true } : s
      )
    );
  };

  const handleAdoptAllExtractedPreviousNames = () => {
    setExtractedStudents((prev) =>
      prev.map((s) => {
        if (s.suspectedMatch && !s.confirmedPreviousName) {
          return {
            ...s,
            name: s.suspectedMatch.matchedName,
            isExisting: true,
            suspectedMatch: null,
            confirmedPreviousName: true,
          };
        }
        return s;
      })
    );
  };

  const handleToggleSelectAll = (checked: boolean) => {
    setExtractedStudents((prev) => prev.map((s) => ({ ...s, selected: checked })));
  };

  const handleToggleStudent = (id: string) => {
    setExtractedStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, selected: !s.selected } : s))
    );
  };

  const handleUpdateStudent = (
    id: string,
    field: 'name' | 'gradeLevel' | 'section' | 'writtenRawScore' | 'notes',
    value: any
  ) => {
    setExtractedStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, [field]: value } : s))
    );
  };

  const handleUpdateCustomScore = (
    id: string,
    colKey: string,
    colId: string | undefined,
    scoreVal: string
  ) => {
    setExtractedStudents((prev) =>
      prev.map((s) => {
        if (s.id !== id) return s;
        const num = scoreVal.trim() === '' ? null : parseFloat(scoreVal);
        const parsedNum = !isNaN(num as number) ? num : null;
        const nextScores = { ...s.scores };
        nextScores[colKey] = parsedNum;
        nextScores[normalizeArabic(colKey)] = parsedNum;
        if (colId) {
          nextScores[colId] = parsedNum;
        }
        return {
          ...s,
          scores: nextScores,
        };
      })
    );
  };

  const handleDeleteExtractedStudent = (id: string) => {
    setExtractedStudents((prev) => prev.filter((s) => s.id !== id));
  };

  const handleConfirmExtracted = () => {
    const selected = extractedStudents.filter((s) => s.selected && s.name.trim().length > 0);
    if (selected.length === 0) return;

    const newRows: Partial<StudentRow>[] = selected.map((s) => ({
      name: cleanSingleSpaces(s.name),
      gradeLevel: s.gradeLevel || gradeLevel,
      section: s.section || section,
      writtenRawScore: s.writtenRawScore,
      scores: s.scores,
      notes: s.notes || (s.isAbsent ? 'غائب' : ''),
    }));

    const columnsToCreate: Array<{ name: string; maxScore?: number }> = [];
    if (autoAddColumns && detectedColumns.length > 0) {
      for (const dc of detectedColumns) {
        if (isWrittenScoreColumn(dc.name, dc.type)) continue;

        const normDc = normalizeArabic(dc.name);
        const strippedDc = normDc.replace(/^ال/, '');
        const alreadyExists = customColumns.some((c) => {
          const normC = normalizeArabic(c.name);
          const strippedC = normC.replace(/^ال/, '');
          return normC === normDc || c.name === dc.name || strippedC === strippedDc;
        });

        if (!alreadyExists) {
          columnsToCreate.push({
            name: dc.name,
            maxScore: dc.type === 'oral' ? 20 : dc.type === 'activity' ? 10 : 10,
          });
        }
      }
    }

    onImport(newRows, {
      updateExisting,
      newCustomColumns: columnsToCreate,
    });
    onClose();
  };

  const selectedCount = extractedStudents.filter(
    (s) => s.selected && s.name.trim().length > 0
  ).length;

  const totalWithWrittenScores = extractedStudents.filter(
    (s) => s.writtenRawScore !== null && s.writtenRawScore !== undefined
  ).length;

  const matchedExistingCount = extractedStudents.filter((s) => s.isExisting).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-[#FAF7EC] rounded-2xl shadow-2xl border border-[#D8CEBD] w-full max-w-4xl max-h-[92dvh] flex flex-col overflow-hidden my-auto">
        {/* Header: Clean, Simple, Semantic with Sky Slate Blue Theme */}
        <div className="shrink-0 px-5 py-3.5 bg-[#5692BE] text-white flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold leading-tight">
                استيراد وإضافة بيانات الطلاب
              </h3>
              <p className="text-[11px] sm:text-xs text-blue-100 mt-0.5">
                إضافة يدوية مباشرة أو استخراج بيانات الطلاب من الجهاز أو الكاميرا
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer shrink-0"
            title="إغلاق"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Single Row Bar: حقل الصف والشعبة في أعلى الصفحة وفي سطر واحد */}
        <div className="shrink-0 px-4 py-2.5 sm:px-5 sm:py-3 bg-[#FAF7EC] border-b border-[#D8CEBD] flex items-center gap-3 no-print" dir="rtl">
          {/* حقل الصف: يتسع لاسم الصف/المرحلة */}
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <label className="text-xs sm:text-sm font-bold text-[#2F2822] shrink-0 whitespace-nowrap">
              الصف:
            </label>
            <input
              type="text"
              value={gradeLevel}
              onChange={(e) => setGradeLevel(e.target.value)}
              placeholder="مثال: الأول متوسط"
              className="w-full px-3 py-1.5 bg-white border border-[#D8CEBD] rounded-xl text-xs sm:text-sm font-bold text-[#2F2822] focus:ring-2 focus:ring-[#5692BE] focus:outline-none transition-shadow"
            />
          </div>

          {/* حقل الشعبة: في نفس السطر وبحجم صغير محدد لأن خانة الشعبة لا تحتاج إلى خانة كبيرة */}
          <div className="flex items-center gap-2 shrink-0">
            <label className="text-xs sm:text-sm font-bold text-[#2F2822] shrink-0 whitespace-nowrap">
              الشعبة:
            </label>
            <input
              type="text"
              value={section}
              onChange={(e) => setSection(e.target.value)}
              placeholder="أ / ب"
              maxLength={10}
              className="w-20 sm:w-24 px-2 py-1.5 text-center bg-white border border-[#D8CEBD] rounded-xl text-xs sm:text-sm font-bold text-[#2F2822] focus:ring-2 focus:ring-[#5692BE] focus:outline-none transition-shadow"
            />
          </div>
        </div>

        {/* Organized Options: 2 Independent, Prominent Choices Side by Side */}
        <div className="shrink-0 p-3 sm:p-4 bg-[#F5EFE3] border-b border-[#D8CEBD]">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {/* 1. Default Option: Manual Entry / Paste Text */}
            <button
              type="button"
              onClick={() => setActiveTab('manual')}
              className={`p-3 rounded-xl text-right transition-all cursor-pointer border flex items-center gap-3 ${
                activeTab === 'manual'
                  ? 'bg-white border-[#BA916C] ring-2 ring-[#BA916C]/30 shadow-xs'
                  : 'bg-white/70 hover:bg-white border-[#D8CEBD] text-[#554A3E] hover:border-[#BA916C]'
              }`}
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                  activeTab === 'manual'
                    ? 'bg-[#BA916C] text-white shadow-xs'
                    : 'bg-[#EBDDC8] text-[#554A3E]'
                }`}
              >
                <ClipboardList className="w-5 h-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1.5">
                  <span
                    className={`text-sm font-bold truncate ${
                      activeTab === 'manual' ? 'text-[#8C6544] font-black' : 'text-[#2F2822]'
                    }`}
                  >
                    إضافة يدوية أو لصق نص
                  </span>
                  {activeTab === 'manual' && (
                    <span className="w-2 h-2 rounded-full bg-[#BA916C] shrink-0" />
                  )}
                </div>
                <p className="text-[11px] text-[#7A6E61] truncate mt-0.5">
                  كتابة مباشرة أو لصق من Excel أو Word
                </p>
              </div>
            </button>

            {/* 2. Extraction Option: Device or Camera */}
            <button
              type="button"
              onClick={() => setActiveTab('extract')}
              className={`p-3 rounded-xl text-right transition-all cursor-pointer border flex items-center gap-3 ${
                activeTab === 'extract'
                  ? 'bg-white border-[#5692BE] ring-2 ring-[#5692BE]/30 shadow-xs'
                  : 'bg-white/70 hover:bg-white border-[#D8CEBD] text-[#554A3E] hover:border-[#5692BE]'
              }`}
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                  activeTab === 'extract'
                    ? 'bg-[#5692BE] text-white shadow-xs'
                    : 'bg-[#D2E2EE] text-[#3A6C8F]'
                }`}
              >
                <Camera className="w-5 h-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1.5">
                  <span
                    className={`text-sm font-bold truncate ${
                      activeTab === 'extract' ? 'text-[#3A6C8F] font-black' : 'text-[#2F2822]'
                    }`}
                  >
                    رفع صورة أو التقاط بالكاميرا
                  </span>
                  {activeTab === 'extract' && (
                    <span className="w-2 h-2 rounded-full bg-[#5692BE] shrink-0" />
                  )}
                </div>
                <p className="text-[11px] text-[#7A6E61] truncate mt-0.5">
                  استخراج بيانات الطلاب من الجهاز أو الكاميرا
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* VIEW 1: MANUAL ENTRY / PASTE (DEFAULT VIEW) */}
          {activeTab === 'manual' && (
            <div className="space-y-3.5 animate-in fade-in duration-150">
              {/* Names & Scores Input Area - Spacious, Prominent & High Visibility */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-[#554A3E]">
                  <span className="font-bold text-[#2F2822] flex items-center gap-1.5">
                    <ClipboardList className="w-4 h-4 text-[#BA916C]" />
                    <span>حقل إضافة ولصق أسماء ودرجات الطلاب (طالب في كل سطر):</span>
                  </span>
                  <span className="text-[#7A6E61] text-[11px] font-medium hidden sm:inline">
                    يدعم النسخ واللصق المباشر من Excel أو Word
                  </span>
                </div>

                <div>
                  <textarea
                    rows={12}
                    value={namesText}
                    onChange={(e) => setNamesText(e.target.value)}
                    placeholder={`أحمد محمد علي 85\nحسين كريم حسن 92\nعلي رضا كاظم 78\n\nأو الصق أسماء ودرجات الطلاب مباشرة من جدول Excel...`}
                    className="w-full min-h-[260px] sm:min-h-[300px] p-4 bg-white border-2 border-[#D8CEBD] focus:border-[#BA916C] rounded-xl text-xs sm:text-sm font-mono leading-relaxed text-[#2F2822] focus:ring-2 focus:ring-[#BA916C]/30 focus:outline-none placeholder:text-[#A89C8F] shadow-inner"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
                <span className="text-[#554A3E] font-medium">
                  عدد الطلاب المكتشفين: <b className="text-[#8C6544] font-black">{parsedManualItems.length}</b>
                </span>
                <label className="flex items-center gap-1.5 font-bold text-[#2F2822] cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={updateExisting}
                    onChange={(e) => setUpdateExisting(e.target.checked)}
                    className="rounded text-[#BA916C] focus:ring-[#BA916C] w-4 h-4 cursor-pointer"
                  />
                  <span>تحديث درجات الطلاب المسجلين مسبقاً على أساس الاسم (حتى لو اختلف التسلسل)</span>
                </label>
              </div>

              {/* Suspicious Name Verification Alert for Manual Entry */}
              {suspectedManualItems.length > 0 && (
                <div className="p-3.5 bg-amber-50 border-2 border-amber-300 rounded-xl space-y-2.5 text-xs text-amber-950 animate-in fade-in duration-150">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2 font-black text-amber-900">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>
                        تم رصد أسماء مشابهة لأسماء بالجدول السابق ({suspectedManualItems.length} اسم مشتبه):
                      </span>
                    </div>
                    {suspectedManualItems.length > 1 && (
                      <button
                        type="button"
                        onClick={handleAdoptAllManualPreviousNames}
                        className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-[11px] flex items-center gap-1 shadow-2xs cursor-pointer transition-colors"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>اعتماد جميع الأسماء السابقة دفعة واحدة</span>
                      </button>
                    )}
                  </div>

                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-0.5">
                    {suspectedManualItems.map((item) => (
                      <div
                        key={item.lineIndex}
                        className="flex flex-wrap items-center justify-between gap-2 p-2 bg-amber-100/90 border border-amber-300 rounded-lg text-xs"
                      >
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="font-semibold text-amber-800 line-through opacity-75">
                            {item.rawName}
                          </span>
                          <span className="text-amber-600 font-bold">➔</span>
                          <span className="font-black text-amber-950 bg-white px-2 py-0.5 rounded border border-amber-300">
                            هل تقصد {item.suspectedMatch?.matchedName} كما في الجدول السابق؟
                          </span>
                          <span className="text-[10px] text-amber-700 font-medium">
                            ({item.suspectedMatch?.diffDescription})
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() =>
                            handleAdoptManualPreviousName(
                              item.lineIndex,
                              item.rawName,
                              item.suspectedMatch!.matchedName
                            )
                          }
                          className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md font-bold text-[11px] flex items-center gap-1 cursor-pointer transition-colors shadow-2xs shrink-0"
                        >
                          <Check className="w-3 h-3" />
                          <span>نعم، اعتمد «{item.suspectedMatch?.matchedName}»</span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* VIEW 2: EXTRACTION FROM CAMERA OR DEVICE */}
          {activeTab === 'extract' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Trial Notice */}
              {isTrialUser && (
                isTrialLimitReached ? (
                  <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl flex items-center justify-between gap-3 text-xs text-amber-950">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                      <span>تم استنفاد محاولة الاستخراج المجانية في الفترة التجريبية.</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab('manual')}
                      className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-[11px] shrink-0 cursor-pointer"
                    >
                      استخدام الإدخال اليدوي
                    </button>
                  </div>
                ) : (
                  <div className="px-3 py-2 bg-blue-50 border border-blue-200 rounded-xl flex items-center justify-between gap-2 text-xs text-blue-900 font-semibold">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-[#2B6CB0]" />
                      <span>استخراج بيانات الطلاب من الجهاز أو الكاميرا متاح لمرة واحدة في الفترة التجريبية</span>
                    </span>
                    <span className="text-[10px] bg-blue-200 text-blue-950 px-2 py-0.5 rounded-md font-bold shrink-0">
                      محاولة متبقية: 1/1
                    </span>
                  </div>
                )
              )}

              {!hasExtracted ? (
                <>
                  {/* Clean Upload / Capture Area - Free of Text Overload */}
                  <div className="border-2 border-dashed border-slate-300 hover:border-[#2B6CB0] bg-slate-50/70 hover:bg-blue-50/30 rounded-2xl p-6 text-center transition-colors">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={(e) => handleFilesSelected(e.target.files)}
                      accept="image/*"
                      multiple
                      className="hidden"
                    />
                    <input
                      type="file"
                      ref={cameraInputRef}
                      onChange={(e) => handleFilesSelected(e.target.files)}
                      accept="image/*"
                      capture="environment"
                      className="hidden"
                    />

                    <div className="w-12 h-12 mx-auto rounded-2xl bg-white border border-slate-200 text-[#2B6CB0] flex items-center justify-center mb-2.5 shadow-2xs">
                      <Camera className="w-6 h-6" />
                    </div>

                    <h4 className="text-sm sm:text-base font-bold text-slate-800 mb-1">
                      استخراج بيانات الطلاب من الجهاز أو الكاميرا
                    </h4>
                    <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
                      التقط صورة واضحة لكشف الدرجات أو ارفع صورة كشف محفوظ على جهازك
                    </p>

                    {/* Prominent Action Buttons */}
                    <div className="flex flex-wrap items-center justify-center gap-3">
                      <button
                        type="button"
                        onClick={() => cameraInputRef.current?.click()}
                        className="px-5 py-2.5 bg-[#2B6CB0] hover:bg-[#255C96] text-white rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
                      >
                        <Camera className="w-4 h-4" />
                        <span>التقاط بالكاميرا</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-5 py-2.5 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 shadow-2xs transition-colors cursor-pointer"
                      >
                        <Upload className="w-4 h-4 text-[#2B6CB0]" />
                        <span>رفع صورة من الجهاز</span>
                      </button>
                    </div>

                    {/* Semantic Icons & Key Highlights */}
                    <div className="mt-5 pt-3.5 border-t border-slate-200/80 flex flex-wrap items-center justify-center gap-4 sm:gap-6 text-xs text-slate-600 font-medium">
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>قراءة الأسماء والدرجات المكتوبة</span>
                      </span>
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>التحريري والشفهي والنشاط</span>
                      </span>
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>كشف الغياب تلقائياً</span>
                      </span>
                    </div>
                  </div>

                  {/* Image Previews */}
                  {images.length > 0 && (
                    <div className="space-y-2 pt-1">
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-slate-700">
                        <span>الصور المحددة ({images.length} صورة):</span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setCropImageIndex(0);
                              setIsCropOpen(true);
                            }}
                            className="text-xs font-bold text-[#2B6CB0] hover:text-[#1E3A8A] flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 border border-blue-200 transition-colors cursor-pointer"
                            title="تحديد وقص منطقة الجدول في الصورة يدوياً"
                          >
                            <Scissors className="w-3.5 h-3.5" />
                            <span>تحديد وقص الجدول</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setImages([])}
                            className="text-rose-600 hover:text-rose-700 text-[11px] cursor-pointer"
                          >
                            مسح جميع الصور
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        {images.map((img, idx) => (
                          <div
                            key={img.id}
                            className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-100 aspect-3/4 shadow-xs"
                          >
                            <img
                              src={img.previewUrl}
                              alt={`ورقة ${idx + 1}`}
                              className="w-full h-full object-cover"
                            />
                            {/* Hover Overlay */}
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-2 gap-2">
                              <button
                                type="button"
                                onClick={() => {
                                  setCropImageIndex(idx);
                                  setIsCropOpen(true);
                                }}
                                className="p-2 bg-[#2B6CB0] hover:bg-[#255C96] text-white rounded-full transition-colors cursor-pointer shadow-md"
                                title="تحديد وقص منطقة الجدول"
                              >
                                <Scissors className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleRemoveImage(img.id)}
                                className="p-2 bg-rose-600 hover:bg-rose-700 text-white rounded-full transition-colors cursor-pointer shadow-md"
                                title="حذف الصورة"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>

                            {/* Quick Crop badge */}
                            <button
                              type="button"
                              onClick={() => {
                                setCropImageIndex(idx);
                                setIsCropOpen(true);
                              }}
                              className="absolute top-1.5 left-1.5 bg-black/75 hover:bg-[#2B6CB0] text-white px-2 py-0.5 rounded-lg text-[10px] font-bold flex items-center gap-1 shadow-xs cursor-pointer border border-white/20 transition-colors"
                              title="تحديد وقص منطقة الجدول"
                            >
                              <Scissors className="w-3 h-3 text-blue-200" />
                              <span>تحديد/قص</span>
                            </button>

                            <span className="absolute bottom-1 right-1 bg-black/70 text-white px-1.5 py-0.5 rounded text-[10px] font-mono">
                              #{idx + 1}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              ) : (
                /* Results View: Students and Grades Extracted */
                <div className="space-y-3.5 animate-in fade-in duration-150">
                  {/* Summary Strip */}
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex flex-wrap items-center justify-between gap-2.5">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-xs sm:text-sm font-bold text-emerald-950 flex items-center gap-2">
                          <span>تم استخراج {extractedStudents.length} طالب بنجاح!</span>
                          {totalWithWrittenScores > 0 && (
                            <span className="px-2 py-0.5 bg-emerald-200/80 text-emerald-900 rounded-md text-[11px] font-semibold">
                              {totalWithWrittenScores} درجة تحريري
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-emerald-800 flex flex-wrap items-center gap-2 mt-0.5 font-semibold">
                          <span>الصف: {gradeLevel}</span>
                          <span>·</span>
                          <span>الشعبة: {section}</span>
                          {matchedExistingCount > 0 && (
                            <>
                              <span>·</span>
                              <span className="text-[#2B6CB0] font-bold">
                                {matchedExistingCount} طالب مسجل مسبقاً
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setHasExtracted(false);
                        setImages([]);
                      }}
                      className="px-2.5 py-1.5 bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold transition-colors cursor-pointer shrink-0 flex items-center gap-1 shadow-2xs"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>مسح ورقة جديدة</span>
                    </button>
                  </div>

                  {/* Integration Settings */}
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <label className="flex items-center gap-2 font-bold text-slate-800 cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={updateExisting}
                          onChange={(e) => setUpdateExisting(e.target.checked)}
                          className="rounded text-[#2B6CB0] focus:ring-[#2B6CB0] w-4 h-4 cursor-pointer"
                        />
                        <span>
                          تحديث درجات الطلاب المسجلين مسبقاً إذا تطابقت أسماؤهم
                        </span>
                      </label>

                      {detectedColumns.length > 0 && (
                        <label className="flex items-center gap-2 font-bold text-slate-800 cursor-pointer select-none">
                          <input
                            type="checkbox"
                            checked={autoAddColumns}
                            onChange={(e) => setAutoAddColumns(e.target.checked)}
                            className="rounded text-[#2B6CB0] focus:ring-[#2B6CB0] w-4 h-4 cursor-pointer"
                          />
                          <span>
                            إضافة الأعمدة المكتشفة ({detectedColumns.map((c) => c.name).join('، ')}) إلى السجل تلقائياً
                          </span>
                        </label>
                      )}
                    </div>
                  </div>

                  {/* Suspicious Name Alert Banner for Extracted Students */}
                  {extractedStudents.some((s) => s.suspectedMatch && !s.confirmedPreviousName) && (
                    <div className="p-3 bg-amber-50 border-2 border-amber-300 rounded-xl flex flex-wrap items-center justify-between gap-2.5 text-xs text-amber-950">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                        <div>
                          <span className="font-black">
                            تم رصد {extractedStudents.filter((s) => s.suspectedMatch && !s.confirmedPreviousName).length} اسم مشتبه به
                          </span>
                          <span className="text-amber-800 mr-1">
                            (يختلف في الهمزة أ/ا أو التاء ة/ه أو تقارب حرفي عن الجدول السابق). تم تمييزها بخلفية ملونة لمراجعتها.
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={handleAdoptAllExtractedPreviousNames}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 shadow-2xs cursor-pointer transition-colors shrink-0"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>اعتماد جميع الأسماء السابقة المطابقة</span>
                      </button>
                    </div>
                  )}

                  {/* Selection and count indicator */}
                  <div className="flex items-center justify-between text-xs px-1">
                    <label className="flex items-center gap-1.5 font-bold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={
                          extractedStudents.length > 0 &&
                          extractedStudents.every((s) => s.selected)
                        }
                        onChange={(e) => handleToggleSelectAll(e.target.checked)}
                        className="rounded text-[#2B6CB0] focus:ring-[#2B6CB0] w-4 h-4 cursor-pointer"
                      />
                      <span>تحديد الكل ({extractedStudents.length})</span>
                    </label>
                    <span className="text-slate-600 font-medium">
                      المحدد للإدخال: <b className="text-emerald-700">{selectedCount}</b> طالب
                    </span>
                  </div>

                  {/* Table of extracted students & scores */}
                  <div className="border border-slate-200 rounded-xl overflow-hidden max-h-[350px] overflow-y-auto bg-white shadow-2xs">
                    <table className="w-full text-right border-collapse text-xs">
                      <thead className="bg-slate-100 text-slate-700 font-bold sticky top-0 z-10 border-b border-slate-200">
                        <tr>
                          <th className="p-2 w-8 text-center">#</th>
                          <th className="p-2 w-8 text-center">اختيار</th>
                          <th className="p-2 min-w-[200px]">اسم الطالب</th>
                          <th className="p-2 w-20">الصف</th>
                          <th className="p-2 w-16">الشعبة</th>
                          <th className="p-2 w-28 bg-emerald-50/80 text-emerald-900 border-x border-emerald-200 text-center">
                            <div className="flex flex-col items-center">
                              <span>الامتحان التحريري</span>
                              <span className="text-[10px] text-emerald-700 font-normal">
                                {writtenMaxScore ? `(من ${writtenMaxScore})` : '(تحريري)'}
                              </span>
                            </div>
                          </th>
                          {effectiveReviewColumns.map((col) => (
                            <th
                              key={col.id || col.name}
                              className="p-2 min-w-[85px] bg-sky-50 text-sky-900 border-x border-sky-200 text-center"
                            >
                              <div className="flex flex-col items-center">
                                <span>{col.name}</span>
                                {col.isNew ? (
                                  <span className="text-[9px] text-amber-700 bg-amber-100 px-1 rounded font-normal">
                                    مكتشف
                                  </span>
                                ) : (
                                  <span className="text-[9px] text-sky-700 font-normal">
                                    عمود بالسجل
                                  </span>
                                )}
                              </div>
                            </th>
                          ))}
                          <th className="p-2 w-24">الحالة / ملاحظات</th>
                          <th className="p-2 w-10 text-center">حذف</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {extractedStudents.map((student, idx) => (
                          <tr
                            key={student.id}
                            className={`hover:bg-slate-50 transition-colors ${
                              !student.selected ? 'opacity-40 bg-slate-50/50' : ''
                            }`}
                          >
                            <td className="p-2 text-center text-slate-400 font-mono">
                              {idx + 1}
                            </td>
                            <td className="p-2 text-center">
                              <input
                                type="checkbox"
                                checked={student.selected}
                                onChange={() => handleToggleStudent(student.id)}
                                className="rounded text-[#2B6CB0] focus:ring-[#2B6CB0] w-4 h-4 cursor-pointer"
                              />
                            </td>
                            <td className="p-2">
                              {student.suspectedMatch && !student.confirmedPreviousName ? (
                                <div className="bg-amber-100/90 border-2 border-amber-400 rounded-xl p-2.5 text-amber-950 shadow-xs space-y-1.5 animate-in fade-in">
                                  <div className="flex items-center gap-1.5">
                                    <input
                                      type="text"
                                      value={student.name}
                                      onBlur={(e) =>
                                        handleUpdateStudent(student.id, 'name', cleanSingleSpaces(e.target.value))
                                      }
                                      onChange={(e) =>
                                        handleUpdateStudent(student.id, 'name', e.target.value)
                                      }
                                      className="w-full px-2 py-1 bg-white border border-amber-300 rounded font-black text-amber-950 text-xs focus:ring-1 focus:ring-amber-500 focus:outline-none"
                                    />
                                  </div>

                                  <div className="text-[11px] font-bold text-amber-950 leading-snug">
                                    هل تقصد <span className="underline decoration-amber-600 font-black">{student.suspectedMatch.matchedName}</span> كما في الجدول السابق؟
                                  </div>
                                  <div className="text-[10px] text-amber-800">
                                    ({student.suspectedMatch.diffDescription})
                                  </div>

                                  <div className="flex items-center gap-1 pt-0.5">
                                    <button
                                      type="button"
                                      onClick={() =>
                                        handleAdoptPreviousName(
                                          student.id,
                                          student.suspectedMatch!.matchedName
                                        )
                                      }
                                      className="px-2 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md text-[11px] font-bold flex items-center gap-1 shadow-2xs cursor-pointer transition-colors"
                                    >
                                      <Check className="w-3 h-3" />
                                      <span>نعم، اعتمد الاسم السابق</span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDismissSuspicion(student.id)}
                                      className="px-2 py-1 bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 rounded-md text-[10px] font-semibold cursor-pointer transition-colors"
                                    >
                                      إبقاء كاسم جديد
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="text"
                                    value={student.name}
                                    onBlur={(e) =>
                                      handleUpdateStudent(student.id, 'name', cleanSingleSpaces(e.target.value))
                                    }
                                    onChange={(e) =>
                                      handleUpdateStudent(student.id, 'name', e.target.value)
                                    }
                                    className="w-full px-2 py-1 bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-[#2B6CB0] rounded font-bold text-slate-800 focus:outline-none text-xs"
                                  />
                                  {student.isExisting && (
                                    <span
                                      title="هذا الطالب مسجل مسبقاً في السجل، وسيتم تحديث درجاته على أساس الاسم حتى لو اختلف التسلسل"
                                      className="shrink-0 px-1.5 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 rounded text-[9px] font-bold flex items-center gap-0.5 whitespace-nowrap"
                                    >
                                      <UserCheck className="w-2.5 h-2.5" />
                                      <span>مسجل مسبقاً</span>
                                    </span>
                                  )}
                                </div>
                              )}
                            </td>
                            <td className="p-2">
                              <input
                                type="text"
                                value={student.gradeLevel}
                                onChange={(e) =>
                                  handleUpdateStudent(student.id, 'gradeLevel', e.target.value)
                                }
                                className="w-full px-1.5 py-1 bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-[#2B6CB0] rounded text-slate-700 text-center focus:outline-none"
                              />
                            </td>
                            <td className="p-2">
                              <input
                                type="text"
                                value={student.section}
                                onChange={(e) =>
                                  handleUpdateStudent(student.id, 'section', e.target.value)
                                }
                                className="w-full px-1.5 py-1 bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-[#2B6CB0] rounded text-center text-slate-700 font-bold focus:outline-none"
                              />
                            </td>

                            {/* Written Raw Score Input */}
                            <td className="p-2 bg-emerald-50/40 border-x border-emerald-100 text-center">
                              <input
                                type="number"
                                step="any"
                                min="0"
                                value={
                                  student.writtenRawScore !== null && student.writtenRawScore !== undefined
                                    ? student.writtenRawScore
                                    : ''
                                }
                                placeholder={student.isAbsent ? 'غائب' : '--'}
                                onChange={(e) => {
                                  const val = e.target.value.trim();
                                  handleUpdateStudent(
                                    student.id,
                                    'writtenRawScore',
                                    val === '' ? null : parseFloat(val)
                                  );
                                }}
                                className="w-20 px-2 py-1 bg-white border border-emerald-300 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-500 rounded text-center font-mono font-bold text-emerald-950 focus:outline-none shadow-2xs"
                              />
                            </td>

                            {/* Custom & Detected Columns Inputs */}
                            {effectiveReviewColumns.map((col) => {
                              const normName = normalizeArabic(col.name);
                              const val =
                                col.id && student.scores[col.id] !== undefined && student.scores[col.id] !== null
                                  ? student.scores[col.id]
                                  : (student.scores[col.name] ?? student.scores[normName] ?? null);

                              return (
                                <td
                                  key={col.id || col.name}
                                  className="p-2 bg-sky-50/30 border-x border-sky-100 text-center"
                                >
                                  <input
                                    type="number"
                                    step="any"
                                    min="0"
                                    value={val !== null && val !== undefined ? val : ''}
                                    placeholder="--"
                                    onChange={(e) =>
                                      handleUpdateCustomScore(student.id, col.name, col.id, e.target.value)
                                    }
                                    className="w-16 px-1.5 py-1 bg-white border border-sky-300 focus:border-sky-600 focus:ring-1 focus:ring-sky-500 rounded text-center font-mono font-bold text-sky-950 focus:outline-none shadow-2xs"
                                  />
                                </td>
                              );
                            })}

                            <td className="p-2">
                              <input
                                type="text"
                                value={student.notes || ''}
                                placeholder={student.isAbsent ? 'غائب' : 'ملاحظة...'}
                                onChange={(e) =>
                                  handleUpdateStudent(student.id, 'notes', e.target.value)
                                }
                                className={`w-full px-1.5 py-1 bg-transparent hover:bg-white focus:bg-white border border-transparent hover:border-slate-300 focus:border-slate-400 rounded text-[11px] focus:outline-none ${
                                  student.isAbsent ? 'text-rose-600 font-bold' : 'text-slate-600'
                                }`}
                              />
                            </td>

                            <td className="p-2 text-center">
                              <button
                                type="button"
                                onClick={() => handleDeleteExtractedStudent(student.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                                title="حذف الطالب"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Prepayment notice if applicable */}
              {isPrepaymentError ? (
                <div className="p-3.5 bg-amber-50 border border-amber-300 rounded-xl text-amber-950 text-xs space-y-2">
                  <div className="font-bold flex items-center gap-1.5 text-amber-900">
                    <AlertCircle className="w-4 h-4 text-amber-700" />
                    <span>ملاحظة حول خدمة الاستخراج:</span>
                  </div>
                  <p className="text-amber-800 text-[11px] leading-relaxed">
                    انتهى رصيد المفتاح الحالي المخصص للخدمة. يمكنك استخدام خيار "إضافة يدوية أو لصق نص" لمتابعة رصد الدرجات مجاناً.
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveTab('manual')}
                    className="inline-flex items-center gap-1 text-xs text-amber-900 hover:text-amber-950 font-bold underline cursor-pointer"
                  >
                    <span>الانتقال إلى الإدخال اليدوي أو اللصق</span>
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : null}

              {/* Error Message with Crop action if images present */}
              {errorMessage && !isPrepaymentError && (
                <div className="space-y-2 animate-in fade-in duration-150">
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2">
                    <div className="shrink-0 mt-0.5">⚠️</div>
                    <div className="flex-1 leading-relaxed font-medium">{errorMessage}</div>
                  </div>

                  {images.length > 0 && (
                    <div className="p-3 bg-slate-50 border border-slate-300 rounded-xl flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2 text-slate-700">
                        <Scissors className="w-4 h-4 text-[#2B6CB0]" />
                        <span>يمكنك تحديد وقص منطقة الجدول في الصورة لزيادة دقة القراءة:</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setCropImageIndex(0);
                          setIsCropOpen(true);
                        }}
                        className="px-3 py-1.5 bg-[#2B6CB0] hover:bg-[#255C96] text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1 shrink-0 cursor-pointer"
                      >
                        <Crop className="w-3.5 h-3.5" />
                        <span>تحديد الجدول الآن</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="shrink-0 px-5 py-3.5 bg-[#F8F4EA] border-t border-[#E0D5C3] flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-[#F2ECE0] text-[#554A3E] border border-[#D8CEBD] rounded-xl font-bold text-xs sm:text-sm transition-colors cursor-pointer"
          >
            إلغاء
          </button>

          {activeTab === 'manual' ? (
            <button
              type="button"
              onClick={handleConfirmManual}
              disabled={parsedManualItems.length === 0}
              className="px-5 py-2.5 craft-btn-primary disabled:opacity-50 text-white rounded-xl font-bold text-xs sm:text-sm shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>إدخال {parsedManualItems.length} طالب إلى السجل</span>
            </button>
          ) : (
            hasExtracted ? (
              <button
                type="button"
                onClick={handleConfirmExtracted}
                disabled={selectedCount === 0}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl font-bold text-xs sm:text-sm shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>
                  تأكيد واستيراد {selectedCount} طالب إلى السجل
                </span>
              </button>
            ) : isTrialLimitReached ? (
              <button
                type="button"
                onClick={() => {
                  setErrorMessage(
                    'تم استخدام المحاولة المجانية المتاحة في النسخة التجريبية. يرجى استخدام خيار "إضافة يدوية أو لصق نص" لإدخال الطلاب مجاناً.'
                  );
                }}
                className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-xs sm:text-sm shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <AlertCircle className="w-4 h-4" />
                <span>تم استنفاد المحاولة التجريبية (1/1)</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleExtractFromImages}
                disabled={images.length === 0 || isProcessing}
                className="px-5 py-2.5 bg-[#5692BE] hover:bg-[#467EAA] disabled:opacity-50 text-white rounded-xl font-bold text-xs sm:text-sm shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>جارٍ استخراج بيانات الطلاب والدرجات...</span>
                  </>
                ) : (
                  <>
                    <Camera className="w-4 h-4" />
                    <span>استخراج بيانات الطلاب ({images.length} صورة)</span>
                  </>
                )}
              </button>
            )
          )}
        </div>
      </div>

      {/* Smart Crop Modal for manual table cropping */}
      <SmartCropModal
        isOpen={isCropOpen}
        onClose={() => setIsCropOpen(false)}
        images={images}
        activeImageIndex={cropImageIndex}
        onApplyCrop={handleApplyCrop}
      />
    </div>
  );
};
