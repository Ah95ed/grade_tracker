import React, { useState, useEffect, useMemo } from 'react';
import {
  MonthlyModel,
  StudentRow,
  CustomColumn,
  TeacherProfile,
  RoundingMode,
  WrittenScoreMode,
  ColumnLabels,
  FinalScoreOperation,
} from '../../types';
import {
  calculateWrittenScore,
  calculateStudentMonthlyTotal,
  applyScoreRounding,
  getRatingDetails,
  getStudentMonthlyScoreBreakdown,
  isWrittenScoreColumn,
  getEffectiveTotalMax,
  getOperationLabel,
} from '../../utils/gradeCalculations';
import {
  Plus,
  UserPlus,
  Trash2,
  FileSpreadsheet,
  Printer,
  Search,
  BookOpen,
  X,
  Sliders,
  Check,
  Calendar,
  Eye,
  EyeOff,
  Calculator,
  Pencil,
  PenLine,
  RotateCcw,
  User,
  ChevronDown,
  AlertTriangle,
} from 'lucide-react';
import { BatchImportModal } from './BatchImportModal';
import { CreateModelModal } from './CreateModelModal';
import { ConfirmDeleteModal } from '../Common/ConfirmDeleteModal';
import { ScoreRoundingModal } from './ScoreRoundingModal';
import { RenameColumnsModal } from './RenameColumnsModal';
import { FinalScoreOperationModal } from './FinalScoreOperationModal';
import { StudentFloatingCloud, ActiveStudentCloudInfo } from '../Common/StudentFloatingCloud';
import { ColumnSlant, getSlantClasses, getNextSlant, SlantButton } from '../Common/ColumnSlantToggle';
import {
  cleanSingleSpaces,
  canonicalizeArabic,
  findSuspectedStudentMatch,
} from '../../utils/arabicNameMatcher';

interface Props {
  models: MonthlyModel[];
  activeModelId: string;
  onSelectModel: (id: string) => void;
  onUpdateModel: (updatedModel: MonthlyModel) => void;
  onUpdateAllModels?: (updatedModels: MonthlyModel[]) => void;
  onDeleteModel: (id: string) => void;
  onAddModel: (newModel: MonthlyModel) => void;
  profile: TeacherProfile;
}

export const MonthlySheetView: React.FC<Props> = ({
  models,
  activeModelId,
  onSelectModel,
  onUpdateModel,
  onUpdateAllModels,
  onDeleteModel,
  onAddModel,
  profile,
}) => {
  const currentModel = models.find((m) => m.id === activeModelId) || models[0];

  const [isBatchImportOpen, setIsBatchImportOpen] = useState(false);
  const [isCreateModelOpen, setIsCreateModelOpen] = useState(false);

  // Students from other monthly models/sheets to verify and cross-match against
  const otherModelsStudents = useMemo(() => {
    if (!models || models.length === 0) return [];
    const list: Array<{ id: string; name: string; modelName?: string }> = [];
    const seen = new Set<string>();

    for (const m of models) {
      if (currentModel && m.id === currentModel.id) continue;
      for (const st of m.students || []) {
        const cleaned = cleanSingleSpaces(st.name);
        if (cleaned && !seen.has(cleaned)) {
          seen.add(cleaned);
          list.push({ id: st.id, name: cleaned, modelName: m.name });
        }
      }
    }
    return list;
  }, [models, currentModel?.id]);

  // Quick "Add Column" Modal state
  const [isAddingColumn, setIsAddingColumn] = useState(false);
  const [newColName, setNewColName] = useState('');
  const [newColMax, setNewColMax] = useState<number>(20);

  // Score Rounding Modal state
  const [isRoundingModalOpen, setIsRoundingModalOpen] = useState(false);
  // Final Score Math Operation Modal state (divide by number, multiply, add, subtract, none)
  const [isFinalOperationModalOpen, setIsFinalOperationModalOpen] = useState(false);

  // Search & Filter (embedded directly inside the table column headers)
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGradeLevel, setSelectedGradeLevel] = useState('ALL');
  const [selectedSection, setSelectedSection] = useState('ALL');

  // Column header slant/orientation (normal | italic | vertical)
  const [columnSlants, setColumnSlants] = useState<Record<string, ColumnSlant>>(() => {
    try {
      if (!currentModel?.id) return {};
      const saved = localStorage.getItem(`daragat_monthly_slants_${currentModel.id}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const toggleColumnSlant = (colKey: string) => {
    setColumnSlants((prev) => {
      const next = getNextSlant(prev[colKey]);
      const updated = { ...prev, [colKey]: next };
      if (currentModel?.id) {
        try {
          localStorage.setItem(`daragat_monthly_slants_${currentModel.id}`, JSON.stringify(updated));
        } catch {}
      }
      return updated;
    });
  };

  // Floating student info cloud badge when horizontally scrolling table
  const [activeStudentCloud, setActiveStudentCloud] = useState<ActiveStudentCloudInfo | null>(null);
  const activeRowRef = React.useRef<HTMLTableRowElement | null>(null);
  const tableContainerRef = React.useRef<HTMLDivElement | null>(null);
  const [isNameColumnVisible, setIsNameColumnVisible] = useState(true);

  // Check if student name column is visible within the table container during horizontal scroll
  const checkNameColumnVisibility = React.useCallback(() => {
    if (!tableContainerRef.current) return;
    const container = tableContainerRef.current;
    const nameCell = container.querySelector('[data-student-name-column="true"]') as HTMLElement | null;
    if (!nameCell) return;
    const nameRect = nameCell.getBoundingClientRect();
    const containerRect = container.getBoundingClientRect();

    const visibleLeft = Math.max(nameRect.left, containerRect.left);
    const visibleRight = Math.min(nameRect.right, containerRect.right);
    const visibleWidth = Math.max(0, visibleRight - visibleLeft);

    setIsNameColumnVisible(visibleWidth >= 60);
  }, []);

  // Keep floating badge locked with row vertically during scroll & update visibility
  useEffect(() => {
    const handleScrollOrResize = () => {
      if (activeRowRef.current && activeStudentCloud) {
        const rect = activeRowRef.current.getBoundingClientRect();
        setActiveStudentCloud((prev) => (prev ? { ...prev, rowTop: rect.top } : null));
      }
      checkNameColumnVisibility();
    };

    checkNameColumnVisibility();

    window.addEventListener('scroll', handleScrollOrResize, true);
    window.addEventListener('resize', handleScrollOrResize);
    return () => {
      window.removeEventListener('scroll', handleScrollOrResize, true);
      window.removeEventListener('resize', handleScrollOrResize);
    };
  }, [activeStudentCloud, checkNameColumnVisibility]);

  // Dismiss floating badge when clicking outside the table
  useEffect(() => {
    if (!activeStudentCloud) return;

    const handlePointerDownOutside = (event: MouseEvent | TouchEvent) => {
      const target = event.target as HTMLElement | null;
      if (!target) return;

      if (tableContainerRef.current?.contains(target)) return;
      if (target.closest?.('[data-student-floating-cloud="true"]')) return;
      if (target.closest?.('[data-floating-cloud-toggle="true"]')) return;

      setActiveStudentCloud(null);
    };

    document.addEventListener('pointerdown', handlePointerDownOutside);
    return () => {
      document.removeEventListener('pointerdown', handlePointerDownOutside);
    };
  }, [activeStudentCloud]);

  const handleScoreCellFocus = (
    e: React.FocusEvent<HTMLElement> | React.MouseEvent<HTMLElement>,
    student: StudentRow
  ) => {
    const rowEl = (e.currentTarget.closest('tr') || e.currentTarget) as HTMLTableRowElement;
    if (rowEl) {
      activeRowRef.current = rowEl;
      const rect = rowEl.getBoundingClientRect();
      setActiveStudentCloud({
        studentId: student.id,
        name: student.name,
        section: student.section,
        rowTop: rect.top,
      });
      checkNameColumnVisibility();
    }
  };

  // Confirmation Alert Modal State (Ensures any deletion requires explicit confirmation)
  const [confirmDelete, setConfirmDelete] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmText?: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  // Action Prompt Modal State (Informs user about Export / Print before executing)
  const [actionPrompt, setActionPrompt] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmText: string;
    confirmColor: string;
    icon: React.ReactNode;
    onConfirm: () => void;
  } | null>(null);

  // Floating overlay state shown in front of the page (position: fixed) right after creating a model
  const [newlyCreatedModel, setNewlyCreatedModel] = useState<MonthlyModel | null>(null);

  // Column Renaming states (Modal + Inline in Table Headers)
  const [isRenameColumnsModalOpen, setIsRenameColumnsModalOpen] = useState(false);
  const [editingColumnKey, setEditingColumnKey] = useState<string | null>(null);
  const [inlineEditValue, setInlineEditValue] = useState<string>('');

  // Rating Column visibility preference (hidden by default)
  const [showRatingColumn, setShowRatingColumn] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gradebook_show_rating_col') === 'true';
    } catch {
      return false;
    }
  });

  const toggleRatingColumn = () => {
    setShowRatingColumn((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('gradebook_show_rating_col', String(next));
      } catch (e) {
        console.error(e);
      }
      return next;
    });
  };

  const handleModelCreated = (newModel: MonthlyModel) => {
    // Check if this is the very first model before adding it
    const isFirstModel = models.length === 0;
    onAddModel(newModel);
    // Show prompt overlay to add students ONLY for the very first model
    if (isFirstModel) {
      setNewlyCreatedModel(newModel);
    }
  };

  // Ensure consistency: if models have different totalMaxScore, sync them with the first/active model
  useEffect(() => {
    if (models.length > 1 && onUpdateAllModels) {
      const refMax = models[0]?.totalMaxScore;
      if (refMax && refMax > 0) {
        const hasMismatch = models.some((m, idx) => idx > 0 && m.totalMaxScore !== refMax);
        if (hasMismatch) {
          const synced = models.map((m) => {
            const hasNoCustomCols = (m.customColumns || []).length === 0;
            return {
              ...m,
              totalMaxScore: refMax,
              writtenMaxScore: hasNoCustomCols ? refMax : m.writtenMaxScore,
              updatedAt: new Date().toISOString(),
            };
          });
          onUpdateAllModels(synced);
        }
      }
    }
  }, []);

  // Check if any student in the active model has decimal / fractional scores, or if rounding is configured
  // CRITICAL: Placed BEFORE early return to strictly follow React Rules of Hooks!
  const hasDecimalScores = useMemo(() => {
    if (!currentModel || !currentModel.students) return false;
    const hasRawDecimals = currentModel.students.some((student) => {
      const raw = calculateStudentMonthlyTotal(student, currentModel, true);
      if (raw === null || raw === undefined) return false;
      return Math.abs(raw - Math.round(raw)) > 0.001;
    });
    return hasRawDecimals || (currentModel.roundingMode !== undefined && currentModel.roundingMode !== 'none');
  }, [currentModel]);

  if (!currentModel) {
    return (
      <div className="space-y-4">
        {/* Full-width "إنشاء نموذج لمادة ..." button */}
        <div className="no-print">
          <button
            type="button"
            onClick={() => setIsCreateModelOpen(true)}
            className="w-full py-2.5 px-4 bg-[#557A95] hover:bg-[#476A84] active:scale-99 text-white rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 shadow-xs"
            title={`جدول درجات جديد لمادة ${profile.subject || 'المادة'}`}
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>جدول درجات جديد لمادة {profile.subject || 'المادة'}</span>
          </button>
        </div>

        <div className="bg-white rounded-2xl border border-[#E8E4DA] p-8 sm:p-12 text-center shadow-xs max-w-lg mx-auto my-8 space-y-4">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-[#EEF4F8] border border-[#D2E0EC] flex items-center justify-center text-[#557A95] shadow-xs">
            <Calendar className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-xl font-black text-[#2E2B27]">لا يوجد أي نموذج شهري حالياً</h2>
            <p className="text-sm text-[#7A746B] mt-1.5 leading-relaxed">
              جدول النماذج فارغ حالياً. يمكنك استخدام الزر بالأعلى لإنشاء أول نموذج والبدء برصد الدرجات.
            </p>
          </div>

          <CreateModelModal
            isOpen={isCreateModelOpen}
            onClose={() => setIsCreateModelOpen(false)}
            currentModel={undefined}
            allModels={models}
            onCreate={handleModelCreated}
          />
        </div>
      </div>
    );
  }

  // Real-time calculation of distributed scores vs total max score
  const totalMax = Number(currentModel.totalMaxScore) || 100;
  const customSum = (currentModel.customColumns || []).reduce(
    (sum, col) => sum + Number(col.maxScore || 0),
    0
  );
  // Automatic written weight = totalMax - customSum (e.g. 100 - 20 = 80, or 10 - 2 = 8)
  const autoWrittenWeight = Math.max(0, totalMax - customSum);
  const effectiveWrittenWeight = autoWrittenWeight;
  // Rule: "الدرجة كما في ورقة الطالب" (raw) is active automatically by default,
  // without depending on whether written test score is less than or equal to total max score.
  // "الدرجة النسبية للطالب" (relative) is only active if the teacher explicitly enables it.
  const writtenScoreMode: WrittenScoreMode = currentModel.writtenScoreMode || 'raw';

  const handleUpdateScoreMode = (newMode: 'relative' | 'raw') => {
    if (onUpdateAllModels && models.length > 0) {
      const updatedModels = models.map((m) => ({
        ...m,
        writtenScoreMode: newMode,
        updatedAt: new Date().toISOString(),
      }));
      onUpdateAllModels(updatedModels);
    } else {
      onUpdateModel({
        ...currentModel,
        writtenScoreMode: newMode,
        updatedAt: new Date().toISOString(),
      });
    }
  };

  const rawWrittenMax = currentModel.writtenMaxScore || 0;
  // If in 'raw' mode (الدرجة كما في ورقة الطالب):
  // When custom columns exist (e.g. written 80 + oral 20), allocatedTotal is rawWrittenMax + customSum = 100
  // When no custom columns exist, allocatedTotal is rawWrittenMax (or totalMax)
  // In 'relative' mode (الدرجة النسبية للطالب): calculates weight distribution (effectiveWrittenWeight + customSum)
  const allocatedTotal =
    writtenScoreMode === 'raw'
      ? (customSum > 0 ? rawWrittenMax + customSum : (rawWrittenMax || totalMax))
      : Math.min(totalMax, effectiveWrittenWeight + customSum);
  const remainingScore = totalMax - allocatedTotal;

  // Final Score Math Operation (division, multiplication, addition, subtraction, or none)
  const finalOp = currentModel.finalScoreOperation;
  const hasFinalOp = Boolean(
    finalOp &&
      finalOp.type &&
      finalOp.type !== 'none' &&
      Number(finalOp.value) > 0
  );
  const finalOpLabel = getOperationLabel(finalOp);
  const effectiveTotalMax = getEffectiveTotalMax(currentModel);

  // Breakdown text for custom columns (e.g. "20 درجة شفهي" or "20 درجة شفهي + 10 درجة نشاط")
  const customBreakdownText = (currentModel.customColumns || [])
    .map((col) => {
      const score = col.maxScore || 0;
      const name = (col.name || 'إضافي').trim();
      return name.startsWith('درجة') ? `${score} ${name}` : `${score} درجة ${name}`;
    })
    .join(' + ');

  // Column Titles / Labels (customizable with defaults)
  const studentNameLabel = currentModel.columnLabels?.studentName?.trim() || 'اسم الطالب';
  const gradeLevelLabel = currentModel.columnLabels?.gradeLevel?.trim() || 'الصف';
  const sectionLabel = currentModel.columnLabels?.section?.trim() || 'الشعبة';
  // User requirement: "جدول تحريري من اجعلها درجه التحريري بالورقه من مع امكانيه اعاده تسميه لكل عناوين الاعمده"
  const writtenExamLabel = currentModel.columnLabels?.writtenExam?.trim() || 'درجة التحريري بالورقة من';
  const finalScoreLabel = currentModel.columnLabels?.finalScore?.trim() || 'الدرجة النهائية من';
  const ratingLabel = currentModel.columnLabels?.rating?.trim() || 'التقدير';

  const handleStartInlineEdit = (key: string, currentVal: string) => {
    setEditingColumnKey(key);
    setInlineEditValue(currentVal);
  };

  const handleSaveInlineColumnRename = (key: keyof ColumnLabels) => {
    const trimmed = inlineEditValue.trim();
    if (!trimmed) {
      setEditingColumnKey(null);
      return;
    }
    if (onUpdateAllModels && models.length > 0) {
      const updatedModels = models.map((m) => ({
        ...m,
        columnLabels: {
          ...(m.columnLabels || {}),
          [key]: trimmed,
        },
        updatedAt: new Date().toISOString(),
      }));
      onUpdateAllModels(updatedModels);
    } else {
      onUpdateModel({
        ...currentModel,
        columnLabels: {
          ...(currentModel.columnLabels || {}),
          [key]: trimmed,
        },
        updatedAt: new Date().toISOString(),
      });
    }
    setEditingColumnKey(null);
  };

  const handleSaveInlineCustomColRename = (colId: string) => {
    const trimmed = inlineEditValue.trim();
    if (!trimmed) {
      setEditingColumnKey(null);
      return;
    }
    if (onUpdateAllModels && models.length > 0) {
      const updatedModels = models.map((m) => ({
        ...m,
        customColumns: (m.customColumns || []).map((c) =>
          c.id === colId ? { ...c, name: trimmed } : c
        ),
        updatedAt: new Date().toISOString(),
      }));
      onUpdateAllModels(updatedModels);
    } else {
      onUpdateModel({
        ...currentModel,
        customColumns: (currentModel.customColumns || []).map((c) =>
          c.id === colId ? { ...c, name: trimmed } : c
        ),
        updatedAt: new Date().toISOString(),
      });
    }
    setEditingColumnKey(null);
  };

  // Update total final maximum score (can be edited directly in the final score column)
  const handleUpdateTotalMaxScore = (newMax: number) => {
    try {
      if (newMax > 0) {
        localStorage.setItem('gradebook_last_total_max_score', String(newMax));
      }
    } catch {}

    if (onUpdateAllModels && models.length > 0) {
      const updatedModels = models.map((m) => {
        const hasNoCustomCols = (m.customColumns || []).length === 0;
        const targetWritten = hasNoCustomCols ? newMax : (m.writtenMaxScore || 0);
        return {
          ...m,
          totalMaxScore: newMax,
          writtenMaxScore: targetWritten,
          writtenScoreMode: m.writtenScoreMode || 'raw',
          writtenWeight: null,
          updatedAt: new Date().toISOString(),
        };
      });
      onUpdateAllModels(updatedModels);
    } else {
      const hasNoCustomCols = (currentModel.customColumns || []).length === 0;
      const targetWritten = hasNoCustomCols ? newMax : (currentModel.writtenMaxScore || 0);
      onUpdateModel({
        ...currentModel,
        totalMaxScore: newMax,
        writtenMaxScore: targetWritten,
        writtenScoreMode: currentModel.writtenScoreMode || 'raw',
        writtenWeight: null,
        updatedAt: new Date().toISOString(),
      });
    }
  };

  // Calculate effective percentage of written exam
  const effectiveWrittenPercentage = totalMax > 0 ? Math.round((effectiveWrittenWeight / totalMax) * 100) : 100;

  // When opening the column modal, suggest the preset name and remaining score
  const handleOpenAddColumn = () => {
    if ((currentModel.customColumns || []).length === 0) {
      setNewColName('درجة الشفهي');
    } else {
      setNewColName('');
    }
    const suggested = totalMax === 10 ? 2 : totalMax === 100 ? 20 : Math.max(1, Math.round(totalMax * 0.2));
    setNewColMax(suggested);
    setIsAddingColumn(true);
  };

  const handleSaveRounding = (newMode: RoundingMode, newThreshold: number, applyToAll: boolean) => {
    if (applyToAll && onUpdateAllModels) {
      const updated = models.map((m) => ({
        ...m,
        roundingMode: newMode,
        roundingThreshold: newThreshold,
        updatedAt: new Date().toISOString(),
      }));
      onUpdateAllModels(updated);
    } else {
      onUpdateModel({
        ...currentModel,
        roundingMode: newMode,
        roundingThreshold: newThreshold,
        updatedAt: new Date().toISOString(),
      });
    }
  };

  const handleSaveFinalScoreOperation = (
    operation: FinalScoreOperation,
    applyToAll: boolean
  ) => {
    if (applyToAll && onUpdateAllModels) {
      const updated = models.map((m) => ({
        ...m,
        finalScoreOperation: operation,
        updatedAt: new Date().toISOString(),
      }));
      onUpdateAllModels(updated);
    } else {
      onUpdateModel({
        ...currentModel,
        finalScoreOperation: operation,
        updatedAt: new Date().toISOString(),
      });
    }
  };

  // Student updates - Synchronizes Name, GradeLevel, and Section across ALL monthly models by unique student.id
  const handleUpdateStudent = (studentId: string, updates: Partial<StudentRow>) => {
    const hasProfileField =
      'name' in updates || 'gradeLevel' in updates || 'section' in updates;

    if (hasProfileField && onUpdateAllModels) {
      const profileUpdates: Partial<StudentRow> = {};
      if ('name' in updates) profileUpdates.name = updates.name;
      if ('gradeLevel' in updates) profileUpdates.gradeLevel = updates.gradeLevel;
      if ('section' in updates) profileUpdates.section = updates.section;

      const updatedModels = models.map((m) => {
        if (m.id === currentModel.id) {
          return {
            ...m,
            students: m.students.map((st) =>
              st.id === studentId ? { ...st, ...updates } : st
            ),
            updatedAt: new Date().toISOString(),
          };
        }

        // Check if student exists in this other model by unique ID
        const exists = m.students.some((st) => st.id === studentId);
        if (!exists) {
          // If the student doesn't exist in this model yet, add them so all models have all students
          const curSt = currentModel.students.find((s) => s.id === studentId);
          return {
            ...m,
            students: [
              ...m.students,
              {
                id: studentId, // EXACT SAME ID
                name: updates.name !== undefined ? updates.name : (curSt?.name || ''),
                gradeLevel: updates.gradeLevel !== undefined ? updates.gradeLevel : (curSt?.gradeLevel || 'الأول متوسط'),
                section: updates.section !== undefined ? updates.section : (curSt?.section || 'أ'),
                writtenRawScore: null,
                scores: {},
                notes: '',
              },
            ],
            updatedAt: new Date().toISOString(),
          };
        }

        // Student exists: ONLY update their name/gradeLevel/section, keeping all their scores in this month intact!
        return {
          ...m,
          students: m.students.map((st) =>
            st.id === studentId ? { ...st, ...profileUpdates } : st
          ),
          updatedAt: new Date().toISOString(),
        };
      });

      onUpdateAllModels(updatedModels);
    } else {
      // Score-only updates or local changes: ONLY update the current model
      const updatedStudents = currentModel.students.map((st) =>
        st.id === studentId ? { ...st, ...updates } : st
      );
      onUpdateModel({
        ...currentModel,
        students: updatedStudents,
        updatedAt: new Date().toISOString(),
      });
    }
  };

  const handleUpdateStudentCustomScore = (
    studentId: string,
    colId: string,
    scoreValue: string
  ) => {
    const numericScore = scoreValue === '' ? null : Number(scoreValue);
    const student = currentModel.students.find((s) => s.id === studentId);
    if (!student) return;

    const newScores = {
      ...student.scores,
      [colId]: numericScore,
    };
    handleUpdateStudent(studentId, { scores: newScores });
  };

  // Add single student row - Propagates with the EXACT same unique studentId to all monthly models!
  const handleAddRow = () => {
    const newStudentId = 'st-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7);
    const initialGrade = currentModel.students[0]?.gradeLevel || 'الأول متوسط';
    const initialSection = currentModel.students[0]?.section || (allSections[0] || 'أ');

    const newStudent: StudentRow = {
      id: newStudentId,
      name: '',
      gradeLevel: initialGrade,
      section: initialSection,
      writtenRawScore: null,
      scores: {},
      notes: '',
    };

    if (onUpdateAllModels) {
      const updatedModels = models.map((m) => ({
        ...m,
        students: [
          ...m.students,
          {
            id: newStudentId, // EXACT SAME ID ACROSS ALL MODELS
            name: '',
            gradeLevel: initialGrade,
            section: initialSection,
            writtenRawScore: null,
            scores: {},
            notes: '',
          },
        ],
        updatedAt: new Date().toISOString(),
      }));
      onUpdateAllModels(updatedModels);
    } else {
      onUpdateModel({
        ...currentModel,
        students: [...currentModel.students, newStudent],
        updatedAt: new Date().toISOString(),
      });
    }
  };

  // Delete a student row WITH CONFIRMATION ALERT - Deletes from all monthly models to keep student lists identical!
  const requestDeleteRow = (studentId: string) => {
    const student = currentModel.students.find((st) => st.id === studentId);
    const studentLabel = student?.name?.trim() ? `الطالب (${student.name})` : 'هذا الطالب';
    setConfirmDelete({
      isOpen: true,
      title: `تنبيه: تأكيد حذف صف ${studentLabel}`,
      message: `هل أنت متأكد من حذف ${studentLabel}؟ سيتم حذف الطالب من جميع الشهور والنماذج لضمان تطابق قوائم الطلاب.`,
      confirmText: 'نعم، احذف الطالب من كافة الشهور',
      onConfirm: () => {
        if (onUpdateAllModels) {
          const updatedModels = models.map((m) => ({
            ...m,
            students: m.students.filter((st) => st.id !== studentId),
            updatedAt: new Date().toISOString(),
          }));
          onUpdateAllModels(updatedModels);
        } else {
          onUpdateModel({
            ...currentModel,
            students: currentModel.students.filter((st) => st.id !== studentId),
            updatedAt: new Date().toISOString(),
          });
        }
      },
    });
  };

  // Clear all students WITH CONFIRMATION ALERT
  const requestClearAllStudents = () => {
    setConfirmDelete({
      isOpen: true,
      title: `تأكيد مسح جميع الطلاب للبدء من الصفر`,
      message: `هل أنت متأكد من الاستمرار في مسح كافة الطلاب (${currentModel.students.length} طالب) من جميع الشهور والنماذج للبدء من الصفر؟`,
      confirmText: 'نعم، استمر في مسح الكل',
      onConfirm: () => {
        if (onUpdateAllModels) {
          const updatedModels = models.map((m) => ({
            ...m,
            students: [],
            updatedAt: new Date().toISOString(),
          }));
          onUpdateAllModels(updatedModels);
        } else {
          onUpdateModel({
            ...currentModel,
            students: [],
            updatedAt: new Date().toISOString(),
          });
        }
      },
    });
  };

  // Delete Model WITH CONFIRMATION ALERT
  const requestDeleteModel = (id: string) => {
    const modelToDelete = models.find((m) => m.id === id) || currentModel;
    setConfirmDelete({
      isOpen: true,
      title: `تأكيد حذف نموذج (${modelToDelete.name})`,
      message: `هل أنت متأكد من الاستمرار في حذف نموذج (${modelToDelete.name}) بالكامل؟ سيتم حذف جميع درجات وطلاب هذا الشهر ولا يمكن استرجاعها.`,
      confirmText: `نعم، استمر في حذف ${modelToDelete.name}`,
      onConfirm: () => onDeleteModel(id),
    });
  };

  // Delete a custom column WITH CONFIRMATION ALERT
  const requestDeleteColumn = (colId: string) => {
    const col = (currentModel.customColumns || []).find((c) => c.id === colId);
    if (!col) return;
    setConfirmDelete({
      isOpen: true,
      title: `تأكيد حذف عمود (${col.name})`,
      message: `هل أنت متأكد من الاستمرار في حذف عمود (${col.name})؟ سيتم حذف جميع درجات الطلاب المسجلة في هذا الحقل نهائياً.`,
      confirmText: `نعم، استمر في حذف (${col.name})`,
      onConfirm: () => {
        onUpdateModel({
          ...currentModel,
          customColumns: (currentModel.customColumns || []).filter((c) => c.id !== colId),
          updatedAt: new Date().toISOString(),
        });
      },
    });
  };

  const normalizeArabicName = (str: string): string => {
    return (str || '')
      .replace(/[أإآ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/[\u064B-\u065F\u0670]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const handleBatchImport = (
    importedRows: Partial<StudentRow>[],
    options?: {
      updateExisting?: boolean;
      newCustomColumns?: Array<{ name: string; maxScore?: number }>;
    }
  ) => {
    const shouldUpdateExisting = options?.updateExisting !== false;

    // 1) Clean up any existing accidental redundant written column and map custom columns
    let updatedCustomColumns = [...(currentModel.customColumns || [])].filter(
      (c) => !isWrittenScoreColumn(c.name)
    );
    const colNameToIdMap: Record<string, string> = {};

    for (const c of updatedCustomColumns) {
      const norm = normalizeArabicName(c.name);
      colNameToIdMap[c.name] = c.id;
      colNameToIdMap[norm] = c.id;
      colNameToIdMap[norm.replace(/^ال/, '')] = c.id;
    }

    if (options?.newCustomColumns && options.newCustomColumns.length > 0) {
      for (const newCol of options.newCustomColumns) {
        // Absolutely NEVER create a written exam column as an extra custom column
        if (isWrittenScoreColumn(newCol.name)) continue;

        const normNewCol = normalizeArabicName(newCol.name);
        const strippedNewCol = normNewCol.replace(/^ال/, '');

        const existingCol = updatedCustomColumns.find((c) => {
          const normC = normalizeArabicName(c.name);
          const strippedC = normC.replace(/^ال/, '');
          return normC === normNewCol || c.name === newCol.name || strippedC === strippedNewCol;
        });

        if (existingCol) {
          colNameToIdMap[newCol.name] = existingCol.id;
          colNameToIdMap[normNewCol] = existingCol.id;
          colNameToIdMap[strippedNewCol] = existingCol.id;
        } else {
          const newId = 'col-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
          const defMax = newCol.maxScore || (totalMax === 10 ? 2 : 20);
          updatedCustomColumns.push({
            id: newId,
            name: newCol.name,
            maxScore: defMax,
          });
          colNameToIdMap[newCol.name] = newId;
          colNameToIdMap[normNewCol] = newId;
          colNameToIdMap[strippedNewCol] = newId;
        }
      }
    }

    // Helper to map row.scores (which may contain column names or column ids) to column IDs
    const resolveScores = (rawScores: Record<string, number | null> | undefined) => {
      const result: Record<string, number | null> = {};
      if (!rawScores) return result;
      for (const [key, val] of Object.entries(rawScores)) {
        if (val === null || val === undefined || isNaN(Number(val))) continue;
        const numVal = Number(val);

        // Written exam scores belong exclusively in writtenRawScore, NEVER in student.scores
        if (isWrittenScoreColumn(key) || key === 'written') continue;

        if (updatedCustomColumns.some((c) => c.id === key)) {
          result[key] = numVal;
          continue;
        }
        const normKey = normalizeArabicName(key);
        const strippedKey = normKey.replace(/^ال/, '');
        const mappedId = colNameToIdMap[key] || colNameToIdMap[normKey] || colNameToIdMap[strippedKey];
        if (mappedId) {
          result[mappedId] = numVal;
        } else {
          result[key] = numVal;
        }
      }
      return result;
    };

    // 2) Partition into updates for existing students and new students to append
    // Crucial rule: Matching is strictly BY NAME, regardless of student sequence order in the table
    const currentStudentsCopy = currentModel.students.map((st) => ({
      ...st,
      scores: { ...(st.scores || {}) },
    }));

    const brandNewStudents: StudentRow[] = [];

    for (const row of importedRows) {
      const cleanedRowName = cleanSingleSpaces(row.name || '');
      if (!cleanedRowName) continue;

      let matchedIdx: number = -1;

      if (shouldUpdateExisting) {
        // Priority 1: Exact match after single-space normalization
        matchedIdx = currentStudentsCopy.findIndex(
          (st) => cleanSingleSpaces(st.name) === cleanedRowName
        );

        // Priority 2: Canonical Arabic match (handles differences in أ / ا, ة / ه, ى / ي, tashkeel, etc.)
        if (matchedIdx === -1) {
          const rowCanon = canonicalizeArabic(cleanedRowName);
          matchedIdx = currentStudentsCopy.findIndex(
            (st) => canonicalizeArabic(st.name) === rowCanon
          );
        }

        // Priority 3: Fuzzy / typo match (Levenshtein / OCR confusions like جيدر vs حيدر)
        if (matchedIdx === -1) {
          const suspected = findSuspectedStudentMatch(cleanedRowName, currentStudentsCopy);
          if (suspected && suspected.matchedId) {
            matchedIdx = currentStudentsCopy.findIndex((st) => st.id === suspected.matchedId);
          }
        }
      }

      const resolvedScores = resolveScores(row.scores);
      let writtenScore =
        row.writtenRawScore !== undefined && row.writtenRawScore !== null && !isNaN(Number(row.writtenRawScore))
          ? Number(row.writtenRawScore)
          : null;

      // If writtenRawScore was null but row.scores contained a written exam grade
      if (writtenScore === null && row.scores) {
        for (const [k, v] of Object.entries(row.scores)) {
          if ((isWrittenScoreColumn(k) || k === 'written') && v !== null && v !== undefined && !isNaN(Number(v))) {
            writtenScore = Number(v);
            break;
          }
        }
      }

      if (matchedIdx !== -1) {
        const target = currentStudentsCopy[matchedIdx];
        if (writtenScore !== null) {
          target.writtenRawScore = writtenScore;
        }
        target.scores = {
          ...target.scores,
          ...resolvedScores,
        };
        if (row.gradeLevel) {
          target.gradeLevel = row.gradeLevel;
        }
        if (row.section) {
          target.section = row.section;
        }
        if (row.notes) {
          target.notes = row.notes;
        }
      } else {
        const newSt: StudentRow = {
          id: 'st-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
          name: cleanedRowName,
          gradeLevel: row.gradeLevel || currentModel.students[0]?.gradeLevel || 'الأول متوسط',
          section: row.section || (allSections[0] || 'أ'),
          writtenRawScore: writtenScore,
          scores: resolvedScores,
          notes: row.notes || '',
        };
        brandNewStudents.push(newSt);
      }
    }

    const finalStudents = [...currentStudentsCopy, ...brandNewStudents];

    // 3) Update models
    if (onUpdateAllModels) {
      const updatedModels = models.map((m) => {
        const isCurrent = m.id === currentModel.id;
        return {
          ...m,
          customColumns: isCurrent ? updatedCustomColumns : m.customColumns,
          students: isCurrent
            ? finalStudents
            : [
                ...m.students,
                ...brandNewStudents.map((st) => ({
                  id: st.id,
                  name: st.name,
                  gradeLevel: st.gradeLevel,
                  section: st.section,
                  writtenRawScore: null,
                  scores: {},
                  notes: '',
                })),
              ],
          updatedAt: new Date().toISOString(),
        };
      });
      onUpdateAllModels(updatedModels);
    } else {
      onUpdateModel({
        ...currentModel,
        customColumns: updatedCustomColumns,
        students: finalStudents,
        updatedAt: new Date().toISOString(),
      });
    }
  };

  // Add new custom column
  const handleAddNewColumn = (nameToAdd?: string, maxToAdd?: number) => {
    const name = (nameToAdd || newColName).trim();
    const max = maxToAdd !== undefined ? maxToAdd : newColMax;
    if (!name) return;

    const newCol: CustomColumn = {
      id: 'col-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      name,
      maxScore: Number(max) || (totalMax === 10 ? 2 : 10),
    };

    onUpdateModel({
      ...currentModel,
      writtenWeight: null, // Clear any manual weight so calculation is always automatic
      customColumns: [...(currentModel.customColumns || []), newCol],
      updatedAt: new Date().toISOString(),
    });

    setNewColName('');
    const suggested = totalMax === 10 ? 2 : totalMax === 100 ? 20 : Math.max(1, Math.round(totalMax * 0.2));
    setNewColMax(suggested);
    setIsAddingColumn(false);
  };

  // Delete a custom column DIRECTLY
  const handleDeleteColumn = (colId: string) => {
    onUpdateModel({
      ...currentModel,
      writtenWeight: null,
      customColumns: (currentModel.customColumns || []).filter((c) => c.id !== colId),
      updatedAt: new Date().toISOString(),
    });
  };

  // Quick preset columns based on totalMax (10 or 100 or custom)
  const presets = totalMax === 10 ? [
    { name: 'درجة الشفهي', max: 2 },
    { name: 'المشاركة والنشاط', max: 1 },
    { name: 'الواجبات اليومية', max: 1 },
    { name: 'السلوك والمواظبة', max: 1 },
  ] : [
    { name: 'درجة الشفهي', max: 20 },
    { name: 'المشاركة والنشاط', max: 10 },
    { name: 'الواجبات اليومية', max: 10 },
    { name: 'السلوك والمواظبة', max: 10 },
  ];

  // Grade levels and sections list for filter
  const allGradeLevels = Array.from(
    new Set(currentModel.students.map((s) => s.gradeLevel).filter(Boolean))
  );
  const allSections = Array.from(
    new Set(currentModel.students.map((s) => s.section).filter(Boolean))
  );

  // Filter students
  const filteredStudents = currentModel.students.filter((st) => {
    const matchName = st.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchGrade = selectedGradeLevel === 'ALL' || st.gradeLevel === selectedGradeLevel;
    const matchSection = selectedSection === 'ALL' || st.section === selectedSection;
    return matchName && matchGrade && matchSection;
  });

  const hasStudents = currentModel.students.length > 0;

  // Export to CSV
  const handleExportCSV = () => {
    const isRelative = writtenScoreMode === 'relative';
    const exportGradeLabel = gradeLevelLabel === 'الصف' ? 'الصف الدراسي' : gradeLevelLabel;
    const exportSectionLabel = 'الشعبة';
    const exportWrittenLabel = 'التحريري';
    const effectiveTotalMax = getEffectiveTotalMax(currentModel);
    const finalOpLabel = getOperationLabel(currentModel.finalScoreOperation);
    const exportFinalScoreLabel = finalOpLabel
      ? `النهائي (${finalOpLabel}) من ${effectiveTotalMax}`
      : `النهائي (من ${effectiveTotalMax})`;

    const headers = [
      'م',
      studentNameLabel,
      exportGradeLabel,
      exportSectionLabel,
      exportWrittenLabel,
      ...(isRelative && customSum > 0 ? [`درجة التحريري المحسوبة (من ${effectiveWrittenWeight})`] : []),
      ...(currentModel.customColumns || []).map((c) => `${c.name} (من ${c.maxScore})`),
      exportFinalScoreLabel,
      ratingLabel,
    ];

    const rows = currentModel.students.map((st, idx) => {
      const writtenCalc = calculateWrittenScore(
        st.writtenRawScore,
        currentModel.writtenMaxScore,
        effectiveWrittenWeight,
        currentModel.totalMaxScore,
        writtenScoreMode
      );
      const total = calculateStudentMonthlyTotal(st, currentModel);
      const rating = getRatingDetails(total, effectiveTotalMax);

      return [
        idx + 1,
        `"${st.name}"`,
        `"${st.gradeLevel}"`,
        `"${st.section}"`,
        st.writtenRawScore ?? '',
        ...(isRelative && customSum > 0 ? [writtenCalc ?? ''] : []),
        ...(currentModel.customColumns || []).map((c) => st.scores[c.id] ?? ''),
        total ?? '',
        `"${rating.text}"`,
      ];
    });

    const csvContent =
      '\uFEFF' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `درجات_${currentModel.name}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Prompt user before exporting CSV/Excel
  const requestExportCSV = () => {
    setActionPrompt({
      isOpen: true,
      title: `تنزيل كشف درجات (${currentModel.name})`,
      message: `أنت على وشك تصدير وتنزيل درجات نموذج (${currentModel.name}) بجميع أعمدته المحسوبة ودرجات الطلاب بصيغة ملف Excel (CSV).`,
      confirmText: 'تنزيل الملف الآن',
      confirmColor: 'bg-[#487B5D] hover:bg-[#3C684E]',
      icon: <FileSpreadsheet className="w-5 h-5 text-[#3E7D59]" />,
      onConfirm: () => {
        handleExportCSV();
        setActionPrompt(null);
      },
    });
  };

  // Prompt user before printing
  const requestPrint = () => {
    setActionPrompt({
      isOpen: true,
      title: `طباعة كشف درجات (${currentModel.name})`,
      message: `أنت على وشك فتح نافذة طباعة كشف درجات نموذج (${currentModel.name}) بكافة تفاصيل الطلاب والدرجات.`,
      confirmText: 'بدء الطباعة',
      confirmColor: 'bg-[#557A95] hover:bg-[#476A84]',
      icon: <Printer className="w-5 h-5 text-[#557A95]" />,
      onConfirm: () => {
        setActionPrompt(null);
        setTimeout(() => window.print(), 100);
      },
    });
  };

  return (
    <div className="space-y-3.5">
      {/* 1. Large Craft Camel Brown "+ جدول درجات جديد" Button (Exact like picture) */}
      <div className="no-print">
        <button
          type="button"
          onClick={() => setIsCreateModelOpen(true)}
          className="w-full py-3.5 px-6 craft-btn-primary active:scale-[0.99] rounded-2xl text-base sm:text-lg font-bold transition-all flex items-center justify-center gap-2.5 cursor-pointer"
          title={`جدول درجات جديد لمادة ${profile.subject || 'المادة'}`}
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
          <span>جدول درجات جديد</span>
        </button>
      </div>

      {/* 2. Model Tabs Card with Trash icon on the active tab (Exact like the picture) */}
      <div className="craft-card p-3 sm:p-4 rounded-2xl shadow-xs no-print">
        <div className="flex items-center gap-2.5 overflow-x-auto pb-1 max-w-full">
          {models.map((model) => {
            const isActive = model.id === currentModel.id;
            return (
              <div key={model.id} className="relative inline-flex shrink-0">
                <button
                  type="button"
                  onClick={() => onSelectModel(model.id)}
                  className={`px-5 py-2.5 rounded-xl text-sm sm:text-base font-bold transition-all whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-[#BA916C] text-white border border-[#9E7752] shadow-sm'
                      : 'bg-[#EBDDC8] hover:bg-[#E0CFB8] text-[#3D2E21] border border-[#CBB69F]'
                  }`}
                >
                  {model.name}
                </button>

                {/* Red Trash button sitting on top of the active model button */}
                {isActive && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      requestDeleteModel(model.id);
                    }}
                    className="absolute -top-2.5 -left-2 sm:-left-2.5 w-6 h-6 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center shadow-md transition-transform hover:scale-110 active:scale-95 cursor-pointer z-10"
                    title={`حذف نموذج ${model.name}`}
                    aria-label={`حذف نموذج ${model.name}`}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Main Gradebook Card - Header with Title, "+ إضافة حقل" button, Print/Export */}
      <div className="craft-card rounded-2xl shadow-xs overflow-hidden">
        {/* Table Title Bar */}
        <div className="w-full px-3.5 py-3 sm:px-5 sm:py-3.5 bg-[#F8F4EA] border-b border-[#D8CEBD] flex items-center justify-between gap-3 flex-wrap sm:flex-nowrap no-print">
          {/* Right: Title showing selected month name in sky blue matching image */}
          <div className="flex items-center gap-3 min-w-0">
            <h3 className="text-sm sm:text-base lg:text-lg font-bold text-[#2F2822] truncate flex items-center gap-1.5">
              <span>كشف درجات:</span>
              <span className="text-[#4A82A8] font-black">{currentModel.name}</span>
            </h3>
          </div>

          {/* Left: Opposite to the title - Rename Columns, Print & Download Excel */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Rename Columns button */}
            <button
              type="button"
              onClick={() => setIsRenameColumnsModalOpen(true)}
              className="px-2.5 py-1.5 sm:py-2 text-[#1E293B] hover:text-[#2B6CB0] bg-white hover:bg-slate-100 border border-[#CBD5E1] rounded-xl transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer active:scale-95 shrink-0"
              title="إعادة تسمية عناوين أعمدة الجدول"
              aria-label="إعادة تسمية عناوين أعمدة الجدول"
            >
              <PenLine className="w-4 h-4 text-[#2B6CB0]" />
              <span className="text-xs font-bold hidden sm:inline">تسمية الأعمدة</span>
            </button>

            {/* Toggle Student Info Cloud button */}
            <button
              type="button"
              data-floating-cloud-toggle="true"
              onClick={() => {
                if (activeStudentCloud) {
                  setActiveStudentCloud(null);
                } else if (filteredStudents.length > 0) {
                  const s = filteredStudents[0];
                  const firstRow = document.querySelector('tbody tr') as HTMLTableRowElement | null;
                  const rect = firstRow?.getBoundingClientRect();
                  activeRowRef.current = firstRow;
                  setActiveStudentCloud({
                    studentId: s.id,
                    name: s.name,
                    section: s.section,
                    rowTop: rect ? rect.top + Math.max(0, (rect.height - 32) / 2) : 200,
                  });
                }
              }}
              className={`px-2.5 py-1.5 sm:py-2 rounded-xl transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer active:scale-95 shrink-0 border ${
                activeStudentCloud
                  ? 'bg-sky-50 text-sky-800 border-sky-300'
                  : 'bg-white text-[#1E293B] hover:text-[#2B6CB0] hover:bg-slate-100 border-[#CBD5E1]'
              }`}
              title="إظهار / إخفاء سحابة اسم الطالب التفاعلية لمتابعة الأسماء أثناء التمرير الأفقي"
              aria-label="سحابة اسم الطالب"
            >
              <User className="w-4 h-4 text-sky-600" />
              <span className="text-xs font-bold hidden md:inline">
                {activeStudentCloud ? 'إخفاء سحابة الطالب' : 'سحابة اسم الطالب'}
              </span>
            </button>

            {/* Print icon only */}
            <button
              type="button"
              onClick={requestPrint}
              className="p-2 sm:p-2.5 text-[#334155] hover:text-[#2B6CB0] bg-white hover:bg-slate-100 border border-[#CBD5E1] rounded-xl transition-all shadow-2xs flex items-center justify-center cursor-pointer active:scale-95 shrink-0"
              title={`طباعة كشف درجات ${currentModel.name}`}
              aria-label={`طباعة كشف درجات ${currentModel.name}`}
            >
              <Printer className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-[#2B6CB0]" />
            </button>

            {/* Download Document icon only */}
            <button
              type="button"
              onClick={requestExportCSV}
              className="p-2 sm:p-2.5 text-[#15803D] hover:text-[#166534] bg-[#F0FDF4] hover:bg-[#DCFCE7] border border-emerald-300 rounded-xl transition-all shadow-2xs flex items-center justify-center cursor-pointer active:scale-95 shrink-0"
              title={`تنزيل مستند درجات ${currentModel.name} بصيغة Excel`}
              aria-label={`تنزيل مستند درجات ${currentModel.name} بصيغة Excel`}
            >
              <FileSpreadsheet className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-[#15803D]" />
            </button>
          </div>
        </div>

        {/* Excel-style Table Grid with Paper & Craft Theme */}
        <div ref={tableContainerRef} onScroll={checkNameColumnVisibility} className="overflow-x-auto">
          <table className="w-full text-right border-collapse border border-[#D5C8B2] bg-[#FAF7EC]">
            <thead>
              <tr className="bg-[#EFE8D8] text-[#2F2822] text-xs font-bold">
                {/* Delete Student Row Action at Start of Table */}
                <th
                  className="py-2.5 px-2 w-10 text-center align-middle text-[#9C3838] font-bold bg-[#EFE8D8] border border-[#D5C8B2] no-print print:hidden"
                  title="حذف صف الطالب من الجدول"
                >
                  <div className="craft-table-header px-1 py-0.5 rounded-lg text-center font-bold text-[11px]">حذف</div>
                </th>

                {/* Index */}
                <th className="py-2.5 px-2 w-9 text-center align-middle text-[#2F2822] font-bold bg-[#EFE8D8] border border-[#D5C8B2]">
                  <div className="flex items-center justify-center gap-0.5">
                    <span className={`craft-table-header px-1 py-0.5 rounded-lg text-center font-bold text-[11px] ${getSlantClasses(columnSlants['index'])}`}>#</span>
                    <SlantButton slant={columnSlants['index']} onToggle={() => toggleColumnSlant('index')} />
                  </div>
                </th>

                {/* Student Name header */}
                <th data-student-name-column="true" className={`py-2 px-3 min-w-[200px] align-top bg-[#EFE8D8] border border-[#D5C8B2] ${columnSlants['studentName'] === 'vertical' ? 'min-w-[70px]' : ''}`}>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      {editingColumnKey === 'studentName' ? (
                        <div className="flex items-center gap-1 w-full">
                          <input
                            type="text"
                            autoFocus
                            value={inlineEditValue}
                            onChange={(e) => setInlineEditValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveInlineColumnRename('studentName');
                              if (e.key === 'Escape') setEditingColumnKey(null);
                            }}
                            className="w-full px-1.5 py-0.5 text-xs font-bold bg-white border border-[#BA916C] rounded focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveInlineColumnRename('studentName')}
                            className="p-1 text-emerald-700 hover:bg-emerald-100 rounded cursor-pointer"
                            title="حفظ"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingColumnKey(null)}
                            className="p-1 text-slate-500 hover:bg-slate-200 rounded cursor-pointer"
                            title="إلغاء"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 group/header">
                          <span className={`craft-table-header px-2.5 py-0.5 rounded-lg font-bold text-[#2F2822] inline-block ${getSlantClasses(columnSlants['studentName'])}`}>{studentNameLabel}</span>
                          <button
                            type="button"
                            onClick={() => handleStartInlineEdit('studentName', studentNameLabel)}
                            className="opacity-40 hover:opacity-100 p-0.5 text-[#6B5E51] hover:text-[#BA916C] rounded transition-opacity cursor-pointer shrink-0 print:hidden"
                            title="إعادة تسمية عمود اسم الطالب"
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                          <SlantButton slant={columnSlants['studentName']} onToggle={() => toggleColumnSlant('studentName')} />
                        </div>
                      )}
                    </div>
                    {/* Embedded Search Input */}
                    <div className="relative print:hidden">
                      <Search className="w-3.5 h-3.5 text-[#64748B] absolute right-2.5 top-2 pointer-events-none" />
                      <input
                        type="text"
                        placeholder="بحث بالاسم..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pr-8 pl-2 py-1 bg-white border border-[#CBD5E1] rounded-lg text-xs font-normal focus:border-[#2B6CB0] focus:ring-1 focus:ring-[#2B6CB0] focus:outline-none placeholder:text-[#94A3B8]"
                      />
                    </div>
                  </div>
                </th>

                {/* Grade Level Column Header with inline dynamic title & small triangle */}
                <th className={`py-1.5 px-1 w-auto min-w-[50px] max-w-[85px] print:w-auto print:min-w-0 print:px-0 text-center align-middle bg-[#EFE8D8] border border-[#D5C8B2] ${columnSlants['gradeLevel'] === 'vertical' ? 'min-w-[40px]' : ''}`}>
                  <div className="flex flex-col items-center justify-center gap-1">
                    {/* Screen edit & filter */}
                    <div className="print:hidden flex items-center justify-center w-full">
                      {editingColumnKey === 'gradeLevel' ? (
                        <div className="flex items-center justify-center gap-1">
                          <input
                            type="text"
                            autoFocus
                            value={inlineEditValue}
                            onChange={(e) => setInlineEditValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveInlineColumnRename('gradeLevel');
                              if (e.key === 'Escape') setEditingColumnKey(null);
                            }}
                            className="w-16 px-1 py-0.5 text-xs font-bold bg-white border border-[#BA916C] rounded text-center focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveInlineColumnRename('gradeLevel')}
                            className="p-0.5 text-emerald-700 hover:bg-emerald-100 rounded cursor-pointer"
                            title="حفظ"
                          >
                            <Check className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingColumnKey(null)}
                            className="p-0.5 text-slate-500 hover:bg-slate-200 rounded cursor-pointer"
                            title="إلغاء"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center gap-1 group/header w-full">
                          {/* Top row: Pencil and Slant icons stacked vertically above the dropdown */}
                          <div className="flex items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleStartInlineEdit('gradeLevel', gradeLevelLabel)}
                              className="p-1 text-[#6B5E51] hover:text-[#BA916C] hover:bg-white/70 border border-slate-300/80 rounded transition-all cursor-pointer shadow-2xs"
                              title="إعادة تسمية عمود الصف"
                            >
                              <Pencil className="w-2.5 h-2.5" />
                            </button>
                            <SlantButton slant={columnSlants['gradeLevel']} onToggle={() => toggleColumnSlant('gradeLevel')} className="p-1" />
                          </div>

                          {/* Relative container with dynamic title + small triangle + invisible native select */}
                          <div className="relative inline-flex items-center justify-center gap-1 px-1.5 py-0.5 rounded-lg bg-white/70 hover:bg-white border border-[#D5C8B2] hover:border-[#BA916C] shadow-2xs transition-all cursor-pointer group/grade w-full">
                            <span className={`font-bold text-xs text-[#2F2822] whitespace-nowrap truncate ${getSlantClasses(columnSlants['gradeLevel'])}`}>
                              {selectedGradeLevel === 'ALL' ? gradeLevelLabel : selectedGradeLevel}
                            </span>
                            <ChevronDown className="w-3 h-3 text-[#6B5E51] shrink-0 transition-transform group-hover/grade:translate-y-0.5" />
                            <select
                              value={selectedGradeLevel}
                              onChange={(e) => setSelectedGradeLevel(e.target.value)}
                              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                              title="انقر لاختيار الصف أو تصفية الكل"
                            >
                              <option value="ALL">الكل ({gradeLevelLabel})</option>
                              {allGradeLevels.map((grd) => (
                                <option key={grd} value={grd}>
                                  {grd}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Print Only Header: displays selected grade (e.g. الأول متوسط) or الصف الدراسي without dropdown/arrow */}
                    <div className="hidden print:block text-center py-1">
                      <span className={`font-bold text-xs text-[#2F2822] ${getSlantClasses(columnSlants['gradeLevel'])}`}>
                        {selectedGradeLevel === 'ALL'
                          ? (gradeLevelLabel === 'الصف' ? 'الصف الدراسي' : gradeLevelLabel)
                          : selectedGradeLevel}
                      </span>
                    </div>
                  </div>
                </th>

                {/* Section Column - Narrow width, vertical "الشعبة" with letter underneath & small triangle, or vertical "كل الشعب" */}
                <th className="py-1 px-0.5 w-auto min-w-[32px] max-w-[42px] print:w-auto print:min-w-0 print:px-0 text-center align-middle bg-[#EFE8D8] border border-[#D5C8B2]">
                  <div className="flex flex-col items-center justify-center">
                    {/* Screen edit & filter */}
                    <div className="print:hidden flex flex-col items-center w-full">
                      {editingColumnKey === 'section' ? (
                        <div className="flex items-center justify-center gap-0.5">
                          <input
                            type="text"
                            autoFocus
                            value={inlineEditValue}
                            onChange={(e) => setInlineEditValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveInlineColumnRename('section');
                              if (e.key === 'Escape') setEditingColumnKey(null);
                            }}
                            className="w-10 px-0.5 py-0.5 text-xs font-bold bg-white border border-[#BA916C] rounded text-center focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveInlineColumnRename('section')}
                            className="p-0.5 text-emerald-700 hover:bg-emerald-100 rounded cursor-pointer"
                            title="حفظ"
                          >
                            <Check className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="relative flex flex-col items-center justify-center p-1 rounded hover:bg-white/60 transition-colors cursor-pointer group/sec w-full">
                          {selectedSection === 'ALL' ? (
                            /* All Sections: "كل الشعب" displayed vertically */
                            <div className="flex flex-col items-center">
                              <span className="[writing-mode:vertical-rl] rotate-180 font-bold text-xs text-[#2F2822] tracking-wider py-1 select-none leading-tight">
                                كل الشعب
                              </span>
                              <ChevronDown className="w-3 h-3 text-[#6B5E51] mt-0.5 shrink-0 transition-transform group-hover/sec:translate-y-0.5" />
                            </div>
                          ) : (
                            /* Specific Section: "الشعبة" vertically + section letter horizontally underneath */
                            <div className="flex flex-col items-center">
                              <span className="[writing-mode:vertical-rl] rotate-180 font-bold text-xs text-[#2F2822] tracking-wider select-none leading-tight">
                                {sectionLabel}
                              </span>
                              <span className="font-extrabold text-xs text-[#2F2822] mt-0.5 leading-none bg-[#E5D7BE] px-1 py-0.5 rounded shadow-2xs">
                                {selectedSection}
                              </span>
                              <ChevronDown className="w-2.5 h-2.5 text-[#6B5E51] mt-0.5 shrink-0 transition-transform group-hover/sec:translate-y-0.5" />
                            </div>
                          )}

                          {/* Invisible native select overlay for instant selection */}
                          <select
                            value={selectedSection}
                            onChange={(e) => setSelectedSection(e.target.value)}
                            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                            title="انقر لاختيار وتصفية الشعبة"
                          >
                            <option value="ALL">كل الشعب</option>
                            {allSections.map((sec) => (
                              <option key={sec} value={sec}>
                                شعبة {sec}
                              </option>
                            ))}
                          </select>
                        </div>
                      )}
                    </div>

                    {/* Print Only Header: Vertical "كل الشعب" or Vertical "الشعبة" with normal horizontal letter underneath */}
                    <div className="hidden print:flex flex-col items-center justify-center text-center py-0.5 leading-tight">
                      {selectedSection === 'ALL' ? (
                        <span className="[writing-mode:vertical-rl] rotate-180 font-bold text-xs text-[#2F2822] tracking-wider py-1 select-none">
                          كل الشعب
                        </span>
                      ) : (
                        <div className="flex flex-col items-center justify-center">
                          <span className="[writing-mode:vertical-rl] rotate-180 font-bold text-xs text-[#2F2822] tracking-wider select-none">
                            {sectionLabel}
                          </span>
                          <span className="font-bold text-xs text-[#2F2822] mt-0.5 leading-none">
                            {selectedSection}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </th>

                {/* Written Exam Header with editable "درجة التحريري بالورقة من [ input ]" and radio mode selector */}
                <th className={`py-2.5 px-3 min-w-[210px] print:min-w-0 bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] text-center align-top ${columnSlants['writtenExam'] === 'vertical' ? 'min-w-[60px]' : ''}`}>
                  <div className="space-y-1.5 print:hidden">
                    {/* Header Top Row: "درجة التحريري بالورقة من" + editable input */}
                    <div className="flex items-center justify-center gap-1.5">
                      {editingColumnKey === 'writtenExam' ? (
                        <div className="flex items-center justify-center gap-1">
                          <input
                            type="text"
                            autoFocus
                            value={inlineEditValue}
                            onChange={(e) => setInlineEditValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveInlineColumnRename('writtenExam');
                              if (e.key === 'Escape') setEditingColumnKey(null);
                            }}
                            className="w-36 px-1.5 py-0.5 text-xs font-bold bg-white border border-[#2B6CB0] rounded text-center focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveInlineColumnRename('writtenExam')}
                            className="p-1 text-emerald-700 hover:bg-emerald-100 rounded cursor-pointer"
                            title="حفظ"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingColumnKey(null)}
                            className="p-1 text-slate-500 hover:bg-slate-200 rounded cursor-pointer"
                            title="إلغاء"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center gap-1 group/header">
                          <span className={`font-bold text-xs text-[#1E293B] whitespace-nowrap ${getSlantClasses(columnSlants['writtenExam'])}`}>
                            {writtenExamLabel}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleStartInlineEdit('writtenExam', writtenExamLabel)}
                            className="opacity-40 hover:opacity-100 p-0.5 text-slate-500 hover:text-[#2B6CB0] rounded transition-opacity cursor-pointer shrink-0"
                            title="إعادة تسمية عنوان عمود التحريري"
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                          <SlantButton slant={columnSlants['writtenExam']} onToggle={() => toggleColumnSlant('writtenExam')} />
                        </div>
                      )}
                      <input
                        type="number"
                        min="1"
                        max="1000"
                        value={currentModel.writtenMaxScore || ''}
                        onChange={(e) => {
                          const val = e.target.value === '' ? 0 : Number(e.target.value);
                          if (onUpdateAllModels && models.length > 0) {
                            const updatedModels = models.map((m) => ({
                              ...m,
                              writtenMaxScore: val,
                              writtenScoreMode: m.writtenScoreMode || 'raw',
                              updatedAt: new Date().toISOString(),
                            }));
                            onUpdateAllModels(updatedModels);
                          } else {
                            onUpdateModel({
                              ...currentModel,
                              writtenMaxScore: val,
                              writtenScoreMode: currentModel.writtenScoreMode || 'raw',
                              updatedAt: new Date().toISOString(),
                            });
                          }
                        }}
                        className="w-12 px-1 py-0.5 bg-white text-[#1E293B] font-black text-xs rounded-lg border border-[#CBD5E1] shadow-2xs text-center focus:border-[#2B6CB0] focus:ring-1 focus:ring-[#2B6CB0] focus:outline-none"
                        title="تعديل درجة الامتحان التحريري من"
                      />
                    </div>

                    {/* Mode selector option as Radio buttons - STRICTLY HIDDEN ON PRINT */}
                    <div className="pt-1.5 border-t border-[#CBD5E1] text-right space-y-1.5 bg-white/90 p-2 rounded-xl border border-[#CBD5E1]/60 shadow-2xs">
                      <label className={`flex items-center gap-1.5 p-1 rounded-lg cursor-pointer select-none text-[11px] font-bold transition-all ${writtenScoreMode === 'raw' ? 'bg-blue-50 text-[#1E40AF]' : 'text-slate-700 hover:text-[#2B6CB0]'}`}>
                        <input
                          type="radio"
                          name={`writtenScoreMode-${currentModel.id}`}
                          value="raw"
                          checked={writtenScoreMode === 'raw'}
                          onChange={() => handleUpdateScoreMode('raw')}
                          className="text-[#2B6CB0] focus:ring-[#2B6CB0] w-3.5 h-3.5 cursor-pointer accent-[#2B6CB0]"
                        />
                        <span className="leading-tight">الدرجة كما في ورقة الطالب</span>
                      </label>

                      <label className={`flex items-center gap-1.5 p-1 rounded-lg cursor-pointer select-none text-[11px] font-bold transition-all ${writtenScoreMode === 'relative' ? 'bg-blue-50 text-[#1E40AF]' : 'text-slate-700 hover:text-[#2B6CB0]'}`}>
                        <input
                          type="radio"
                          name={`writtenScoreMode-${currentModel.id}`}
                          value="relative"
                          checked={writtenScoreMode === 'relative'}
                          onChange={() => handleUpdateScoreMode('relative')}
                          className="text-[#2B6CB0] focus:ring-[#2B6CB0] w-3.5 h-3.5 cursor-pointer accent-[#2B6CB0]"
                        />
                        <span className="leading-tight">الدرجة النسبية للطالب</span>
                      </label>
                    </div>

                    {/* Header Bottom Row: Info based on selected mode */}
                    <div>
                      {writtenScoreMode === 'relative' ? (
                        customSum > 0 && effectiveWrittenWeight !== currentModel.writtenMaxScore ? (
                          <div className="text-[10px] text-[#2B6CB0] font-semibold leading-tight">
                            (يُحتسب كنسبة من {effectiveWrittenWeight} درجة)
                          </div>
                        ) : (
                          <div className="text-[10px] text-[#2B6CB0] font-semibold leading-tight">
                            (الدرجة النسبية مفعلة)
                          </div>
                        )
                      ) : (
                        <div className="text-[10px] text-emerald-700 font-bold leading-tight">
                          (مفعل تلقائي - كما في الورقة بدون نسبة)
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Print Only Header: Strictly ONLY "التحريري" */}
                  <div className="hidden print:block text-center py-1">
                    <span className={`font-bold text-xs text-[#1E293B] ${getSlantClasses(columnSlants['writtenExam'])}`}>
                      التحريري
                    </span>
                  </div>
                </th>

                {/* Optional Custom Columns */}
                {(currentModel.customColumns || []).map((col) => (
                  <th
                    key={col.id}
                    className={`py-2 px-3 min-w-[130px] print:min-w-0 bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] align-top ${columnSlants[col.id] === 'vertical' ? 'min-w-[50px]' : ''}`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      {editingColumnKey === col.id ? (
                        <div className="flex items-center gap-1 w-full print:hidden">
                          <input
                            type="text"
                            autoFocus
                            value={inlineEditValue}
                            onChange={(e) => setInlineEditValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveInlineCustomColRename(col.id);
                              if (e.key === 'Escape') setEditingColumnKey(null);
                            }}
                            className="w-full px-1.5 py-0.5 text-xs font-bold bg-white border border-[#2B6CB0] rounded focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveInlineCustomColRename(col.id)}
                            className="p-1 text-emerald-700 hover:bg-emerald-100 rounded shrink-0 cursor-pointer"
                            title="حفظ"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingColumnKey(null)}
                            className="p-1 text-slate-500 hover:bg-slate-200 rounded shrink-0 cursor-pointer"
                            title="إلغاء"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-1 min-w-0 group/header">
                            <span className={`font-bold truncate text-[#1E293B] ${getSlantClasses(columnSlants[col.id])}`}>{col.name}</span>
                            <button
                              type="button"
                              onClick={() => handleStartInlineEdit(col.id, col.name)}
                              className="opacity-40 hover:opacity-100 p-0.5 text-slate-500 hover:text-[#2B6CB0] rounded transition-opacity shrink-0 cursor-pointer print:hidden"
                              title={`إعادة تسمية عمود (${col.name})`}
                            >
                              <Pencil className="w-3 h-3" />
                            </button>
                            <SlantButton slant={columnSlants[col.id]} onToggle={() => toggleColumnSlant(col.id)} />
                          </div>
                          <button
                            type="button"
                            onClick={() => requestDeleteColumn(col.id)}
                            className="p-1 text-[#BD4B4B] hover:text-white hover:bg-[#BD4B4B] bg-[#FBEBEB] rounded-lg transition-colors shrink-0 cursor-pointer print:hidden"
                            title={`حذف عمود (${col.name})`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                    <div className="text-[10px] text-[#64748B] font-semibold mt-1">
                      (الدرجة: {col.maxScore})
                    </div>
                  </th>
                ))}

                {/* Divider '+' Button between Written / Custom Columns and Final Score */}
                <th className="py-2 px-2 min-w-[95px] max-w-[110px] bg-[#F8FAFC] border border-[#CBD5E1] text-center align-middle no-print print:hidden select-none">
                  <div className="flex flex-col items-center justify-center gap-1.5 py-1">
                    <span className="text-[10px] font-bold text-[#2B6CB0] leading-snug text-center">
                      إذا أردت إضافة حقل اضغط هنا
                    </span>
                    <button
                      type="button"
                      onClick={handleOpenAddColumn}
                      className="w-7 h-7 rounded-full bg-[#2B6CB0] hover:bg-[#1E4E8C] active:scale-95 text-white flex items-center justify-center shadow-xs transition-all cursor-pointer ring-2 ring-blue-200 hover:ring-blue-400 hover:scale-105"
                      title="إذا أردت إضافة حقل اضغط هنا"
                      aria-label="إذا أردت إضافة حقل اضغط هنا"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                    </button>
                  </div>
                </th>

                {/* Final Score Header - In print strictly ONLY "النهائي" */}
                <th className={`py-2.5 px-3 min-w-[170px] print:min-w-0 bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] text-center align-top ${columnSlants['finalScore'] === 'vertical' ? 'min-w-[50px]' : ''}`}>
                  <div className="space-y-1.5 print:hidden">
                    {/* Header Top Row: Title + Slant Toggle + Edit Pencil + Operation Badge + Max Score Input */}
                    <div className="flex items-center justify-center gap-1.5">
                      {editingColumnKey === 'finalScore' ? (
                        <div className="flex items-center justify-center gap-1">
                          <input
                            type="text"
                            autoFocus
                            value={inlineEditValue}
                            onChange={(e) => setInlineEditValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveInlineColumnRename('finalScore');
                              if (e.key === 'Escape') setEditingColumnKey(null);
                            }}
                            className="w-28 px-1.5 py-0.5 text-xs font-bold bg-white border border-[#2B6CB0] rounded text-center focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveInlineColumnRename('finalScore')}
                            className="p-1 text-emerald-700 hover:bg-emerald-100 rounded cursor-pointer"
                            title="حفظ"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingColumnKey(null)}
                            className="p-1 text-slate-500 hover:bg-slate-200 rounded cursor-pointer"
                            title="إلغاء"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center gap-1 group/header">
                          <span className={`font-bold text-xs text-[#1E293B] whitespace-nowrap ${getSlantClasses(columnSlants['finalScore'])}`}>
                            {finalScoreLabel}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleStartInlineEdit('finalScore', finalScoreLabel)}
                            className="opacity-40 hover:opacity-100 p-0.5 text-slate-500 hover:text-[#2B6CB0] rounded transition-opacity cursor-pointer shrink-0"
                            title="إعادة تسمية عمود الدرجة النهائية"
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                          <SlantButton slant={columnSlants['finalScore']} onToggle={() => toggleColumnSlant('finalScore')} />
                        </div>
                      )}

                      {/* Prominent pill badge if an active math operation is applied (e.g. ÷ 2) */}
                      {hasFinalOp && (
                        <button
                          type="button"
                          onClick={() => setIsFinalOperationModalOpen(true)}
                          className="px-1.5 py-0.5 rounded-md text-[10px] font-black bg-blue-600 text-white hover:bg-blue-700 shadow-2xs transition-all cursor-pointer flex items-center gap-0.5 active:scale-95 shrink-0"
                          title={`الدرجة النهائية مقسومة/معدلة: (${finalOpLabel}) - انقر للتعديل أو الإلغاء`}
                        >
                          <Calculator className="w-3 h-3" />
                          <span>{finalOpLabel}</span>
                        </button>
                      )}

                      <div className="relative inline-flex items-center">
                        <input
                          type="number"
                          min="1"
                          max="1000"
                          placeholder="100"
                          value={!currentModel.totalMaxScore || currentModel.totalMaxScore === 0 ? '' : currentModel.totalMaxScore}
                          onChange={(e) => {
                            const raw = e.target.value;
                            const newMax = raw === '' ? 0 : Number(raw);
                            handleUpdateTotalMaxScore(newMax);
                          }}
                          className="w-14 px-1 py-0.5 bg-white text-[#1E293B] font-black text-xs rounded-lg border border-[#CBD5E1] shadow-2xs text-center focus:border-[#2B6CB0] focus:ring-1 focus:ring-[#2B6CB0] focus:outline-none transition-colors"
                          title="تعديل الدرجة النهائية الكاملة"
                        />
                      </div>
                    </div>

                    {/* Header Bottom Row: Completion status + Math Op Button + Rounding + Rating toggle: STRICTLY HIDDEN ON PRINT */}
                    <div className="flex items-center justify-between gap-1 pt-1 border-t border-[#CBD5E1] text-[10px]">
                      <div className="font-bold text-right">
                        {remainingScore === 0 ? (
                          <span className="text-[#15803D] font-black">
                            ({allocatedTotal}/{totalMax}) {hasFinalOp ? `➔ ${effectiveTotalMax}` : 'مكتمل ✓'}
                          </span>
                        ) : remainingScore > 0 ? (
                          <span className="text-[#2B6CB0] font-bold">
                            ({allocatedTotal}/{totalMax}) متبقي {remainingScore}
                          </span>
                        ) : (
                          <span className="text-[#BD4B4B] font-bold">
                            ({allocatedTotal}/{totalMax}) زائد {Math.abs(remainingScore)}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        {/* Math Operation Button (divide by number, multiply, add, subtract, none) */}
                        <button
                          type="button"
                          onClick={() => setIsFinalOperationModalOpen(true)}
                          className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold transition-all border flex items-center gap-1 shadow-2xs active:scale-95 cursor-pointer ${
                            hasFinalOp
                              ? 'bg-blue-50 text-blue-800 border-blue-300 hover:bg-blue-100 font-black'
                              : 'bg-white text-[#2B6CB0] border-[#CBD5E1] hover:bg-slate-50'
                          }`}
                          title={
                            hasFinalOp
                              ? `الدرجة مطبق عليها (${finalOpLabel}) والمحصلة من ${effectiveTotalMax}. انقر لتعديل أو إلغاء العملية.`
                              : 'خيارات الدرجة النهائية: قسمة على عدد (مثلاً قسمة على 2)، ضرب، جمع، أو طرح'
                          }
                        >
                          <Calculator className={`w-3.5 h-3.5 ${hasFinalOp ? 'text-blue-700' : 'text-[#2B6CB0]'}`} />
                          <span>{hasFinalOp ? `عملية: ${finalOpLabel}` : '÷ × + - عملية'}</span>
                        </button>

                        {/* Rounding button inside header - only appears when decimals exist */}
                        {hasDecimalScores && (
                          <button
                            type="button"
                            onClick={() => setIsRoundingModalOpen(true)}
                            className="px-1.5 py-0.5 rounded-md text-[10px] font-bold transition-all border flex items-center gap-1 shadow-2xs bg-white text-[#854D0E] border-[#CBD5E1] hover:bg-slate-50 cursor-pointer"
                            title="التحكم بالنسب وقواعد جبر الكسور العشرية"
                          >
                            <Calculator className="w-3.5 h-3.5 text-[#854D0E]" />
                            <span>
                              {currentModel.roundingMode === 'half_up'
                                ? 'جبر: ≥0.5'
                                : currentModel.roundingMode === 'any_fraction'
                                ? 'جبر: ≥0.1'
                                : currentModel.roundingMode === 'custom_threshold'
                                ? `جبر: ≥${currentModel.roundingThreshold}`
                                : 'التحكم بالنسب العشرية'}
                            </span>
                          </button>
                        )}

                        {/* Toggle Rating button inside header */}
                        <button
                          type="button"
                          onClick={toggleRatingColumn}
                          className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold transition-all border flex items-center gap-1 shadow-2xs active:scale-95 cursor-pointer ${
                            showRatingColumn
                              ? 'bg-[#EBF4EE] text-[#15803D] border-emerald-300'
                              : 'bg-white text-[#64748B] border-[#CBD5E1] hover:bg-slate-100'
                          }`}
                          title={showRatingColumn ? 'عمود التقدير ظاهر (انقر للإخفاء)' : 'عمود التقدير مخفي (انقر للإظهار)'}
                        >
                          {showRatingColumn ? (
                            <Eye className="w-3.5 h-3.5 text-[#15803D]" />
                          ) : (
                            <EyeOff className="w-3.5 h-3.5 text-[#64748B]" />
                          )}
                          <span>التقدير: {showRatingColumn ? 'ظاهر' : 'مخفي'}</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Print Only Title */}
                  <div className="hidden print:block text-center py-1">
                    <span className={`font-bold text-xs text-[#1E293B] ${getSlantClasses(columnSlants['finalScore'])}`}>
                      {hasFinalOp ? `النهائي (${finalOpLabel})` : 'النهائي'}
                    </span>
                  </div>
                </th>

                {/* Rating Badge Header */}
                {showRatingColumn && (
                  <th className={`py-2.5 px-2 min-w-[85px] print:min-w-0 bg-[#F1F5F9] border border-[#CBD5E1] text-[#1E293B] text-center align-middle animate-in fade-in ${columnSlants['rating'] === 'vertical' ? 'min-w-[45px]' : ''}`}>
                    <div className="flex items-center justify-center gap-1">
                      {editingColumnKey === 'rating' ? (
                        <div className="flex items-center justify-center gap-1 print:hidden">
                          <input
                            type="text"
                            autoFocus
                            value={inlineEditValue}
                            onChange={(e) => setInlineEditValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveInlineColumnRename('rating');
                              if (e.key === 'Escape') setEditingColumnKey(null);
                            }}
                            className="w-20 px-1.5 py-0.5 text-xs font-bold bg-white border border-[#2B6CB0] rounded text-center focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveInlineColumnRename('rating')}
                            className="p-1 text-emerald-700 hover:bg-emerald-100 rounded cursor-pointer"
                            title="حفظ"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingColumnKey(null)}
                            className="p-1 text-slate-500 hover:bg-slate-200 rounded cursor-pointer"
                            title="إلغاء"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center gap-1 group/header">
                          <span className={`font-bold text-xs text-[#1E293B] ${getSlantClasses(columnSlants['rating'])}`}>{ratingLabel}</span>
                          <button
                            type="button"
                            onClick={() => handleStartInlineEdit('rating', ratingLabel)}
                            className="opacity-40 hover:opacity-100 p-0.5 text-slate-500 hover:text-[#2B6CB0] rounded transition-opacity cursor-pointer shrink-0 print:hidden"
                            title="إعادة تسمية عمود التقدير"
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                          <SlantButton slant={columnSlants['rating']} onToggle={() => toggleColumnSlant('rating')} />
                        </div>
                      )}
                      <button
                        type="button"
                        onClick={toggleRatingColumn}
                        className="p-0.5 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-200 transition-colors cursor-pointer print:hidden"
                        title="إخفاء عمود التقدير"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  </th>
                )}
              </tr>
            </thead>

            {filteredStudents.length > 0 && (
              <tbody className="text-sm">
                {filteredStudents.map((student, index) => {
                  const writtenCalculated = calculateWrittenScore(
                    student.writtenRawScore,
                    currentModel.writtenMaxScore,
                    effectiveWrittenWeight,
                    currentModel.totalMaxScore,
                    writtenScoreMode
                  );
                  const hasWrittenDecimal =
                    writtenCalculated !== null && Math.round(writtenCalculated) !== writtenCalculated;
                  const roundingMode = currentModel.roundingMode || 'any_fraction';
                  const roundedWrittenScore =
                    writtenCalculated !== null
                      ? currentModel.roundingMode === 'none'
                        ? writtenCalculated
                        : applyScoreRounding(
                            writtenCalculated,
                            roundingMode,
                            currentModel.roundingThreshold,
                            currentModel.totalMaxScore
                          )
                      : null;
                  const breakdown = getStudentMonthlyScoreBreakdown(student, currentModel);
                  const totalMonthly = breakdown.finalScore;
                  const rating = getRatingDetails(totalMonthly, effectiveTotalMax);

                  // Detect if student name resembles another student in this model or other models (e.g. أ/ا or typo)
                  const suspectedInTable = (() => {
                    const cleaned = cleanSingleSpaces(student.name);
                    if (!cleaned || cleaned.length < 3) return null;
                    const others = [
                      ...currentModel.students.filter((s) => s.id !== student.id),
                      ...otherModelsStudents.filter((os) => os.id !== student.id),
                    ];
                    return findSuspectedStudentMatch(cleaned, others, { ignoreExact: true });
                  })();

                  return (
                    <tr
                      key={student.id}
                      className="even:bg-[#F8FAFC] odd:bg-white hover:bg-blue-50/40 transition-colors group"
                    >
                      {/* Delete Student Row Button AT THE VERY BEGINNING OF THE ROW */}
                      <td className="py-1 px-1 text-center align-middle border border-[#CBD5E1] no-print print:hidden">
                        <button
                          type="button"
                          onClick={() => requestDeleteRow(student.id)}
                          className="w-7 h-7 inline-flex items-center justify-center rounded-lg text-[#BD4B4B] hover:text-white bg-[#FDF2F2] hover:bg-[#BD4B4B] border border-[#F5D5D5] hover:border-[#BD4B4B] transition-all shadow-2xs hover:scale-105 active:scale-95"
                          title={`حذف صف الطالب (${student.name || 'بدون اسم'}) مع تنبيه تأكيد`}
                        >
                          <Trash2 className="w-3.5 h-3.5 transition-colors" />
                        </button>
                      </td>

                      {/* Row Index */}
                      <td className="py-1.5 px-2 text-center text-xs font-bold text-[#64748B] border border-[#CBD5E1] bg-[#F8FAFC]">
                        {index + 1}
                      </td>

                      {/* Student Name */}
                      <td
                        data-student-name-column="true"
                        className={`py-1 px-2 border transition-colors ${
                          suspectedInTable
                            ? 'bg-amber-100/90 border-amber-400'
                            : 'border-[#CBD5E1]'
                        }`}
                      >
                        <div className="space-y-1">
                          <input
                            type="text"
                            value={student.name}
                            onFocus={(e) => handleScoreCellFocus(e, student)}
                            onClick={(e) => handleScoreCellFocus(e, student)}
                            onBlur={(e) => {
                              const cleaned = cleanSingleSpaces(e.target.value);
                              if (cleaned !== student.name) {
                                handleUpdateStudent(student.id, { name: cleaned });
                              }
                            }}
                            onChange={(e) =>
                              handleUpdateStudent(student.id, { name: e.target.value })
                            }
                            placeholder="اكتب اسم الطالب..."
                            className={`w-full px-2 py-1 border border-transparent hover:border-[#CBD5E1] focus:border-[#2B6CB0] focus:bg-white text-sm font-bold text-[#1E293B] focus:outline-none transition-colors rounded-none sm:rounded-sm ${
                              suspectedInTable ? 'bg-amber-50/80 font-black' : ''
                            }`}
                          />

                          {suspectedInTable && (
                            <div className="flex flex-wrap items-center justify-between gap-1 p-1 bg-amber-200/90 border border-amber-300 rounded text-[10px] text-amber-950 font-bold no-print print:hidden shadow-2xs">
                              <span className="flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3 text-amber-700 shrink-0" />
                                <span>هل تقصد «{suspectedInTable.matchedName}» كما في الجدول السابق؟</span>
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  handleUpdateStudent(student.id, {
                                    name: suspectedInTable.matchedName,
                                  })
                                }
                                className="px-1.5 py-0.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-[9px] font-bold cursor-pointer transition-colors shadow-2xs"
                              >
                                نعم اعتمد
                              </button>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Grade Level */}
                      <td className="py-1 px-2 border border-[#CBD5E1]">
                        <input
                          type="text"
                          value={student.gradeLevel}
                          onFocus={(e) => handleScoreCellFocus(e, student)}
                          onClick={(e) => handleScoreCellFocus(e, student)}
                          onChange={(e) =>
                            handleUpdateStudent(student.id, { gradeLevel: e.target.value })
                          }
                          placeholder="الصف"
                          className="w-full px-1.5 py-1 border border-transparent hover:border-[#CBD5E1] focus:border-[#2B6CB0] focus:bg-white text-xs font-medium text-[#475569] focus:outline-none transition-colors text-center rounded-none sm:rounded-sm"
                        />
                      </td>

                      {/* Section */}
                      <td className="py-1 px-0.5 text-center border border-[#CBD5E1] w-auto min-w-[34px] max-w-[48px] print:w-auto print:px-0">
                        <input
                          type="text"
                          value={student.section}
                          onFocus={(e) => handleScoreCellFocus(e, student)}
                          onClick={(e) => handleScoreCellFocus(e, student)}
                          onChange={(e) =>
                            handleUpdateStudent(student.id, { section: e.target.value })
                          }
                          placeholder="أ"
                          className="w-full text-center px-0.5 py-1 border border-transparent hover:border-[#CBD5E1] focus:border-[#2B6CB0] focus:bg-white text-xs font-bold text-[#1E293B] focus:outline-none transition-colors rounded-none sm:rounded-sm"
                        />
                      </td>

                      {/* Written Exam Input + Converted Score Display */}
                      <td className="py-1 px-2.5 text-center border border-[#CBD5E1]">
                        <div className="flex flex-col items-center justify-center gap-1">
                          <input
                            type="number"
                            min="0"
                            max={currentModel.writtenMaxScore}
                            step="any"
                            value={
                              student.writtenRawScore === null ? '' : student.writtenRawScore
                            }
                            onFocus={(e) => handleScoreCellFocus(e, student)}
                            onClick={(e) => handleScoreCellFocus(e, student)}
                            onChange={(e) =>
                              handleUpdateStudent(student.id, {
                                writtenRawScore:
                                  e.target.value === '' ? null : Number(e.target.value),
                              })
                            }
                            placeholder={`/${currentModel.writtenMaxScore}`}
                            className="w-16 px-1.5 py-1 text-center bg-white border border-[#CBD5E1] rounded-lg text-sm font-bold text-[#1E293B] focus:border-[#2B6CB0] focus:ring-1 focus:ring-[#2B6CB0] focus:outline-none"
                          />

                          {/* Written score conversion display under the input number */}
                          {writtenCalculated !== null && (
                            hasWrittenDecimal ? (
                              <button
                                type="button"
                                onClick={() => setIsRoundingModalOpen(true)}
                                className="text-[11px] leading-tight font-bold text-[#1F5078] bg-[#DCE8F2] hover:bg-[#CFDFEC] border border-[#B8D2E7] px-2 py-0.5 rounded-lg whitespace-nowrap shadow-2xs transition-all active:scale-95"
                                title="انقر لتعديل قاعدة جبر وتقريب الكسور العشرية"
                              >
                                {currentModel.roundingMode === 'none' ? (
                                  <span>{writtenCalculated} (بدون تقريب)</span>
                                ) : (
                                  <span>
                                    <span className="font-black">{writtenCalculated}</span>
                                    {' '}تحتسب{' '}
                                    <span className="font-black text-emerald-800 bg-white/90 px-1 py-0.2 rounded border border-emerald-300">
                                      {roundedWrittenScore}
                                    </span>
                                  </span>
                                )}
                              </button>
                            ) : (
                              writtenScoreMode === 'relative' &&
                              effectiveWrittenWeight !== currentModel.writtenMaxScore && (
                                <span
                                  className="text-xs font-black text-[#2B6CB0] bg-[#EFF6FF] px-1.5 py-0.5 rounded-lg whitespace-nowrap"
                                  title={`الدرجة المحسوبة (من ${effectiveWrittenWeight})`}
                                >
                                  = {writtenCalculated}
                                </span>
                              )
                            )
                          )}
                        </div>
                      </td>

                      {/* Optional Custom Columns (Oral, Behavior, etc.) */}
                      {(currentModel.customColumns || []).map((col) => {
                        const val = student.scores[col.id];
                        const isExceeded =
                          val !== null && val !== undefined && Number(val) > col.maxScore;

                        return (
                          <td
                            key={col.id}
                            className="py-1 px-2 text-center border border-[#CBD5E1]"
                          >
                            <input
                              type="number"
                              min="0"
                              max={col.maxScore}
                              step="any"
                              value={val === null || val === undefined ? '' : val}
                              onFocus={(e) => handleScoreCellFocus(e, student)}
                              onClick={(e) => handleScoreCellFocus(e, student)}
                              onChange={(e) =>
                                handleUpdateStudentCustomScore(
                                  student.id,
                                  col.id,
                                  e.target.value
                                )
                              }
                              placeholder={`/${col.maxScore}`}
                              className={`w-16 px-1 py-1 text-center border rounded-lg text-sm font-bold focus:bg-white focus:ring-1 focus:ring-[#2B6CB0] focus:outline-none ${
                                isExceeded
                                  ? 'border-red-300 text-red-600 bg-red-50'
                                  : 'border-[#CBD5E1] text-[#1E293B] bg-white'
                              }`}
                            />
                          </td>
                        );
                      })}

                      {/* Divider Column Cell between Written / Custom Columns and Final Score */}
                      <td className="w-16 border border-[#CBD5E1] bg-slate-50/40 text-center no-print print:hidden">
                        <div className="w-px h-6 bg-slate-200 mx-auto" />
                      </td>

                      {/* Mandatory Final Monthly Score */}
                      <td className="py-1 px-3 text-center font-black border border-[#CBD5E1]">
                        {totalMonthly !== null ? (
                          <div className="flex flex-col items-center justify-center gap-0.5">
                            <span className="text-sm sm:text-base font-black text-[#1E293B] px-2.5 py-0.5 bg-slate-100 rounded-lg inline-block min-w-[45px] border border-slate-200">
                              {totalMonthly}
                            </span>
                            {breakdown.hasOperation && breakdown.baseScore !== null && breakdown.baseScore !== totalMonthly && (
                              <span
                                className="text-[10px] text-blue-700 font-bold"
                                title={`المجموع قبل العملية (${breakdown.operationLabel}): ${breakdown.baseScore}`}
                              >
                                (الأصل: {breakdown.baseScore})
                              </span>
                            )}
                            {breakdown.isRounded && (
                              <span
                                className="text-[10px] text-[#854D0E] font-bold"
                                title={`الدرجة قبل جبر الكسور كانت ${breakdown.rawScore}`}
                              >
                                (أصله: {breakdown.rawScore})
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-400 text-xs">-</span>
                        )}
                      </td>

                      {/* Rating Badge */}
                      {showRatingColumn && (
                        <td className="py-1 px-2 text-center border border-[#CBD5E1] animate-in fade-in">
                          <span
                            className={`text-[11px] px-2.5 py-0.5 rounded-full font-bold border ${rating.badgeBg} ${rating.badgeText}`}
                          >
                            {rating.text}
                          </span>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            )}
          </table>
        </div>

        {/* Empty State Banner (Outside overflow-x-auto so it is 100% full-width on mobile screen,
            perfectly centered and NEVER cut off off-screen!) */}
        {filteredStudents.length === 0 && (
          <div className="py-8 px-4 text-center bg-white border-t border-[#E8E4DA]">
            <div className="max-w-md mx-auto space-y-3">
              {currentModel.students.length === 0 ? (
                <>
                  <div className="w-12 h-12 mx-auto rounded-2xl bg-[#EEF4F8] border border-[#D2E0EC] flex items-center justify-center text-[#557A95] shadow-xs">
                    <UserPlus className="w-6 h-6" />
                  </div>

                  <div className="pt-1 flex items-center justify-center">
                    <button
                      type="button"
                      onClick={() => setIsBatchImportOpen(true)}
                      className="w-full sm:w-auto px-6 py-2.5 craft-btn-primary active:scale-95 text-white rounded-xl text-xs sm:text-sm font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span>إضافة أو استيراد كشف الطلاب 📷</span>
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-12 h-12 mx-auto rounded-2xl bg-[#EEF4F8] border border-[#D2E0EC] flex items-center justify-center text-[#557A95] shadow-xs">
                    <Search className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-extrabold text-[#2E2B27] text-base">
                      لا يوجد طلاب مطابقين للبحث أو الشعبة المختارة
                    </p>
                    <p className="text-xs text-[#7A746B] mt-1">
                      جرّب تغيير كلمة البحث أو اختيار "جميع الشُعب"
                    </p>
                  </div>
                  <div className="pt-1 flex justify-center">
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery('');
                        setSelectedSection('ALL');
                      }}
                      className="px-4 py-2 bg-[#EDE8E0] hover:bg-[#E2DDD2] text-[#4A463F] rounded-xl text-xs font-bold transition-all cursor-pointer"
                    >
                      إلغاء التصفية وعرض الكل
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      {/* 4. Bottom Action Bar: Sits naturally under the table (NEVER fixed, so it will NEVER climb over the keyboard when typing on mobile) */}
      {hasStudents && (
        <div className="bg-[#FAF7EC] rounded-2xl border border-[#D8CEBD] p-3 sm:p-4 shadow-xs flex flex-wrap items-center justify-between gap-3 no-print">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsBatchImportOpen(true)}
              className="px-4 py-2.5 craft-btn-primary active:scale-95 text-white rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 shadow-xs cursor-pointer"
              title="إضافة طالب جديد أو لصق قائمة أسماء طلاب من ملف أو إكسل"
            >
              <UserPlus className="w-4 h-4" />
              <span>إضافة أو استيراد كشف الطلاب 📷</span>
            </button>
          </div>

          {/* Student count and clear all */}
          <div className="flex items-center gap-3 text-xs sm:text-sm text-[#7A746B] font-medium mr-auto sm:mr-0">
            <span>
              عدد الطلاب:{' '}
              <strong className="text-[#2E2B27] font-bold">
                {filteredStudents.length}
              </strong>{' '}
              من أصل{' '}
              <strong className="text-[#2E2B27] font-bold">
                {currentModel.students.length}
              </strong>
            </span>

            <button
              type="button"
              onClick={requestClearAllStudents}
              className="text-[#9A9388] hover:text-[#BD4B4B] text-xs underline transition-colors font-semibold cursor-pointer"
              title="مسح جميع أسماء الطلاب الحالية للبدء من جديد"
            >
              مسح الكل
            </button>
          </div>
        </div>
      )}

      {/* Quick "Add Field/Column" Modal */}
      {isAddingColumn && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-[#FAF7EC] rounded-2xl shadow-xl border border-[#D8CEBD] w-full max-w-md overflow-hidden">
            {/* Header - Sky Slate Blue Theme */}
            <div className="px-5 py-3.5 bg-[#5692BE] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-200" />
                <h3 className="text-sm font-bold">إضافة حقل درجة جديد للجدول</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddingColumn(false)}
                className="p-1 text-white/80 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content */}
            <div className="p-5 space-y-4">
              {/* Score Distribution Overview Box */}
              <div className="p-3 bg-blue-50/90 rounded-xl border border-blue-200 text-xs text-blue-950 space-y-1.5">
                <div className="flex items-center justify-between font-bold">
                  <span>إجمالي الدرجة النهائية للمادة:</span>
                  <span className="text-sm font-black text-[#2B6CB0]">
                    {totalMax} درجة
                  </span>
                </div>
                <p className="text-[11px] text-blue-800 leading-relaxed">
                  الحصة الحالية للتحريري: <strong>{effectiveWrittenWeight}</strong>{' '}
                  {customSum > 0 ? `+ الحقول الإضافية (${customSum})` : ''} ={' '}
                  <strong>{totalMax}</strong>.
                </p>
              </div>

              {/* Quick Preset Pills */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1.5">
                  حقول مقترحة وشائعة بنقرة واحدة:
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {presets.map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleAddNewColumn(p.name, p.max)}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-800 border border-slate-200 hover:border-indigo-300 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3 h-3 text-indigo-600" />
                      {p.name} ({p.max})
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Input */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اسم الحقل الجديد
                  </label>
                  <input
                    type="text"
                    value={newColName}
                    onChange={(e) => setNewColName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddNewColumn()}
                    placeholder="مثلاً: درجة الشفهي، السلوك، الواجبات..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    autoFocus
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الدرجة الكاملة لهذا الحقل
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="1"
                      max={totalMax}
                      value={newColMax}
                      onChange={(e) => setNewColMax(Number(e.target.value))}
                      className="w-24 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-center text-sm font-bold text-indigo-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                    <span className="text-xs text-slate-500 font-semibold">درجة</span>
                  </div>

                  {/* Live Calculation Feedback */}
                  <div className="mt-2 text-[11px] font-medium">
                    {totalMax - customSum - newColMax >= 0 ? (
                      <span className="text-emerald-800 bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-200 inline-block leading-relaxed">
                        ✓ عند وضع <strong>{newColMax || 0}</strong> درجة لهذا الحقل:
                        ستُحتسب درجة التحريري تلقائياً من{' '}
                        <strong className="text-emerald-950 font-black">
                          {Math.max(0, totalMax - customSum - (Number(newColMax) || 0))}
                        </strong>{' '}
                        ({totalMax > 0 ? Math.round((Math.max(0, totalMax - customSum - (Number(newColMax) || 0)) / totalMax) * 100) : 100}% من الدرجة النهائية) دون الحاجة لإدخال أي نسبة!
                      </span>
                    ) : (
                      <span className="text-rose-700 bg-rose-50 px-2 py-1 rounded inline-block font-bold">
                        ⚠️ تنبيه: وضع {newColMax} درجة سيتجاوز سقف الدرجة النهائية
                        بـ {Math.abs(totalMax - customSum - newColMax)} درجات زائدة.
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-5 py-3 bg-[#F8F4EA] border-t border-[#E0D5C3] flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsAddingColumn(false)}
                className="px-3 py-1.5 text-[#7A6E61] hover:bg-[#EBE3D3] rounded-lg text-xs font-semibold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => handleAddNewColumn()}
                disabled={!newColName.trim()}
                className="px-4 py-1.5 craft-btn-primary disabled:opacity-50 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                إضافة الحقل للجدول
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <BatchImportModal
        isOpen={isBatchImportOpen}
        onClose={() => setIsBatchImportOpen(false)}
        onImport={handleBatchImport}
        defaultGrade={currentModel.students[0]?.gradeLevel || 'الأول متوسط'}
        defaultSection={currentModel.students[0]?.section || (allSections[0] || 'أ')}
        customColumns={currentModel.customColumns}
        writtenMaxScore={currentModel.writtenMaxScore}
        existingStudents={currentModel.students}
        previousModelsStudents={otherModelsStudents}
      />

      <CreateModelModal
        isOpen={isCreateModelOpen}
        onClose={() => setIsCreateModelOpen(false)}
        currentModel={currentModel}
        allModels={models}
        onCreate={handleModelCreated}
      />

      {/* Confirmation Alert Modal for all deletions */}
      <ConfirmDeleteModal
        isOpen={confirmDelete.isOpen}
        title={confirmDelete.title}
        message={confirmDelete.message}
        confirmText={confirmDelete.confirmText}
        onConfirm={confirmDelete.onConfirm}
        onCancel={() => setConfirmDelete((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* Action Prompt Modal for Print / Export */}
      {actionPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150 text-right">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5 font-black text-slate-800 text-sm sm:text-base">
                <div className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0 shadow-2xs">
                  {actionPrompt.icon}
                </div>
                <span>{actionPrompt.title}</span>
              </div>
              <button
                type="button"
                onClick={() => setActionPrompt(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Message Body */}
            <div className="p-5 space-y-2">
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-semibold">
                {actionPrompt.message}
              </p>
            </div>

            {/* Actions */}
            <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setActionPrompt(null)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-200 rounded-xl font-bold text-xs transition-colors"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={actionPrompt.onConfirm}
                className={`px-4 py-2 text-white rounded-xl font-bold text-xs transition-all shadow-sm ${actionPrompt.confirmColor}`}
              >
                {actionPrompt.confirmText}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating fixed overlay dialog in front of page after creating a model (CSS position: fixed) */}
      {newlyCreatedModel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200 no-print" dir="rtl">
          <div className="bg-white rounded-3xl shadow-2xl border border-emerald-100 max-w-md w-full overflow-hidden animate-in zoom-in-95 duration-200">
            {/* Header banner */}
            <div className="bg-gradient-to-l from-[#3E6D52] via-[#487B5D] to-[#557A95] text-white p-6 text-center relative">
              <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-3 border border-white/25 shadow-md">
                <UserPlus className="w-7 h-7 text-emerald-100" />
              </div>
              <h3 className="text-lg sm:text-xl font-black">
                تم إنشاء نموذج ({newlyCreatedModel.name}) بنجاح!
              </h3>
              <p className="text-xs sm:text-sm text-emerald-100 mt-1 max-w-xs mx-auto leading-relaxed">
                الخطوة القادمة هي إضافة أو لصق أسماء الطلاب للبدء برصد الدرجات
              </p>
              <button
                type="button"
                onClick={() => setNewlyCreatedModel(null)}
                className="absolute top-4 left-4 p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content & Actions */}
            <div className="p-5 sm:p-6 space-y-3.5 text-center">
              <p className="text-xs text-slate-600 leading-relaxed font-semibold">
                النموذج جاهز حالياً. يمكنك كتابة اسم طالب أو لصق قائمة أسماء طلابك من ملف وورد أو إكسل دفعة واحدة.
              </p>

              <button
                type="button"
                onClick={() => {
                  setNewlyCreatedModel(null);
                  setIsBatchImportOpen(true);
                }}
                className="w-full py-3.5 px-5 bg-[#487B5D] hover:bg-[#3C684E] active:scale-98 text-white rounded-2xl text-sm font-black transition-all shadow-md flex items-center justify-center gap-2"
              >
                <UserPlus className="w-5 h-5" />
                <span>إضافة طالب أو لصق أسماء الطلاب</span>
              </button>

              <button
                type="button"
                onClick={() => setNewlyCreatedModel(null)}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold transition-colors"
              >
                سأقوم بإضافتهم لاحقاً
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Score Rounding Modal */}
      <ScoreRoundingModal
        isOpen={isRoundingModalOpen}
        onClose={() => setIsRoundingModalOpen(false)}
        currentMode={currentModel.roundingMode || 'none'}
        currentThreshold={currentModel.roundingThreshold || 0.5}
        modelName={currentModel.name}
        onSave={handleSaveRounding}
      />
      {/* Final Score Math Operation Modal */}
      <FinalScoreOperationModal
        isOpen={isFinalOperationModalOpen}
        onClose={() => setIsFinalOperationModalOpen(false)}
        currentOperation={currentModel.finalScoreOperation}
        totalMaxScore={currentModel.totalMaxScore || 100}
        modelName={currentModel.name}
        onSave={handleSaveFinalScoreOperation}
      />
      {/* Rename Columns Modal */}
      <RenameColumnsModal
        isOpen={isRenameColumnsModalOpen}
        onClose={() => setIsRenameColumnsModalOpen(false)}
        model={currentModel}
        onSave={(newLabels, updatedCustomCols) => {
          if (onUpdateAllModels && models.length > 0) {
            const updated = models.map((m) => ({
              ...m,
              columnLabels: newLabels,
              customColumns: updatedCustomCols,
              updatedAt: new Date().toISOString(),
            }));
            onUpdateAllModels(updated);
          } else {
            onUpdateModel({
              ...currentModel,
              columnLabels: newLabels,
              customColumns: updatedCustomCols,
              updatedAt: new Date().toISOString(),
            });
          }
        }}
      />

      {/* Floating Student Info Cloud during horizontal scrolling (only when names are scrolled out of view) */}
      <StudentFloatingCloud
        info={activeStudentCloud}
        isOpen={Boolean(activeStudentCloud) && !isNameColumnVisible}
        onClose={() => setActiveStudentCloud(null)}
      />
    </div>
  );
};
