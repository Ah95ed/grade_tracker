import { GoogleGenAI, Type } from '@google/genai';
import { isWrittenScoreColumn } from '../utils/gradeCalculations';
import { cleanSingleSpaces } from '../utils/arabicNameMatcher';

export interface AvailableColumnInfo {
  id: string;
  name: string;
  type: 'written' | 'custom';
  maxScore?: number;
}

export interface DetectedScoreItem {
  columnName: string;
  type: string;
  score: number | null;
}

export interface ExtractedStudent {
  name: string;
  gradeLevel: string;
  section: string;
  writtenRawScore: number | null;
  scores: Record<string, number | null>;
  detectedScores: DetectedScoreItem[];
  isAbsent?: boolean;
  notes?: string;
}

export interface DetectedColumn {
  name: string;
  type: string;
}

export interface ExtractRequestPayload {
  images: Array<{
    mimeType: string;
    data: string; // base64 string
  }>;
  defaultGrade?: string;
  defaultSection?: string;
  availableColumns?: AvailableColumnInfo[];
  apiKey?: string;
}

export interface ExtractionResult {
  detectedGrade?: string;
  detectedSection?: string;
  students: ExtractedStudent[];
  detectedColumns: DetectedColumn[];
}

function normalizeArabicText(str: string): string {
  return str
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .trim();
}

function safeParseOrRepairJson(raw: string): any {
  if (!raw || typeof raw !== 'string') return null;
  let cleaned = raw.trim();
  cleaned = cleaned.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```$/i, '').trim();

  try {
    return JSON.parse(cleaned);
  } catch {
    // Attempt repair for truncated JSON response
  }

  try {
    const studentsIdx = cleaned.indexOf('"students"');
    if (studentsIdx !== -1) {
      const arrStart = cleaned.indexOf('[', studentsIdx);
      if (arrStart !== -1) {
        const lastObjectEnd = cleaned.lastIndexOf('}');
        if (lastObjectEnd > arrStart) {
          const repaired = cleaned.slice(0, lastObjectEnd + 1) + ']}';
          return JSON.parse(repaired);
        }
      }
    }
  } catch {
    // Repair failed
  }
  return null;
}

export async function extractStudentsFromImages(
  payload: ExtractRequestPayload
): Promise<ExtractionResult> {
  const { images, defaultGrade = 'الأول متوسط', defaultSection = 'أ', availableColumns = [], apiKey: clientApiKey } = payload;

  if (!images || images.length === 0) {
    throw new Error('لم يتم إرسال أي صورة للمعالجة');
  }

  // Prioritize explicitly provided key from client, then server primary key (GEMINI_API_KEYD), then fallback key (GEMINI_API_KEYA)
  const primaryKey = (
    (clientApiKey || '').trim() ||
    process.env.GEMINI_API_KEYD ||
    process.env.GEMINI_APK_KEYd ||
    process.env.GEMINI_API_KEY ||
    process.env.GEMINI_API_KEYd ||
    process.env.GOOGLE_API_KEY ||
    process.env.VITE_GEMINI_API_KEY ||
    ''
  )
    .trim()
    .replace(/^["'\s]+|["'\s]+$/g, '');

  const fallbackKey = (
    process.env.GEMINI_API_KEYA ||
    process.env.API_KEY_GEMINIA ||
    process.env.GEMINI_API_KEY_A ||
    process.env.GEMINI_API_KEY_2 ||
    ''
  )
    .trim()
    .replace(/^["'\s]+|["'\s]+$/g, '');

  const apiKeys: string[] = [];
  if (primaryKey) apiKeys.push(primaryKey);
  if (fallbackKey && !apiKeys.includes(fallbackKey)) apiKeys.push(fallbackKey);

  if (apiKeys.length === 0) {
    const err: any = new Error('مفتاح Gemini API غير متوفر. يرجى التأكد من ضبط GEMINI_API_KEYD أو GEMINI_API_KEYA.');
    err.isAuthError = true;
    err.status = 401;
    throw err;
  }

  const parts: any[] = images.map((img) => ({
    inlineData: {
      mimeType: img.mimeType || 'image/jpeg',
      data: img.data.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, ''),
    },
  }));

  const customCols = availableColumns.filter((c: any) => c.type !== 'written');
  const colsDescription = `
الأعمدة المعرفة في جدول المعلم داخل النظام للمطابقة الدقيقة:
1. خانة "الامتحان التحريري" (حقل: writtenRawScore): مخصص لدرجة الامتحان التحريري أو الورقي أو درجة الشهر أو الاختبار.
${
  customCols.length > 0
    ? `2. الأعمدة الإضافية المسجلة حالياً في جدول المعلم:\n` +
      customCols
        .map((c: any) => `   - "${c.name}" (المعرف: ${c.id}، الدرجة العظمى: ${c.maxScore || 'غير محدد'})`)
        .join('\n')
    : '2. لا توجد أعمدة إضافية معرفة مسبقاً، استخرج أي أعمدة درجات أخرى موجودة في الورقة بأسمائها الأصلية.'
}
`;

  const promptText = `أنت مساعد خبير ومتقدم جداً وموثوق في التعرف البصري واستخراج البيانات من كشوفات وقوائم درجات الطلاب المدرسية باللغة العربية (سواء كانت مطبوعة طباعة رسمية كجداول وإكسل أو مكتوبة بخط اليد بالكامل على ورق مسطر أو دفاتر درجات).
قم بتحليل الصورة / الصور المرفقة بعناية فائقة، واستخرج جميع أسماء الطلاب، والصف الدراسي، والشعبة، وجميع الدرجات المسجلة لكل طالب مع تصنيف دقيق لنوع كل درجة وتوزيعها على أعمدة الجدول وفق القواعد الصارمة التالية:

⚠️ التوجيه الحاسم الأول (قراءة ترويسة الورقة واستخراج المرحلة/الصف والشعبة):
- اقرأ ترويسة الورقة (أعلى الصفحة) لاستخراج الصف/المرحلة الدراسية (مثل: "الأول متوسط"، "الثاني متوسط"، "الثالث متوسط"، "الرابع الإعدادي"، "الخامس علمي"، "السادس الابتدائي"، إلخ) وضعه في الحقل الرئيسي detectedGrade.
- اقرأ الشعبة من أعلى الورقة (مثل: "أ"، "ب"، "ج"، "د"، "شعبة 1"، "شعبة 2") وضعها في الحقل الرئيسي detectedSection.
- إذا لم تكن المرحلة أو الشعبة مكتوبة في الترويسة، فاستخدم القيم الافتراضية ("${defaultGrade}"، "${defaultSection}").

⚠️ التوجيه الحاسم الثاني (استخراج كافة أسماء الطلاب دون أي استثناء):
- يجب قراءة واستخراج **جميع** أسماء وصفوف ودرجات الطلاب الموجودين في الصورة أو الكشف من أول اسم في أعلى القائمة حتى آخر اسم في أسفلها سطراً بسطر.
- الكشوفات المدرسية تضم عادةً ما بين 10 إلى 50 طالباً. ممنوع منعاً باتاً التوقف بعد أول طالبين أو ثلاثة كعينة، ويجب إدراج كل طالب يظهر في الورقة كعنصر مستقل في مصفوفة students بدون أي اختصار أو حذف.
- استخرج الاسم كاملاً (الثلاثي أو الرباعي) كما هو مسجل بالورقة دون قطع.
- ⚠️ قاعدة دقيقة للمسافات: يجب دائماً عند استخراج الأسماء أن يكون بين كلمات الاسم الثلاثي أو الرباعي فراغ (مسافة) واحدة فقط، مثلاً: "محمد علي" وليس "محمد  علي" بمسافات مزدوجة أو زائدة.

⚠️ التوجيه الحاسم الثالث (قراءة عناوين الأعمدة وتوزيع الدرجات في مكانها الصحيح في الجدول):
1. اقرأ صف عناوين الأعمدة في أعلى الجدول بدقة لتحديد موضع كل نوع من الدرجات:
   أ) عمود الامتحان التحريري (حقل writtenRawScore):
      - ضع فيه الدرجة الرقمية المأخوذة حصراً من العمود المعنون بـ:
        (تحريري، الامتحان التحريري، التحريري، اختبار تحريري، كتابي، ورقي، امتحان، اختبار، درجة الشهر، الشهر الأول، الشهر الثاني، السعي، أو عمود الدرجة الأساسي إذا لم يكن بالورقة سوى عمود واحد فقط للدرجات).
      - ⚠️ تحذير فائق الأهمية: إذا كان الكشف يحتوي على عمودين أو أكثر (مثلاً عمود شفهي وعمود تحريري)، فلا تضع درجة الشفهي في خانة التحريري أبداً! ضع درجة كل عمود في مكانه الصحيح.
      - ⚠️ قاعدة ذهبية حاسمة: لا تدرج أبداً عمود التحريري أو أي من مسمياته (مثل "الدرجة التحريري" أو "التحريري") ضمن مصفوفة detectedScores أو مصفوفة detectedColumns! درجة التحريري مكانها الوحيد هو حقل writtenRawScore فقط.
   ب) أعمدة الدرجات الأخرى (مصفوفة detectedScores ومصفوفة detectedColumns):
      - مخصصة حصراً لأعمدة الدرجات الإضافية الأخرى بخلاف التحريري (مثل: شفهي، نشاط، يومي، مشاركة، واجبات، دفتر، مواظبة، سلوك، مشروع):
        * ضعه في مصفوفة detectedScores مع تحديد:
          - columnName: اسم العمود كما هو مكتوب في الورقة تماماً (مثلاً: "الشفهي"، "النشاط"، "الواجبات").
          - type: نوع الدرجة (oral للشفهي، activity للنشاط أو اليومي، homework للواجبات أو الدفتر، attendance للمواظبة، behavior للسلوك، other لأي نوع آخر).
          - score: القيمة العددية للدرجة.
        * طابق مسميات الأعمدة في الورقة مع الأعمدة المعرفة في السجل الموضحة أدناه متى ما اتفقت في المعنى.
      - إذا لم يكن في الورقة سوى درجات التحريري فقط، فاترك detectedColumns و detectedScores فارغة تماماً!
2. معالجة الحالات الخاصة:
   - حوّل الأرقام المشرقية (٠، ١، ٢، ٣، ٤، ٥، ٦، ٧، ٨، ٩) إلى أرقام قياسية (0-9).
   - ادعم الكسور والدرجات العشرية (مثل: 18.5 أو 9.5).
   - الطالب الغائب: إذا كان الطالب مسجلاً كغائب (مكتوب "غ"، "غائب"، "مؤجل") أو خانة الدرجة فارغة تماماً مع علامة غياب، اجعل الدرجة null وضع isAbsent: true واكتب "غائب" في notes.
   - لا تدرج أرقام التسلسل (مثل 1، 2، 3 في عمود "ت") ضمن الدرجات، ولا تدرج عناوين الجدول كطلاب.
${colsDescription}`;

  parts.push({ text: promptText });

  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      detectedGrade: {
        type: Type.STRING,
        description: 'الصف أو المرحلة الدراسية المستخرجة من ترويسة الورقة',
      },
      detectedSection: {
        type: Type.STRING,
        description: 'الشعبة المستخرجة من ترويسة الورقة (أ، ب، ج، د...)',
      },
      students: {
        type: Type.ARRAY,
        description: 'قائمة بجميع الطلاب المستخرجين من الكشف من أول اسم لآخر اسم',
        items: {
          type: Type.OBJECT,
          properties: {
            name: {
              type: Type.STRING,
              description: 'اسم الطالب الكامل باللغة العربية',
            },
            gradeLevel: {
              type: Type.STRING,
              description: 'الصف أو المرحلة الدراسية لهذا الطالب',
            },
            section: {
              type: Type.STRING,
              description: 'الشعبة أو الفصل الدراسي لهذا الطالب',
            },
            writtenRawScore: {
              type: Type.NUMBER,
              description: 'درجة الامتحان التحريري أو الورقي أو درجة الشهر (null إن لم توجد أو كان غائباً)',
            },
            detectedScores: {
              type: Type.ARRAY,
              description: 'الدرجات الأخرى (شفهي، نشاط، يومي، واجبات، دفتر)',
              items: {
                type: Type.OBJECT,
                properties: {
                  columnName: { type: Type.STRING, description: 'اسم العمود بالعربية كما في الورقة' },
                  type: { type: Type.STRING, description: 'نوع الدرجة: oral, activity, homework, attendance, behavior, other' },
                  score: { type: Type.NUMBER, description: 'قيمة الدرجة الرقمية' },
                },
                required: ['columnName'],
              },
            },
            isAbsent: {
              type: Type.BOOLEAN,
              description: 'هل الطالب غائب في الكشف أو الامتحان',
            },
            notes: {
              type: Type.STRING,
              description: 'ملاحظات مسجلة (مثل غائب أو مؤجل)',
            },
          },
          required: ['name'],
        },
      },
      detectedColumns: {
        type: Type.ARRAY,
        description: 'قائمة أعمدة الدرجات الإضافية الموجودة بالورقة بخلاف التحريري',
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING, description: 'اسم العمود بالعربية' },
            type: { type: Type.STRING, description: 'نوع الدرجة: oral, activity, homework, attendance, behavior, other' },
          },
          required: ['name'],
        },
      },
    },
    required: ['students'],
  };

  let responseText = '';
  let authErrorDetected = false;
  let lastErrorMessage = '';

  // المرور على المفاتيح: في حال وجود ضغط (429/Resource Exhausted) أو مشكلة، ننتقل فوراً للمفتاح الاحتياطي
  keyLoop: for (let kIdx = 0; kIdx < apiKeys.length; kIdx++) {
    const currentKey = apiKeys[kIdx];
    const keyLabel = kIdx === 0 ? 'المفتاح الأساسي (GEMINI_API_KEYD)' : 'المفتاح الاحتياطي (GEMINI_API_KEYA)';

    const ai = new GoogleGenAI({
      apiKey: currentKey,
      httpOptions: {
        headers: {
          'x-goog-api-key': currentKey,
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const tryGenerate = async (model: string) => {
      return await ai.models.generateContent({
        model,
        contents: { parts },
        config: {
          responseMimeType: 'application/json',
          responseSchema,
          temperature: 0.1,
          maxOutputTokens: 32768,
        },
      });
    };

    const models = ['gemini-3.1-flash-lite', 'gemini-3.5-flash', 'gemini-3.8-flash'];
    for (const model of models) {
      try {
        const response = await tryGenerate(model);
        if (response.text) {
          responseText = response.text;
          if (kIdx > 0) {
            console.log(`[Dev] تم الاستخراج بنجاح باستخدام ${keyLabel}`);
          }
          break keyLoop;
        }
      } catch (err: any) {
        lastErrorMessage = err?.message || String(err);
        const isAuth =
          lastErrorMessage.includes('401') ||
          lastErrorMessage.includes('UNAUTHENTICATED') ||
          lastErrorMessage.includes('ACCESS_TOKEN_TYPE_UNSUPPORTED') ||
          lastErrorMessage.includes('API key not valid') ||
          lastErrorMessage.includes('API_KEY_INVALID');

        const isOverloadedOrRateLimited =
          lastErrorMessage.includes('429') ||
          lastErrorMessage.includes('RESOURCE_EXHAUSTED') ||
          lastErrorMessage.includes('quota') ||
          lastErrorMessage.includes('rate limit') ||
          lastErrorMessage.includes('503') ||
          lastErrorMessage.includes('prepayment');

        if (isAuth) authErrorDetected = true;

        if ((isOverloadedOrRateLimited || isAuth) && kIdx < apiKeys.length - 1) {
          console.warn(`[Dev] ${keyLabel} واجه ضغطاً أو مشكلة (${lastErrorMessage.slice(0, 80)}). الانتقال إلى المفتاح التالي (GEMINI_API_KEYA)...`);
          break; // انتقل للمفتاح الاحتياطي
        }
      }
    }

    // تجربة REST المباشر إذا لم تنجح الحزمة على هذا المفتاح
    if (!responseText && !authErrorDetected) {
      try {
        responseText = await callGeminiDirectRest(currentKey, images, promptText);
        if (responseText) {
          break keyLoop;
        }
      } catch (restErr: any) {
        lastErrorMessage = restErr?.message || String(restErr);
      }
    }
  }

  if (authErrorDetected || (!responseText && lastErrorMessage.includes('401'))) {
    const e: any = new Error('مفتاح Gemini API غير مصرح له أو منتهي الصلاحية (رمز 401). يرجى التأكد من صلاحية المفاتيح GEMINI_API_KEYD و GEMINI_API_KEYA.');
    e.isAuthError = true;
    e.status = 401;
    throw e;
  }

  if (!responseText) {
    throw new Error(`فشلت المعالجة بالذكاء الاصطناعي: ${lastErrorMessage.slice(0, 160)}`);
  }

  let parsed: any = safeParseOrRepairJson(responseText);

  let rawList: any[] = [];
  let detectedGradeVal = defaultGrade;
  let detectedSectionVal = defaultSection;

  if (Array.isArray(parsed)) {
    rawList = parsed;
  } else if (parsed && typeof parsed === 'object') {
    if (Array.isArray(parsed.students)) {
      rawList = parsed.students;
    }
    if (parsed.detectedGrade && typeof parsed.detectedGrade === 'string' && parsed.detectedGrade.trim()) {
      detectedGradeVal = parsed.detectedGrade.trim();
    }
    if (parsed.detectedSection && typeof parsed.detectedSection === 'string' && parsed.detectedSection.trim()) {
      detectedSectionVal = parsed.detectedSection.trim();
    }
  }

  const detectedColsMap = new Map<string, { name: string; type: string }>();

  // If parsed object had explicit detectedColumns, filter out any written exam columns
  if (parsed && Array.isArray(parsed.detectedColumns)) {
    for (const col of parsed.detectedColumns) {
      if (col && col.name && !isWrittenScoreColumn(col.name, col.type)) {
        detectedColsMap.set(col.name, { name: col.name, type: col.type || 'other' });
      }
    }
  }

  const students: ExtractedStudent[] = rawList
    .map((item: any) => {
      const name = cleanSingleSpaces(String(item.name || ''));
      const studentGrade = String(item.gradeLevel || detectedGradeVal || defaultGrade).trim();
      const studentSection = String(item.section || detectedSectionVal || defaultSection).trim();

      let writtenRawScore: number | null = null;
      if (typeof item.writtenRawScore === 'number' && !isNaN(item.writtenRawScore)) {
        writtenRawScore = item.writtenRawScore;
      } else if (typeof item.writtenRawScore === 'string' && item.writtenRawScore.trim() !== '') {
        const n = parseFloat(item.writtenRawScore);
        if (!isNaN(n)) writtenRawScore = n;
      }

      const detectedScores: DetectedScoreItem[] = [];
      const scores: Record<string, number | null> = {};

      if (Array.isArray(item.detectedScores)) {
        for (const ds of item.detectedScores) {
          if (!ds || !ds.columnName) continue;
          const colName = String(ds.columnName).trim();
          const colType = String(ds.type || 'other').trim();

          let sVal: number | null = null;
          if (typeof ds.score === 'number' && !isNaN(ds.score)) {
            sVal = ds.score;
          } else if (typeof ds.score === 'string' && ds.score.trim() !== '') {
            const parsedNum = parseFloat(ds.score);
            if (!isNaN(parsedNum)) sVal = parsedNum;
          }

          const isWritten = isWrittenScoreColumn(colName, colType);

          // If written exam score, route it strictly and solely to writtenRawScore
          if (isWritten) {
            if ((writtenRawScore === null || writtenRawScore === undefined) && sVal !== null) {
              writtenRawScore = sVal;
            }
          } else {
            detectedScores.push({
              columnName: colName,
              type: colType,
              score: sVal,
            });
            scores[colName] = sVal;
            scores[normalizeArabicText(colName)] = sVal;

            if (!detectedColsMap.has(colName)) {
              detectedColsMap.set(colName, { name: colName, type: colType });
            }
          }
        }
      }

      // Map to available custom column IDs and names if provided
      if (availableColumns && availableColumns.length > 0) {
        for (const col of availableColumns) {
          if (col.type === 'written' || isWrittenScoreColumn(col.name)) {
            if (writtenRawScore !== null) {
              scores['written'] = writtenRawScore;
            }
            continue;
          }
          const normTarget = normalizeArabicText(col.name);
          for (const [colName, val] of Object.entries(scores)) {
            const normKey = normalizeArabicText(colName);
            if (
              colName === col.id ||
              normKey === normTarget ||
              normKey.includes(normTarget) ||
              normTarget.includes(normKey)
            ) {
              scores[col.id] = val;
              scores[col.name] = val;
            }
          }
        }
      }

      return {
        name,
        gradeLevel: studentGrade,
        section: studentSection,
        writtenRawScore,
        scores,
        detectedScores,
        isAbsent: Boolean(item.isAbsent),
        notes: String(item.notes || '').trim(),
      };
    })
    .filter((s) => s.name.length > 0 && !s.name.includes('اسم الطالب') && !s.name.includes('اسم التلميذ') && !s.name.includes('الملاحظات'));

  const detectedColumns = Array.from(detectedColsMap.values()).filter(
    (c) => c && c.name && !isWrittenScoreColumn(c.name, c.type)
  );

  return {
    detectedGrade: detectedGradeVal,
    detectedSection: detectedSectionVal,
    students,
    detectedColumns,
  };
}

async function callGeminiDirectRest(
  apiKey: string,
  images: Array<{ mimeType: string; data: string }>,
  promptText: string
): Promise<string> {
  const parts: any[] = images.map((img) => ({
    inline_data: {
      mime_type: img.mimeType || 'image/jpeg',
      data: img.data.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, ''),
    },
  }));
  parts.push({ text: promptText });

  const payload = {
    contents: [{ parts }],
    generationConfig: {
      response_mime_type: 'application/json',
      temperature: 0.1,
      max_output_tokens: 32768,
    },
  };

  const models = ['gemini-3.1-flash-lite', 'gemini-3.5-flash', 'gemini-3.8-flash'];
  let lastError: any = null;

  for (const model of models) {
    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': apiKey,
            'User-Agent': 'aistudio-build',
          },
          body: JSON.stringify(payload),
        }
      );

      if (res.ok) {
        const data = (await res.json()) as any;
        return data.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
      }

      const errText = await res.text().catch(() => '');
      if (
        res.status === 401 ||
        (res.status === 400 && errText.includes('API key')) ||
        errText.includes('401') ||
        errText.includes('UNAUTHENTICATED') ||
        errText.includes('API key not valid') ||
        errText.includes('API_KEY_INVALID')
      ) {
        const e: any = new Error('مفتاح Gemini API غير صالح (رمز 401). يرجى إدخال مفتاح صالح للاستمرار.');
        e.status = 401;
        e.isAuthError = true;
        throw e;
      }
      lastError = new Error(`Gemini REST error (${res.status}): ${errText}`);
    } catch (e: any) {
      if (e.isAuthError) throw e;
      lastError = e;
    }
  }

  throw lastError || new Error('فشل استدعاء Gemini REST API');
}
